## Goal

Make the Go Live button on `/my-agents` actually compile a saved agent's IR and push it to Retell — instead of only storing a Retell ID the user pastes in.

## Changes

### 1. New server function — `src/lib/orchestration/deploy-by-id.functions.ts`

Add the pasted `deployAgentById` server fn verbatim. It:
- Loads the agent row (workspace, settings, existing Retell IDs).
- Validates `settings.ir` via `validateAgent` and parses `settings.tools`.
- Calls `deployAgentToRetell` (create or update, depending on whether IDs already exist).
- Persists the returned `retell_agent_id` + `retell_conversation_flow_id` on the agent row.
- Writes a `deployments` audit row (success or error).

Placed under `src/lib/orchestration/` next to the existing `deploy.functions.ts` so it sits with the other deploy primitives. File is client-safe (only imports `*.server.ts` inside the handler chain via the adapter).

### 2. Wire Go Live in `src/routes/_authenticated/my-agents.tsx`

Update the "Go Live" dialog so the primary action runs `deployAgentById` instead of the manual paste flow:

- Import `deployAgentById` and add a second `useServerFn` + `useMutation` (`deployMutation`).
- Rework dialog body:
  - Keep flow-type selector (lead_gen / receptionist).
  - For receptionist: keep inbound phone number input.
  - Drop the required "Retell agent ID" input from the primary path. The Retell ID is now produced by the deploy, not pasted.
  - Add a collapsible "Advanced — link existing Retell agent" section that still exposes the manual paste flow (existing `linkAgentToRetell`) for re-linking imported agents.
- Primary button "Go Live" now:
  1. If flow-type / inbound number changed, call `linkAgentToRetell` first to persist those fields (without clearing the Retell ID).
  2. Call `deployAgentById({ id })`.
  3. On success: toast "Agent is live", invalidate `["my-agents"]`, close dialog.
  4. On error: toast the error message (the server fn already logs to `deployments`).
- "Re-link" button label stays for already-deployed agents; clicking it still opens the same dialog and runs the same deploy path (which updates instead of creates because Retell IDs are present on the row).
- "Unlink" button unchanged.

### 3. No DB or schema changes

`agents.settings`, `retell_agent_id`, `retell_conversation_flow_id`, and `deployments` already exist. No migration needed.

### Technical notes

- `deployAgentById` throws a friendly error when `settings.ir` is missing — the dialog surfaces this via toast, prompting the user to save the agent in the builder first.
- The deploy fn relies on `RETELL_API_KEY` (already configured as a secret).
- Existing `linkAgentToRetell` stays in the codebase and is still used for (a) the advanced manual-link path and (b) setting `agent_type` / `inbound_phone_number` before deploy.
