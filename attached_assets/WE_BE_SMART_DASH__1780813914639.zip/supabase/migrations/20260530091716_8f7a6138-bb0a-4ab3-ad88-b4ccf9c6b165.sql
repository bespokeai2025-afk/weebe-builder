ALTER TABLE public.workspace_settings
  ADD COLUMN IF NOT EXISTS calcom_webhook_secret text;

CREATE UNIQUE INDEX IF NOT EXISTS calendar_bookings_workspace_external_idx
  ON public.calendar_bookings (workspace_id, external_id)
  WHERE external_id IS NOT NULL;