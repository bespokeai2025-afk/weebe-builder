-- Reset password + confirm email for nathanbrett1994@icloud.com
UPDATE auth.users
SET
  encrypted_password = crypt('TempPass!2026', gen_salt('bf')),
  email_confirmed_at = COALESCE(email_confirmed_at, now()),
  updated_at = now()
WHERE email = 'nathanbrett1994@icloud.com';

-- Grant admin role
INSERT INTO public.user_roles (user_id, role)
SELECT id, 'admin'::app_role FROM auth.users WHERE email = 'nathanbrett1994@icloud.com'
ON CONFLICT (user_id, role) DO NOTHING;