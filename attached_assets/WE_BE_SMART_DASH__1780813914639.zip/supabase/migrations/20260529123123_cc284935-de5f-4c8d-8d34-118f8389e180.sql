
-- Lock down handle_new_user (called by auth trigger only)
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.tg_set_updated_at() FROM PUBLIC, anon, authenticated;

-- Helper role/membership functions: callable by authenticated only (used in RLS)
REVOKE EXECUTE ON FUNCTION public.has_role(UUID, public.app_role) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.is_workspace_member(UUID, UUID) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.workspace_role_of(UUID, UUID) FROM PUBLIC, anon;

-- Ensure search_path on the trigger helper (warning 1)
ALTER FUNCTION public.tg_set_updated_at() SET search_path = public;
