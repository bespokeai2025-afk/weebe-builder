-- Ensure calls.retell_call_id is unique (required for webhook upsert onConflict)
CREATE UNIQUE INDEX IF NOT EXISTS calls_retell_call_id_key
  ON public.calls (retell_call_id)
  WHERE retell_call_id IS NOT NULL;

-- Speed up phone-based linking from webhook
CREATE INDEX IF NOT EXISTS leads_workspace_phone_idx
  ON public.leads (workspace_id, phone);

CREATE INDEX IF NOT EXISTS data_records_workspace_mobile_idx
  ON public.data_records (workspace_id, mobile_number);

CREATE INDEX IF NOT EXISTS calls_workspace_started_idx
  ON public.calls (workspace_id, started_at DESC);