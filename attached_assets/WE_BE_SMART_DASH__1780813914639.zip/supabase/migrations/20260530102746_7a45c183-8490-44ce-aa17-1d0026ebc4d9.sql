CREATE TABLE IF NOT EXISTS public.retell_webhook_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID,
  retell_call_id TEXT,
  retell_agent_id TEXT,
  event_type TEXT NOT NULL,
  signature_valid BOOLEAN,
  processing_status TEXT NOT NULL DEFAULT 'received',
  payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  error_message TEXT,
  received_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  processed_at TIMESTAMPTZ
);

GRANT SELECT ON public.retell_webhook_events TO authenticated;
GRANT ALL ON public.retell_webhook_events TO service_role;

ALTER TABLE public.retell_webhook_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY retell_webhook_events_select_workspace_members
  ON public.retell_webhook_events
  FOR SELECT
  TO authenticated
  USING (workspace_id IS NOT NULL AND public.is_workspace_member(workspace_id, auth.uid()));

CREATE INDEX IF NOT EXISTS retell_webhook_events_workspace_received_idx
  ON public.retell_webhook_events (workspace_id, received_at DESC);
CREATE INDEX IF NOT EXISTS retell_webhook_events_call_idx
  ON public.retell_webhook_events (retell_call_id);
CREATE INDEX IF NOT EXISTS retell_webhook_events_event_type_idx
  ON public.retell_webhook_events (event_type);