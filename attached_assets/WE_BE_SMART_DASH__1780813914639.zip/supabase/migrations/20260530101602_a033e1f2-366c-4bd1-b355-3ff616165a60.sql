UPDATE public.workspace_settings
SET retell_default_agent_id = regexp_replace(retell_default_agent_id, '^agents/', '')
WHERE retell_default_agent_id LIKE 'agents/%';