-- Status enum for data record calling lifecycle
DO $$ BEGIN
  CREATE TYPE public.data_record_call_status AS ENUM (
    'needs_to_call',
    'queued',
    'calling',
    'completed',
    'failed',
    'do_not_call'
  );
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

ALTER TABLE public.data_records
  ADD COLUMN IF NOT EXISTS assigned_agent_id uuid,
  ADD COLUMN IF NOT EXISTS scheduled_call_at timestamptz,
  ADD COLUMN IF NOT EXISTS call_status public.data_record_call_status NOT NULL DEFAULT 'needs_to_call',
  ADD COLUMN IF NOT EXISTS last_call_at timestamptz,
  ADD COLUMN IF NOT EXISTS last_call_outcome text,
  ADD COLUMN IF NOT EXISTS last_call_sentiment text;

-- Backfill: if need_to_call was already false, treat as do_not_call so the UI reflects reality.
UPDATE public.data_records
SET call_status = 'do_not_call'
WHERE need_to_call = false AND call_status = 'needs_to_call';

CREATE INDEX IF NOT EXISTS data_records_call_status_idx
  ON public.data_records (workspace_id, call_status);
CREATE INDEX IF NOT EXISTS data_records_assigned_agent_idx
  ON public.data_records (workspace_id, assigned_agent_id);
CREATE INDEX IF NOT EXISTS data_records_scheduled_call_at_idx
  ON public.data_records (workspace_id, scheduled_call_at);

ALTER TABLE public.workspace_settings
  ADD COLUMN IF NOT EXISTS call_schedule jsonb NOT NULL DEFAULT '{}'::jsonb;
