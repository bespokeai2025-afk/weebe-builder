ALTER TABLE public.workspace_settings ADD COLUMN IF NOT EXISTS twilio_auth_token text;
CREATE UNIQUE INDEX IF NOT EXISTS whatsapp_messages_workspace_external_id_idx
  ON public.whatsapp_messages (workspace_id, external_id)
  WHERE external_id IS NOT NULL;