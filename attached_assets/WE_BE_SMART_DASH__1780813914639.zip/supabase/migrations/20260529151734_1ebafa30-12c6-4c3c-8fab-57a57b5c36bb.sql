CREATE TYPE public.agent_flow_type AS ENUM ('lead_gen', 'receptionist');

ALTER TABLE public.agents
  ADD COLUMN agent_type public.agent_flow_type NOT NULL DEFAULT 'lead_gen',
  ADD COLUMN inbound_phone_number text,
  ADD COLUMN retell_conversation_flow_id text;

CREATE INDEX IF NOT EXISTS idx_agents_agent_type ON public.agents(agent_type);
CREATE INDEX IF NOT EXISTS idx_agents_inbound_phone ON public.agents(inbound_phone_number);