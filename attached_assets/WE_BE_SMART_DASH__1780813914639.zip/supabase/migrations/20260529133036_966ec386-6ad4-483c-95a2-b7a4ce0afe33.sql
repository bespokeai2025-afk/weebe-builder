-- Helper to keep updated_at fresh (re-use existing tg_set_updated_at)

-- ============= LEADS =============
CREATE TYPE lead_source AS ENUM ('website','inbound','outbound','referral','import');
CREATE TYPE lead_status AS ENUM ('need_to_call','calling','completed','interested','not_interested','not_connected','do_not_call','qualified');
CREATE TYPE sentiment_kind AS ENUM ('positive','neutral','negative');

CREATE TABLE public.leads (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID NOT NULL,
  full_name TEXT,
  phone TEXT NOT NULL,
  email TEXT,
  company_name TEXT,
  funding_amount NUMERIC(12,2),
  state_name TEXT,
  business_type TEXT,
  business_address TEXT,
  monthly_revenue NUMERIC(12,2),
  source lead_source NOT NULL DEFAULT 'inbound',
  type TEXT,
  status lead_status NOT NULL DEFAULT 'need_to_call',
  sentiment sentiment_kind,
  call_outcome TEXT,
  attempt_count INT NOT NULL DEFAULT 0,
  callback_requested BOOLEAN NOT NULL DEFAULT false,
  sent_to_underwriting BOOLEAN NOT NULL DEFAULT false,
  bank_statements_uploaded BOOLEAN NOT NULL DEFAULT false,
  bank_statements_status TEXT,
  missing_information TEXT,
  notes TEXT,
  last_contacted_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX leads_workspace_id_idx ON public.leads(workspace_id);
CREATE INDEX leads_status_idx ON public.leads(workspace_id, status);
CREATE INDEX leads_phone_idx ON public.leads(phone);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.leads TO authenticated;
GRANT ALL ON public.leads TO service_role;

ALTER TABLE public.leads ENABLE ROW LEVEL SECURITY;
CREATE POLICY leads_select_workspace_members ON public.leads FOR SELECT TO authenticated
  USING (is_workspace_member(workspace_id, auth.uid()));
CREATE POLICY leads_insert_workspace_members ON public.leads FOR INSERT TO authenticated
  WITH CHECK (is_workspace_member(workspace_id, auth.uid()));
CREATE POLICY leads_update_workspace_members ON public.leads FOR UPDATE TO authenticated
  USING (is_workspace_member(workspace_id, auth.uid()));
CREATE POLICY leads_delete_workspace_members ON public.leads FOR DELETE TO authenticated
  USING (is_workspace_member(workspace_id, auth.uid()));

CREATE TRIGGER leads_set_updated_at BEFORE UPDATE ON public.leads
  FOR EACH ROW EXECUTE FUNCTION public.tg_set_updated_at();

-- ============= CALLS =============
CREATE TYPE call_type AS ENUM ('inbound','outbound');
CREATE TYPE call_status AS ENUM ('initiated','ringing','in_progress','completed','no_answer','busy','failed','voicemail');

CREATE TABLE public.calls (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID NOT NULL,
  lead_id UUID REFERENCES public.leads(id) ON DELETE SET NULL,
  call_type call_type NOT NULL DEFAULT 'outbound',
  call_status call_status NOT NULL DEFAULT 'initiated',
  retell_call_id TEXT,
  agent_id TEXT,
  agent_name TEXT,
  from_number TEXT,
  to_number TEXT NOT NULL,
  duration_seconds INT,
  started_at TIMESTAMPTZ,
  ended_at TIMESTAMPTZ,
  disconnection_reason TEXT,
  call_outcome TEXT,
  call_successful BOOLEAN,
  in_voicemail BOOLEAN,
  sentiment sentiment_kind,
  transcript TEXT,
  call_summary TEXT,
  recording_url TEXT,
  cost_cents INT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX calls_workspace_id_idx ON public.calls(workspace_id);
CREATE INDEX calls_lead_id_idx ON public.calls(lead_id);
CREATE INDEX calls_started_at_idx ON public.calls(workspace_id, started_at DESC);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.calls TO authenticated;
GRANT ALL ON public.calls TO service_role;

ALTER TABLE public.calls ENABLE ROW LEVEL SECURITY;
CREATE POLICY calls_select_workspace_members ON public.calls FOR SELECT TO authenticated
  USING (is_workspace_member(workspace_id, auth.uid()));
CREATE POLICY calls_insert_workspace_members ON public.calls FOR INSERT TO authenticated
  WITH CHECK (is_workspace_member(workspace_id, auth.uid()));
CREATE POLICY calls_update_workspace_members ON public.calls FOR UPDATE TO authenticated
  USING (is_workspace_member(workspace_id, auth.uid()));
CREATE POLICY calls_delete_workspace_members ON public.calls FOR DELETE TO authenticated
  USING (is_workspace_member(workspace_id, auth.uid()));

CREATE TRIGGER calls_set_updated_at BEFORE UPDATE ON public.calls
  FOR EACH ROW EXECUTE FUNCTION public.tg_set_updated_at();

-- ============= CALENDAR BOOKINGS =============
CREATE TYPE booking_status AS ENUM ('pending','accepted','completed','cancelled','rescheduled','no_show');

CREATE TABLE public.calendar_bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID NOT NULL,
  lead_id UUID REFERENCES public.leads(id) ON DELETE SET NULL,
  external_id TEXT,
  source TEXT NOT NULL DEFAULT 'manual',
  title TEXT NOT NULL,
  description TEXT,
  attendee_name TEXT,
  attendee_email TEXT,
  attendee_phone TEXT,
  start_at TIMESTAMPTZ NOT NULL,
  end_at TIMESTAMPTZ NOT NULL,
  status booking_status NOT NULL DEFAULT 'pending',
  meeting_url TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX bookings_workspace_idx ON public.calendar_bookings(workspace_id);
CREATE INDEX bookings_start_idx ON public.calendar_bookings(workspace_id, start_at);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.calendar_bookings TO authenticated;
GRANT ALL ON public.calendar_bookings TO service_role;

ALTER TABLE public.calendar_bookings ENABLE ROW LEVEL SECURITY;
CREATE POLICY bookings_select_workspace_members ON public.calendar_bookings FOR SELECT TO authenticated
  USING (is_workspace_member(workspace_id, auth.uid()));
CREATE POLICY bookings_insert_workspace_members ON public.calendar_bookings FOR INSERT TO authenticated
  WITH CHECK (is_workspace_member(workspace_id, auth.uid()));
CREATE POLICY bookings_update_workspace_members ON public.calendar_bookings FOR UPDATE TO authenticated
  USING (is_workspace_member(workspace_id, auth.uid()));
CREATE POLICY bookings_delete_workspace_members ON public.calendar_bookings FOR DELETE TO authenticated
  USING (is_workspace_member(workspace_id, auth.uid()));

CREATE TRIGGER bookings_set_updated_at BEFORE UPDATE ON public.calendar_bookings
  FOR EACH ROW EXECUTE FUNCTION public.tg_set_updated_at();

-- ============= WHATSAPP MESSAGES =============
CREATE TYPE message_direction AS ENUM ('inbound','outbound');
CREATE TYPE message_status AS ENUM ('queued','sent','delivered','read','failed');

CREATE TABLE public.whatsapp_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID NOT NULL,
  lead_id UUID REFERENCES public.leads(id) ON DELETE SET NULL,
  external_id TEXT,
  contact_phone TEXT NOT NULL,
  contact_name TEXT,
  direction message_direction NOT NULL,
  body TEXT,
  media_url TEXT,
  status message_status NOT NULL DEFAULT 'sent',
  sent_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX wa_workspace_idx ON public.whatsapp_messages(workspace_id);
CREATE INDEX wa_phone_idx ON public.whatsapp_messages(workspace_id, contact_phone, sent_at DESC);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.whatsapp_messages TO authenticated;
GRANT ALL ON public.whatsapp_messages TO service_role;

ALTER TABLE public.whatsapp_messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY wa_select_workspace_members ON public.whatsapp_messages FOR SELECT TO authenticated
  USING (is_workspace_member(workspace_id, auth.uid()));
CREATE POLICY wa_insert_workspace_members ON public.whatsapp_messages FOR INSERT TO authenticated
  WITH CHECK (is_workspace_member(workspace_id, auth.uid()));
CREATE POLICY wa_update_workspace_members ON public.whatsapp_messages FOR UPDATE TO authenticated
  USING (is_workspace_member(workspace_id, auth.uid()));
CREATE POLICY wa_delete_workspace_members ON public.whatsapp_messages FOR DELETE TO authenticated
  USING (is_workspace_member(workspace_id, auth.uid()));

-- ============= CRM / DATA RECORDS =============
CREATE TABLE public.data_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID NOT NULL,
  name TEXT NOT NULL,
  first_name TEXT,
  last_name TEXT,
  title TEXT,
  mobile_number TEXT NOT NULL,
  email TEXT,
  client_name TEXT,
  unique_id TEXT,
  lead_external_id TEXT,
  property_type TEXT,
  bedrooms TEXT,
  address_line1 TEXT,
  address_line2 TEXT,
  city TEXT,
  state TEXT,
  postal_code TEXT,
  need_to_call BOOLEAN NOT NULL DEFAULT true,
  is_active BOOLEAN NOT NULL DEFAULT true,
  is_deleted BOOLEAN NOT NULL DEFAULT false,
  meta JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX data_workspace_idx ON public.data_records(workspace_id);
CREATE INDEX data_mobile_idx ON public.data_records(workspace_id, mobile_number);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.data_records TO authenticated;
GRANT ALL ON public.data_records TO service_role;

ALTER TABLE public.data_records ENABLE ROW LEVEL SECURITY;
CREATE POLICY data_select_workspace_members ON public.data_records FOR SELECT TO authenticated
  USING (is_workspace_member(workspace_id, auth.uid()));
CREATE POLICY data_insert_workspace_members ON public.data_records FOR INSERT TO authenticated
  WITH CHECK (is_workspace_member(workspace_id, auth.uid()));
CREATE POLICY data_update_workspace_members ON public.data_records FOR UPDATE TO authenticated
  USING (is_workspace_member(workspace_id, auth.uid()));
CREATE POLICY data_delete_workspace_members ON public.data_records FOR DELETE TO authenticated
  USING (is_workspace_member(workspace_id, auth.uid()));

CREATE TRIGGER data_set_updated_at BEFORE UPDATE ON public.data_records
  FOR EACH ROW EXECUTE FUNCTION public.tg_set_updated_at();

-- ============= WORKSPACE SETTINGS =============
CREATE TABLE public.workspace_settings (
  workspace_id UUID PRIMARY KEY,
  business_name TEXT,
  timezone TEXT NOT NULL DEFAULT 'UTC',
  business_hours JSONB NOT NULL DEFAULT '{}'::jsonb,
  retell_workspace_id TEXT,
  retell_default_agent_id TEXT,
  calcom_api_token TEXT,
  calcom_event_type_id TEXT,
  whatsapp_provider TEXT,
  whatsapp_phone_id TEXT,
  notification_email TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.workspace_settings TO authenticated;
GRANT ALL ON public.workspace_settings TO service_role;

ALTER TABLE public.workspace_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY ws_settings_select ON public.workspace_settings FOR SELECT TO authenticated
  USING (is_workspace_member(workspace_id, auth.uid()));
CREATE POLICY ws_settings_insert ON public.workspace_settings FOR INSERT TO authenticated
  WITH CHECK (workspace_role_of(workspace_id, auth.uid()) IN ('owner','admin'));
CREATE POLICY ws_settings_update ON public.workspace_settings FOR UPDATE TO authenticated
  USING (workspace_role_of(workspace_id, auth.uid()) IN ('owner','admin'));

CREATE TRIGGER ws_settings_set_updated_at BEFORE UPDATE ON public.workspace_settings
  FOR EACH ROW EXECUTE FUNCTION public.tg_set_updated_at();