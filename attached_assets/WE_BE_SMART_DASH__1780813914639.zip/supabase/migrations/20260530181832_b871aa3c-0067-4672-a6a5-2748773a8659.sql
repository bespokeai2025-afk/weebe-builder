ALTER TABLE public.workspace_settings
  ADD COLUMN IF NOT EXISTS builder_base_url text,
  ADD COLUMN IF NOT EXISTS builder_api_token text,
  ADD COLUMN IF NOT EXISTS builder_last_synced_at timestamptz,
  ADD COLUMN IF NOT EXISTS builder_last_sync_status text;