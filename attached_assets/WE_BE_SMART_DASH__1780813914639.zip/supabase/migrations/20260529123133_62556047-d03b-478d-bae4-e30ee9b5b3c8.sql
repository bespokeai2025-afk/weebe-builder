
REVOKE EXECUTE ON FUNCTION public.has_role(UUID, public.app_role) FROM authenticated;
REVOKE EXECUTE ON FUNCTION public.is_workspace_member(UUID, UUID) FROM authenticated;
REVOKE EXECUTE ON FUNCTION public.workspace_role_of(UUID, UUID) FROM authenticated;
