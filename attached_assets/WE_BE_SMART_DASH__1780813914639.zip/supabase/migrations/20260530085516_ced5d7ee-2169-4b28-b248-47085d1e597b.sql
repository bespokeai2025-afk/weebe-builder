-- Per-workspace API tokens for external integrations (Agent Builder, etc.)
-- Plaintext token is shown ONCE at creation; we store only a SHA-256 hash.

CREATE TABLE public.workspace_api_tokens (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id UUID NOT NULL,
  name TEXT NOT NULL,
  prefix TEXT NOT NULL,           -- first 8 chars of the token, safe to display
  token_hash TEXT NOT NULL UNIQUE, -- sha256(plaintext) hex
  created_by UUID NOT NULL,
  last_used_at TIMESTAMPTZ,
  revoked_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX workspace_api_tokens_workspace_id_idx ON public.workspace_api_tokens(workspace_id);
CREATE INDEX workspace_api_tokens_token_hash_idx ON public.workspace_api_tokens(token_hash) WHERE revoked_at IS NULL;

GRANT SELECT, INSERT, UPDATE, DELETE ON public.workspace_api_tokens TO authenticated;
GRANT ALL ON public.workspace_api_tokens TO service_role;

ALTER TABLE public.workspace_api_tokens ENABLE ROW LEVEL SECURITY;

-- Only workspace owners/admins can manage tokens
CREATE POLICY api_tokens_select_admins ON public.workspace_api_tokens
  FOR SELECT TO authenticated
  USING (workspace_role_of(workspace_id, auth.uid()) IN ('owner','admin'));

CREATE POLICY api_tokens_insert_admins ON public.workspace_api_tokens
  FOR INSERT TO authenticated
  WITH CHECK (
    workspace_role_of(workspace_id, auth.uid()) IN ('owner','admin')
    AND created_by = auth.uid()
  );

CREATE POLICY api_tokens_update_admins ON public.workspace_api_tokens
  FOR UPDATE TO authenticated
  USING (workspace_role_of(workspace_id, auth.uid()) IN ('owner','admin'));

CREATE POLICY api_tokens_delete_admins ON public.workspace_api_tokens
  FOR DELETE TO authenticated
  USING (workspace_role_of(workspace_id, auth.uid()) IN ('owner','admin'));