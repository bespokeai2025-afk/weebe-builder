import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { autofixCalcomBooking } from "@/lib/providers/retell/calcom-autofix.server";

/**
 * Workspace-scoped agent CRUD. All access is gated by RLS via
 * `is_workspace_member(workspace_id, auth.uid())`.
 *
 * Shape mirrors the builder app's `agents` table: flow_data / settings /
 * variables JSON columns, plus an optional retell_agent_id and a
 * cost_seconds counter for usage tracking.
 */

const JsonValue: z.ZodType<unknown> = z.lazy(() =>
  z.union([z.string(), z.number(), z.boolean(), z.null(), z.array(JsonValue), z.record(z.string(), JsonValue)]),
);

export const listMyAgents = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase } = context;
    const { data, error } = await supabase
      .from("agents")
      .select(
        "id, workspace_id, name, agent_type, inbound_phone_number, retell_agent_id, retell_conversation_flow_id, cost_seconds, settings, updated_at, created_at",
      )
      .order("updated_at", { ascending: false });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const getMyAgent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ context, data }) => {
    const { supabase } = context;
    const { data: row, error } = await supabase
      .from("agents")
      .select("*")
      .eq("id", data.id)
      .maybeSingle();
    if (error) throw new Error(error.message);
    return row;
  });

export const upsertMyAgent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        id: z.string().uuid().optional(),
        workspaceId: z.string().uuid(),
        name: z.string().min(1).max(200),
        retellAgentId: z.string().nullable().optional(),
        flowData: JsonValue,
        settings: JsonValue,
        variables: JsonValue,
        costSeconds: z.number().int().nonnegative().optional(),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    const base = {
      workspace_id: data.workspaceId,
      user_id: userId,
      name: data.name,
      retell_agent_id: data.retellAgentId ?? null,
      flow_data: data.flowData as never,
      settings: data.settings as never,
      variables: data.variables as never,
      ...(typeof data.costSeconds === "number" ? { cost_seconds: data.costSeconds } : {}),
    };

    if (data.id) {
      const { data: row, error } = await supabase
        .from("agents")
        .update(base)
        .eq("id", data.id)
        .select("id")
        .maybeSingle();
      if (error) throw new Error(error.message);
      return { id: (row?.id as string) ?? data.id };
    }
    const { data: row, error } = await supabase
      .from("agents")
      .insert(base)
      .select("id")
      .maybeSingle();
    if (error) throw new Error(error.message);
    return { id: row!.id as string };
  });

export const deleteMyAgent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ context, data }) => {
    const { supabase } = context;
    const { error } = await supabase.from("agents").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/**
 * Auto-fix the Cal.com booking tool on a deployed Retell agent: inject
 * cal_api_key + event_type_id from workspace settings, harden the tool
 * description to require attendee_email/phone, and default the agent's
 * attendee_phone dynamic variable to {{from_number}}.
 */
export const autoFixBookingTool = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({ agentId: z.string().uuid() }).parse(input),
  )
  .handler(async ({ context, data }) => {
    const { supabase } = context;
    const { data: row, error } = await supabase
      .from("agents")
      .select("id, workspace_id, retell_agent_id, retell_conversation_flow_id")
      .eq("id", data.agentId)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!row) throw new Error("Agent not found");
    if (!row.retell_agent_id) throw new Error("Agent is not linked to Retell yet.");
    return autofixCalcomBooking({
      workspaceId: row.workspace_id as string,
      retellAgentId: row.retell_agent_id as string,
      retellConversationFlowId: (row.retell_conversation_flow_id as string | null) ?? null,
    });
  });

/**
 * Link (or unlink) a local agent to an existing Retell agent by ID.
 * This is what powers the "Go Live" button in the agent builder — the
 * user pastes the Retell agent ID from their Retell dashboard and the
 * record is marked deployed. Pass `null` (or empty string) to unlink.
 */
export const linkAgentToRetell = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        id: z.string().uuid(),
        retellAgentId: z
          .string()
          .trim()
          .max(200)
          .nullable()
          .transform((v) => (v && v.length > 0 ? v : null)),
        agentType: z.enum(["lead_gen", "receptionist"]).optional(),
        inboundPhoneNumber: z
          .string()
          .trim()
          .max(32)
          .nullable()
          .optional()
          .transform((v) => (v && v.length > 0 ? v : null)),
        retellConversationFlowId: z
          .string()
          .trim()
          .max(200)
          .nullable()
          .optional()
          .transform((v) => (v && v.length > 0 ? v : null)),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    const patch = {
      retell_agent_id: data.retellAgentId,
      ...(data.agentType ? { agent_type: data.agentType } : {}),
      ...(data.inboundPhoneNumber !== undefined
        ? { inbound_phone_number: data.inboundPhoneNumber }
        : {}),
      ...(data.retellConversationFlowId !== undefined
        ? { retell_conversation_flow_id: data.retellConversationFlowId }
        : {}),
    };

    const { data: row, error } = await supabase
      .from("agents")
      .update(patch)
      .eq("id", data.id)
      .select("id, workspace_id, retell_agent_id, agent_type, inbound_phone_number")
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!row) throw new Error("Agent not found");

    // Audit trail in deployments so the dashboard reflects the action.
    await supabase.from("deployments").insert({
      agent_id: row.id as string,
      workspace_id: row.workspace_id as string,
      provider: "retell",
      provider_agent_id: data.retellAgentId,
      provider_flow_id: data.retellConversationFlowId ?? null,
      status: data.retellAgentId ? "success" : "error",
      error: data.retellAgentId ? null : "unlinked",
      deployed_by: userId,
      payload: {
        agent_type: row.agent_type,
        inbound_phone_number: row.inbound_phone_number,
      } as never,
    });

    return {
      id: row.id as string,
      retell_agent_id: row.retell_agent_id as string | null,
      agent_type: row.agent_type as "lead_gen" | "receptionist",
      inbound_phone_number: row.inbound_phone_number as string | null,
    };
  });

export const listMyDeployments = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase } = context;
    const { data, error } = await supabase
      .from("deployments")
      .select("id, agent_id, workspace_id, provider, provider_agent_id, status, error, deployed_at, deployed_by")
      .order("deployed_at", { ascending: false })
      .limit(100);
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const getDashboardStats = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase } = context;
    const [agentsRes, deploysRes] = await Promise.all([
      supabase.from("agents").select("id, retell_agent_id, cost_seconds, updated_at"),
      supabase
        .from("deployments")
        .select("id, status, deployed_at")
        .order("deployed_at", { ascending: false })
        .limit(50),
    ]);
    if (agentsRes.error) throw new Error(agentsRes.error.message);
    if (deploysRes.error) throw new Error(deploysRes.error.message);
    const agents = agentsRes.data ?? [];
    const deploys = deploysRes.data ?? [];
    const totalSeconds = agents.reduce(
      (acc, a) => acc + ((a.cost_seconds as number | null) ?? 0),
      0,
    );
    return {
      agentCount: agents.length,
      deployedCount: agents.filter((a) => a.retell_agent_id).length,
      deploymentCount: deploys.length,
      successCount: deploys.filter((d) => d.status === "success").length,
      errorCount: deploys.filter((d) => d.status === "error").length,
      totalSeconds,
    };
  });

/** Record a deployment audit row. Used by the orchestration deploy fn. */
export const recordDeployment = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        agentId: z.string().uuid(),
        workspaceId: z.string().uuid(),
        provider: z.string().default("retell"),
        providerAgentId: z.string().optional(),
        providerFlowId: z.string().optional(),
        status: z.enum(["success", "error"]).default("success"),
        payload: JsonValue.optional(),
        error: z.string().optional(),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    const { error } = await supabase.from("deployments").insert({
      agent_id: data.agentId,
      workspace_id: data.workspaceId,
      provider: data.provider,
      provider_agent_id: data.providerAgentId ?? null,
      provider_flow_id: data.providerFlowId ?? null,
      status: data.status,
      payload: (data.payload ?? null) as never,
      error: data.error ?? null,
      deployed_by: userId,
    });
    if (error) throw new Error(error.message);
    return { ok: true };
  });