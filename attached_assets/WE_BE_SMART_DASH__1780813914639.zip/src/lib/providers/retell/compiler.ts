/**
 * Compile an internal IR Agent + Workflow into the shape Retell expects.
 *
 * This is the "provider adapter" for Retell. The output is a plain JSON
 * payload ready to POST to Retell's create/update endpoints. No network
 * calls happen here — this module is pure so it is easy to unit-test and
 * runs in any environment.
 *
 * The mapping deliberately covers the common node kinds used by 95% of
 * deployments. The exporter project (Lovable "Retell AI Exporter") owns
 * the long-tail edge cases (round-trip raw fields, SIP headers, agentic
 * warm transfers with sub-agent IDs, etc.). Port those overlays into this
 * compiler when the orchestration layer needs them.
 */
import type {
  IRAgent,
  IRNode,
  IRToolDefinition,
  IRTransition,
  IRWorkflow,
} from "@/lib/orchestration/ir";

type RetellEdge = {
  id: string;
  destination_node_id?: string;
  transition_condition: { type: "prompt"; prompt: string };
};

type RetellNode = Record<string, unknown> & { id: string; type: string };

export interface CompiledRetellPayload {
  agent: Record<string, unknown>;
  conversationFlow: Record<string, unknown>;
}

/**
 * Public entry point. Pure, side-effect-free.
 */
export function compileAgentToRetell(
  agent: IRAgent,
  tools: IRToolDefinition[] = [],
): CompiledRetellPayload {
  const conversationFlow = compileWorkflowToRetell(agent.workflow, agent, tools);

  const retellAgent: Record<string, unknown> = {
    agent_name: agent.name,
    language: agent.voice.language,
    voice_id: agent.voice.voiceId,
    voice_speed: agent.voice.voiceSpeed,
    voice_temperature: agent.voice.voiceTemperature,
    volume: agent.voice.volume,
    responsiveness: agent.voice.responsiveness,
    interruption_sensitivity: agent.voice.interruptionSensitivity,
    voice_emotion: agent.voice.voiceEmotion === "none" ? null : agent.voice.voiceEmotion,
    max_call_duration_ms: agent.maxCallDurationMs,
    response_engine: {
      type: "conversation-flow",
      version: 0,
      conversation_flow_id: conversationFlow.conversation_flow_id,
    },
  };
  if (agent.beginMessage) retellAgent.begin_message = agent.beginMessage;
  if (agent.webhookUrl) retellAgent.webhook_url = agent.webhookUrl;

  return { agent: retellAgent, conversationFlow };
}

export function compileWorkflowToRetell(
  workflow: IRWorkflow,
  agent: IRAgent,
  tools: IRToolDefinition[],
): Record<string, unknown> {
  const validIds = new Set(workflow.nodes.map((n) => n.id));
  const startNode =
    workflow.nodes.find((n) => n.isStart) ??
    workflow.nodes.find((n) => n.kind === "conversation") ??
    workflow.nodes[0];

  const retellTools = tools.map(compileToolToRetell);
  const toolKeyToId = new Map(tools.map((t) => [t.key, t.key]));

  const retellNodes = workflow.nodes.map((n) =>
    compileNode(n, edgesFromNode(workflow, n.id, validIds), toolKeyToId),
  );

  return {
    conversation_flow_id:
      workflow.id ?? `cf_${Math.random().toString(16).slice(2, 14)}`,
    version: 0,
    global_prompt: workflow.globalPrompt,
    start_node_id: startNode?.id ?? retellNodes[0]?.id ?? "",
    start_speaker: workflow.startSpeaker,
    model_choice: {
      type: "cascading",
      high_priority: false,
      model: agent.model,
    },
    nodes: retellNodes,
    tools: retellTools,
    knowledge_base_ids: [],
    tool_call_strict_mode: true,
    is_transfer_cf: false,
    is_published: false,
  };
}

// ---------- Edge reconciliation ----------

function edgesFromNode(
  workflow: IRWorkflow,
  nodeId: string,
  validIds: Set<string>,
): RetellEdge[] {
  const node = workflow.nodes.find((n) => n.id === nodeId);
  if (!node) return [];

  const graphEdges = workflow.edges.filter(
    (e) => e.source === nodeId && validIds.has(e.target),
  );
  const transitionIds = new Set(node.transitions.map((t) => t.id));

  const transitionEdges: RetellEdge[] = node.transitions
    .filter((t) => !t.target || validIds.has(t.target))
    .map((t, i) => buildTransitionEdge(t, graphEdges, nodeId, i));

  const extraEdges: RetellEdge[] = graphEdges
    .filter((e) => !transitionIds.has(String(e.sourceHandle ?? "")))
    .map((e, i) => ({
      id: e.id || `edge-${nodeId}-extra-${i}`,
      destination_node_id: e.target,
      transition_condition: { type: "prompt", prompt: "Continue" },
    }));

  return [...transitionEdges, ...extraEdges];
}

function buildTransitionEdge(
  t: IRTransition,
  graphEdges: IRWorkflow["edges"],
  nodeId: string,
  i: number,
): RetellEdge {
  const graphEdge =
    graphEdges.find((e) => e.sourceHandle === t.id) ??
    graphEdges.find((e) => t.target && e.target === t.target);
  return {
    id: graphEdge?.id || t.id || `edge-${nodeId}-${i}`,
    ...(t.target ? { destination_node_id: t.target } : {}),
    transition_condition: { type: "prompt", prompt: t.condition },
  };
}

// ---------- Per-kind node compilation ----------

function compileNode(
  node: IRNode,
  edges: RetellEdge[],
  toolKeyToId: Map<string, string>,
): RetellNode {
  const base = {
    id: node.id,
    name: node.label,
    display_position: node.position,
  };

  switch (node.kind) {
    case "conversation":
      return {
        ...base,
        type: "conversation",
        ...(node.isStart && node.startSpeaker
          ? { start_speaker: node.startSpeaker }
          : {}),
        instruction: {
          type: node.instructionType,
          text: node.prompt ?? "",
        },
        edges,
      };

    case "tool":
      return {
        ...base,
        type: "function",
        tool_id: toolKeyToId.get(node.toolRef) ?? node.toolRef,
        tool_type: "local",
        speak_during_execution: node.speakDuringExecution,
        wait_for_result: node.waitForResult,
        edges,
      };

    case "call_transfer":
      return compileCallTransferNode(node, base, edges);

    case "qualification":
      return {
        ...base,
        type: "extract_dynamic_variables",
        instruction: {
          type: "prompt",
          text:
            node.prompt ?? "Extract the variables below from the conversation.",
        },
        variables: node.variables.map((v) => ({
          name: v.name,
          description: v.description,
          type: v.type,
          ...(v.type === "enum" && v.choices?.length ? { choices: v.choices } : {}),
        })),
        edges,
      };

    case "logic": {
      const elseIdx = edges.findIndex(
        (e) => !e.transition_condition.prompt ||
          /^(else|otherwise)$/i.test(e.transition_condition.prompt),
      );
      const idx = elseIdx >= 0 ? elseIdx : edges.length - 1;
      const elseEdge: RetellEdge =
        idx >= 0
          ? {
              ...edges[idx],
              transition_condition: { type: "prompt", prompt: "Else" },
            }
          : {
              id: `edge-${node.id}-else`,
              transition_condition: { type: "prompt", prompt: "Else" },
            };
      const mainEdges = idx >= 0 ? edges.filter((_, i) => i !== idx) : edges;
      return {
        ...base,
        type: "branch",
        instruction: { type: "prompt", text: node.prompt ?? "" },
        edges: mainEdges,
        else_edge: elseEdge,
      };
    }

    case "end_call":
      return {
        ...base,
        type: "end",
        instruction: {
          type: "prompt",
          text: node.endingPrompt ?? node.prompt ?? "End the call politely.",
        },
      };
  }
}

function compileCallTransferNode(
  node: Extract<IRNode, { kind: "call_transfer" }>,
  base: { id: string; name: string; display_position: { x: number; y: number } },
  edges: RetellEdge[],
): RetellNode {
  const transfer_destination =
    node.transferMode === "dynamic"
      ? { type: "inferred", prompt: node.destination }
      : { type: "predefined", number: node.destination };

  const transfer_option: Record<string, unknown> = {
    type: node.transferType,
    show_transferee_as_caller: node.showTransfereeAsCaller,
    ...(node.ringDurationSec
      ? { transfer_ring_duration_ms: node.ringDurationSec * 1000 }
      : {}),
  };

  if (node.transferType === "warm_transfer" && node.warmHandoffPrompt) {
    transfer_option.public_handoff_option = {
      type: "prompt",
      prompt: node.warmHandoffPrompt,
    };
    transfer_option.on_hold_music = "ringtone";
  }

  // Retell requires `edge` (transfer-failed fallback) on transfer_call nodes.
  const failedEdge: RetellEdge = edges[0]
    ? { ...edges[0], transition_condition: { type: "prompt", prompt: "Transfer failed" } }
    : {
        id: `edge-${node.id}-transfer-failed`,
        transition_condition: { type: "prompt", prompt: "Transfer failed" },
      };

  return {
    ...base,
    type: "transfer_call",
    transfer_destination,
    transfer_option,
    speak_during_execution: false,
    edge: failedEdge,
  };
}

// ---------- Tool compilation ----------

function compileToolToRetell(tool: IRToolDefinition): Record<string, unknown> {
  const common = {
    tool_id: tool.key,
    name: tool.key,
    description: tool.description,
    speak_during_execution: tool.speakDuringExecution,
  };

  switch (tool.kind) {
    case "builtin":
      // Caller-supplied native Retell tool name (e.g. "end_call").
      return { ...common, type: tool.name };
    case "calcom":
      // Cal.com presets are usually expanded by the deploy step with the
      // workspace's API key — keep a generic "custom" stub here.
      return {
        ...common,
        type: "custom",
        url: tool.url,
        parameters: tool.parameters,
      };
    case "http":
    case "crm":
    default:
      return {
        ...common,
        type: "custom",
        url: tool.url,
        parameters: tool.parameters,
      };
  }
}