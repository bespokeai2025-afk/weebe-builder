/**
 * High-level Retell adapter. Takes an internal IR Agent, compiles it to
 * the Retell payload shape, and pushes it to the Retell API.
 *
 * Two-step deploy (matches Retell's API surface):
 *   1. Create / update the conversation flow.
 *   2. Create / update the agent that references the flow.
 *
 * Returns the provider ids + raw response for the caller to persist in
 * the `deployments` table.
 */
import {
  compileAgentToRetell,
  type CompiledRetellPayload,
} from "./compiler";
import type { IRAgent, IRToolDefinition } from "@/lib/orchestration/ir";
import { retellFetch, stripReadOnlyKeys, redactPayload } from "./client.server";

export interface DeployRetellInput {
  agent: IRAgent;
  tools?: IRToolDefinition[];
  /** Existing Retell agent id — when present we PATCH instead of POST. */
  retellAgentId?: string;
  /** Existing Retell conversation flow id — same idea. */
  retellConversationFlowId?: string;
  /** Optional per-workspace override (otherwise reads RETELL_API_KEY). */
  apiKey?: string;
}

export interface DeployRetellResult {
  retellAgentId: string;
  retellConversationFlowId: string;
  agentResponse: Record<string, unknown>;
  flowResponse: Record<string, unknown>;
  /** What we sent — useful for debugging compiler output. */
  compiled: CompiledRetellPayload;
}

export async function deployAgentToRetell(
  input: DeployRetellInput,
): Promise<DeployRetellResult> {
  const compiled = compileAgentToRetell(input.agent, input.tools ?? []);

  // ---- Step 1: conversation flow ----
  const flowBody = stripReadOnlyKeys(compiled.conversationFlow);

  let flowResponse: Record<string, unknown>;
  if (input.retellConversationFlowId) {
    flowResponse = await retellFetch(
      `/update-conversation-flow/${input.retellConversationFlowId}`,
      flowBody,
      "PATCH",
      input.apiKey,
    );
  } else {
    flowResponse = await retellFetch(
      "/create-conversation-flow",
      flowBody,
      "POST",
      input.apiKey,
    );
  }

  const flowId =
    String(flowResponse.conversation_flow_id ?? "") ||
    String(compiled.conversationFlow.conversation_flow_id ?? "");
  if (!flowId) {
    console.error("[retell-deploy] flow id missing", redactPayload(flowResponse));
    throw new Error("Retell did not return a conversation_flow_id");
  }

  // ---- Step 2: agent referencing the flow ----
  const agentBody: Record<string, unknown> = stripReadOnlyKeys({
    ...compiled.agent,
    response_engine: {
      type: "conversation-flow",
      version: 0,
      conversation_flow_id: flowId,
    },
  });

  let agentResponse: Record<string, unknown>;
  if (input.retellAgentId) {
    agentResponse = await retellFetch(
      `/update-agent/${input.retellAgentId}`,
      agentBody,
      "PATCH",
      input.apiKey,
    );
  } else {
    agentResponse = await retellFetch(
      "/create-agent",
      agentBody,
      "POST",
      input.apiKey,
    );
  }

  const retellAgentId =
    String(agentResponse.agent_id ?? input.retellAgentId ?? "");
  if (!retellAgentId) {
    console.error("[retell-deploy] agent id missing", redactPayload(agentResponse));
    throw new Error("Retell did not return an agent_id");
  }

  return {
    retellAgentId,
    retellConversationFlowId: flowId,
    agentResponse,
    flowResponse,
    compiled,
  };
}