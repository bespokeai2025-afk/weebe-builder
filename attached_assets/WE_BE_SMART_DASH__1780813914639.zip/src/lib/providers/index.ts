/**
 * Provider registry. The orchestration layer treats every voice provider
 * as a pluggable adapter — Retell today, Vapi / Bland / others tomorrow.
 *
 * The registry stays minimal on purpose: provider name + capabilities.
 * Adapter modules live under `src/lib/providers/<name>/` and are imported
 * lazily from server functions so we don't ship Retell types to the
 * browser bundle.
 */
export type ProviderKey = "retell";

export interface ProviderDescriptor {
  key: ProviderKey;
  label: string;
  /** What this provider supports — the dashboard hides controls otherwise. */
  capabilities: {
    conversationFlow: boolean;
    callTransfer: boolean;
    qualification: boolean;
    customTools: boolean;
    calcomBookingTools: boolean;
  };
}

export const PROVIDERS: Record<ProviderKey, ProviderDescriptor> = {
  retell: {
    key: "retell",
    label: "Retell AI",
    capabilities: {
      conversationFlow: true,
      callTransfer: true,
      qualification: true,
      customTools: true,
      calcomBookingTools: true,
    },
  },
};

export function getProvider(key: ProviderKey): ProviderDescriptor {
  const p = PROVIDERS[key];
  if (!p) throw new Error(`Unknown provider: ${key}`);
  return p;
}