import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const getMyContext = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;

    const { data: profile, error: pErr } = await supabase
      .from("profiles")
      .select("id,email,full_name,default_workspace_id")
      .eq("id", userId)
      .single();
    if (pErr) throw new Error(pErr.message);

    const { data: memberships, error: mErr } = await supabase
      .from("workspace_members")
      .select("role,workspace:workspaces(id,name,slug,owner_id,created_at)")
      .eq("user_id", userId);
    if (mErr) throw new Error(mErr.message);

    return {
      profile,
      workspaces: (memberships ?? []).map((m: any) => ({
        ...m.workspace,
        role: m.role,
      })),
    };
  });