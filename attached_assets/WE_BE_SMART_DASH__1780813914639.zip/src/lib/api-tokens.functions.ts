/**
 * Workspace API tokens: mint / list / revoke.
 *
 * Plaintext token is returned exactly once on create. We store only
 * sha256(plaintext) so a DB leak doesn't expose live integration credentials.
 */
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { createHash, randomBytes } from "crypto";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

function sha256Hex(input: string): string {
  return createHash("sha256").update(input).digest("hex");
}

function generateToken(): { plaintext: string; prefix: string; hash: string } {
  const raw = randomBytes(32).toString("base64url");
  const plaintext = `lvb_${raw}`;
  return {
    plaintext,
    prefix: plaintext.slice(0, 12),
    hash: sha256Hex(plaintext),
  };
}

export const listWorkspaceApiTokens = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({ workspaceId: z.string().uuid() }).parse(input),
  )
  .handler(async ({ context, data }) => {
    const { supabase } = context;
    const { data: rows, error } = await supabase
      .from("workspace_api_tokens")
      .select("id, workspace_id, name, prefix, created_by, last_used_at, revoked_at, created_at")
      .eq("workspace_id", data.workspaceId)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

export const createWorkspaceApiToken = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        workspaceId: z.string().uuid(),
        name: z.string().min(1).max(80),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    const { plaintext, prefix, hash } = generateToken();
    const { data: row, error } = await supabase
      .from("workspace_api_tokens")
      .insert({
        workspace_id: data.workspaceId,
        name: data.name,
        prefix,
        token_hash: hash,
        created_by: userId,
      } as never)
      .select("id, name, prefix, created_at")
      .single();
    if (error) throw new Error(error.message);
    return { ...row, plaintext };
  });

export const revokeWorkspaceApiToken = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({ id: z.string().uuid() }).parse(input),
  )
  .handler(async ({ context, data }) => {
    const { supabase } = context;
    const { error } = await supabase
      .from("workspace_api_tokens")
      .update({ revoked_at: new Date().toISOString() } as never)
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });