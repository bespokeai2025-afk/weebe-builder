import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { retellFetch } from "@/lib/providers/retell/client.server";

/**
 * Workspace-scoped server functions for the user-facing dashboard
 * (leads, calls, calendar bookings, whatsapp, data, settings).
 * All access is gated by RLS via is_workspace_member().
 */

function getPrimaryWorkspaceId(memberships: { workspace_id: string }[]): string {
  if (!memberships.length) throw new Error("No workspace");
  return memberships[0].workspace_id;
}

async function resolveWorkspaceId(supabase: any, userId: string): Promise<string> {
  const { data, error } = await supabase
    .from("workspace_members")
    .select("workspace_id, created_at")
    .eq("user_id", userId)
    .order("created_at", { ascending: true })
    .limit(1);
  if (error) throw new Error(error.message);
  return getPrimaryWorkspaceId(data ?? []);
}

// ============= DASHBOARD STATS =============
export const getOverviewStats = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const workspaceId = await resolveWorkspaceId(supabase, userId);

    const [leadsRes, callsRes, bookingsRes, qualifiedRes] = await Promise.all([
      supabase.from("leads").select("id, status, created_at", { count: "exact", head: false }).eq("workspace_id", workspaceId),
      supabase.from("calls").select("id, call_status, duration_seconds, started_at").eq("workspace_id", workspaceId),
      supabase.from("calendar_bookings").select("id, status, start_at").eq("workspace_id", workspaceId),
      supabase.from("leads").select("id").eq("workspace_id", workspaceId).in("status", ["interested", "qualified"]),
    ]);

    if (leadsRes.error) throw new Error(leadsRes.error.message);
    if (callsRes.error) throw new Error(callsRes.error.message);
    if (bookingsRes.error) throw new Error(bookingsRes.error.message);

    const leads = leadsRes.data ?? [];
    const calls = callsRes.data ?? [];
    const bookings = bookingsRes.data ?? [];
    const now = Date.now();

    return {
      workspaceId,
      totals: {
        leads: leads.length,
        qualified: (qualifiedRes.data ?? []).length,
        calls: calls.length,
        callsCompleted: calls.filter((c: any) => c.call_status === "completed").length,
        callsFailed: calls.filter((c: any) => ["failed", "no_answer", "busy"].includes(c.call_status)).length,
        totalCallSeconds: calls.reduce((acc: number, c: any) => acc + (c.duration_seconds ?? 0), 0),
        bookings: bookings.length,
        upcomingBookings: bookings.filter((b: any) => new Date(b.start_at).getTime() > now && b.status !== "cancelled").length,
        pendingBookings: bookings.filter((b: any) => b.status === "pending").length,
        cancelledBookings: bookings.filter((b: any) => b.status === "cancelled").length,
      },
      recentLeads: leads.slice(-5).reverse(),
    };
  });

// ============= LEADS =============
export const listLeads = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      status: z.string().optional(),
      qualifiedOnly: z.boolean().optional(),
      search: z.string().optional(),
      limit: z.number().int().min(1).max(500).default(100),
    }).parse(input ?? {}),
  )
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    const workspaceId = await resolveWorkspaceId(supabase, userId);
    let q = supabase
      .from("leads")
      .select("*")
      .eq("workspace_id", workspaceId)
      .order("updated_at", { ascending: false })
      .limit(data.limit);
    if (data.qualifiedOnly) q = q.in("status", ["interested", "qualified"]);
    if (data.status && data.status !== "all") q = q.eq("status", data.status as any);
    if (data.search) q = q.or(`full_name.ilike.%${data.search}%,phone.ilike.%${data.search}%,email.ilike.%${data.search}%`);
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

export const upsertLead = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      id: z.string().uuid().optional(),
      full_name: z.string().nullable().optional(),
      phone: z.string().min(3).max(40),
      email: z.string().email().nullable().optional().or(z.literal("")),
      company_name: z.string().nullable().optional(),
      status: z.string().optional(),
      source: z.string().optional(),
      funding_amount: z.number().nullable().optional(),
      notes: z.string().nullable().optional(),
    }).parse(input),
  )
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    const workspaceId = await resolveWorkspaceId(supabase, userId);
    const payload: any = {
      workspace_id: workspaceId,
      full_name: data.full_name ?? null,
      phone: data.phone,
      email: data.email || null,
      company_name: data.company_name ?? null,
      funding_amount: data.funding_amount ?? null,
      notes: data.notes ?? null,
      ...(data.status ? { status: data.status } : {}),
      ...(data.source ? { source: data.source } : {}),
    };
    if (data.id) {
      const { error } = await supabase.from("leads").update(payload).eq("id", data.id);
      if (error) throw new Error(error.message);
      return { id: data.id };
    }
    const { data: row, error } = await supabase.from("leads").insert(payload).select("id").single();
    if (error) throw new Error(error.message);
    return { id: row!.id as string };
  });

export const deleteLead = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ context, data }) => {
    const { supabase } = context;
    const { error } = await supabase.from("leads").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// ============= CALLS =============
export const listCalls = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      status: z.string().optional(),
      direction: z.enum(["inbound", "outbound"]).optional(),
      limit: z.number().int().min(1).max(500).default(100),
    }).parse(input ?? {}),
  )
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    const workspaceId = await resolveWorkspaceId(supabase, userId);
    let q = supabase
      .from("calls")
      .select("*, lead:leads(id, full_name, phone)")
      .eq("workspace_id", workspaceId)
      .order("started_at", { ascending: false, nullsFirst: false })
      .limit(data.limit);
    if (data.status && data.status !== "all") q = q.eq("call_status", data.status as any);
    if (data.direction) q = q.eq("call_type", data.direction as any);
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

// ============= CALENDAR BOOKINGS =============
export const listBookings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      status: z.string().optional(),
      from: z.string().optional(),
      to: z.string().optional(),
      limit: z.number().int().min(1).max(500).default(200),
    }).parse(input ?? {}),
  )
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    const workspaceId = await resolveWorkspaceId(supabase, userId);
    let q = supabase
      .from("calendar_bookings")
      .select("*")
      .eq("workspace_id", workspaceId)
      .order("start_at", { ascending: true })
      .limit(data.limit);
    if (data.status && data.status !== "all") q = q.eq("status", data.status as any);
    if (data.from) q = q.gte("start_at", data.from);
    if (data.to) q = q.lte("start_at", data.to);
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

export const upsertBooking = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      id: z.string().uuid().optional(),
      title: z.string().min(1).max(200),
      attendee_name: z.string().nullable().optional(),
      attendee_email: z.string().email().nullable().optional().or(z.literal("")),
      start_at: z.string(),
      end_at: z.string(),
      status: z.string().optional(),
      notes: z.string().nullable().optional(),
    }).parse(input),
  )
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    const workspaceId = await resolveWorkspaceId(supabase, userId);
    const payload: any = {
      workspace_id: workspaceId,
      source: "manual",
      title: data.title,
      attendee_name: data.attendee_name ?? null,
      attendee_email: data.attendee_email || null,
      start_at: data.start_at,
      end_at: data.end_at,
      notes: data.notes ?? null,
      ...(data.status ? { status: data.status } : {}),
    };
    if (data.id) {
      const { error } = await supabase.from("calendar_bookings").update(payload).eq("id", data.id);
      if (error) throw new Error(error.message);
      return { id: data.id };
    }
    const { data: row, error } = await supabase.from("calendar_bookings").insert(payload).select("id").single();
    if (error) throw new Error(error.message);
    return { id: row!.id as string };
  });

// ============= CAL.COM BOOKINGS (live) =============
type UnifiedBooking = {
  id: string;
  source: "calcom" | "local";
  title: string;
  start_at: string;
  end_at: string | null;
  status: string;
  attendee_name: string | null;
  attendee_email: string | null;
  meeting_url: string | null;
};

function normalizeCalcomStatus(s: string | null | undefined): string {
  const v = (s ?? "").toString().toLowerCase();
  if (v === "accepted") return "confirmed";
  if (v === "rejected" || v === "cancelled" || v === "canceled") return "cancelled";
  if (v === "pending") return "pending";
  return v || "confirmed";
}

export const listCalendarBookings = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const workspaceId = await resolveWorkspaceId(supabase, userId);

    const [{ data: settings, error: sErr }, { data: localRows, error: lErr }] = await Promise.all([
      supabase
        .from("workspace_settings")
        .select("calcom_api_token, calcom_event_type_id")
        .eq("workspace_id", workspaceId)
        .maybeSingle(),
      supabase
        .from("calendar_bookings")
        .select("*")
        .eq("workspace_id", workspaceId)
        .order("start_at", { ascending: true })
        .limit(500),
    ]);
    if (sErr) throw new Error(sErr.message);
    if (lErr) throw new Error(lErr.message);

    const local: UnifiedBooking[] = ((localRows ?? []) as any[]).map((b) => ({
      id: `local:${b.id}`,
      source: "local" as const,
      title: b.title,
      start_at: b.start_at,
      end_at: b.end_at ?? null,
      status: b.status,
      attendee_name: b.attendee_name ?? null,
      attendee_email: b.attendee_email ?? null,
      meeting_url: b.meeting_url ?? null,
    }));

    const token = settings?.calcom_api_token ?? null;
    let calcom: UnifiedBooking[] = [];
    let calcomError: string | null = null;
    const calcomConfigured = Boolean(token);

    if (token) {
      try {
        const url = new URL("https://api.cal.com/v1/bookings");
        url.searchParams.set("apiKey", token);
        const res = await fetch(url.toString(), {
          method: "GET",
          headers: { Accept: "application/json" },
        });
        if (!res.ok) {
          const body = await res.text().catch(() => "");
          calcomError = `Cal.com API ${res.status}: ${body.slice(0, 200) || res.statusText}`;
        } else {
          const payload: any = await res.json();
          const list: any[] = Array.isArray(payload?.bookings)
            ? payload.bookings
            : Array.isArray(payload)
              ? payload
              : [];
          calcom = list.map((b: any) => {
            const attendee = Array.isArray(b.attendees) && b.attendees.length > 0 ? b.attendees[0] : null;
            return {
              id: `calcom:${b.uid ?? b.id}`,
              source: "calcom" as const,
              title: b.title ?? b.eventType?.title ?? "Meeting",
              start_at: b.startTime ?? b.start ?? "",
              end_at: b.endTime ?? b.end ?? null,
              status: normalizeCalcomStatus(b.status),
              attendee_name: attendee?.name ?? null,
              attendee_email: attendee?.email ?? null,
              meeting_url:
                b.metadata?.videoCallUrl ??
                (typeof b.location === "string" ? b.location : null) ??
                (b.uid ? `https://app.cal.com/booking/${b.uid}` : null),
            };
          });
        }
      } catch (e: any) {
        calcomError = e?.message ?? "Cal.com request failed";
      }
    }

    const combined = [...calcom, ...local].filter((b) => !!b.start_at);
    combined.sort((a, b) => new Date(a.start_at).getTime() - new Date(b.start_at).getTime());

    return {
      bookings: combined,
      calcomConfigured,
      calcomError,
    };
  });

// ============= WHATSAPP =============
export const listWhatsappThreads = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const workspaceId = await resolveWorkspaceId(supabase, userId);
    const { data, error } = await supabase
      .from("whatsapp_messages")
      .select("*")
      .eq("workspace_id", workspaceId)
      .order("sent_at", { ascending: false })
      .limit(500);
    if (error) throw new Error(error.message);
    // Group by contact_phone
    const threads = new Map<string, { phone: string; name: string | null; lastMessage: string | null; lastAt: string; unread: number; messages: any[] }>();
    for (const m of (data ?? []) as any[]) {
      const existing = threads.get(m.contact_phone);
      if (!existing) {
        threads.set(m.contact_phone, {
          phone: m.contact_phone,
          name: m.contact_name,
          lastMessage: m.body,
          lastAt: m.sent_at,
          unread: 0,
          messages: [m],
        });
      } else {
        existing.messages.push(m);
      }
    }
    return Array.from(threads.values());
  });

// ============= DATA RECORDS =============
export const listDataRecords = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      search: z.string().optional(),
      activeOnly: z.boolean().optional(),
      callStatus: z
        .enum(["all", "needs_to_call", "queued", "calling", "completed", "failed", "do_not_call"])
        .optional(),
      assignedAgentId: z.string().uuid().nullable().optional(),
      unassignedOnly: z.boolean().optional(),
      limit: z.number().int().min(1).max(2000).default(500),
    }).parse(input ?? {}),
  )
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    const workspaceId = await resolveWorkspaceId(supabase, userId);
    let q = supabase
      .from("data_records")
      .select("*")
      .eq("workspace_id", workspaceId)
      .eq("is_deleted", false)
      .order("updated_at", { ascending: false })
      .limit(data.limit);
    if (data.activeOnly) q = q.eq("is_active", true);
    if (data.callStatus && data.callStatus !== "all") q = q.eq("call_status", data.callStatus);
    if (data.unassignedOnly) q = q.is("assigned_agent_id", null);
    else if (data.assignedAgentId) q = q.eq("assigned_agent_id", data.assignedAgentId);
    if (data.search) q = q.or(`name.ilike.%${data.search}%,mobile_number.ilike.%${data.search}%,email.ilike.%${data.search}%`);
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

// ============= DATA RECORD ACTIONS =============
const RecordIdsSchema = z.object({
  recordIds: z.array(z.string().uuid()).min(1).max(2000),
});

export const assignAgentToRecords = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    RecordIdsSchema.extend({
      agentId: z.string().uuid().nullable(),
    }).parse(input),
  )
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    const workspaceId = await resolveWorkspaceId(supabase, userId);
    const { error, count } = await supabase
      .from("data_records")
      .update({ assigned_agent_id: data.agentId }, { count: "exact" })
      .eq("workspace_id", workspaceId)
      .in("id", data.recordIds);
    if (error) throw new Error(error.message);
    return { updated: count ?? 0 };
  });

export const scheduleCallsForRecords = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    RecordIdsSchema.extend({
      scheduledAt: z.string().datetime().nullable(),
      agentId: z.string().uuid().nullable().optional(),
    }).parse(input),
  )
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    const workspaceId = await resolveWorkspaceId(supabase, userId);
    const patch: {
      scheduled_call_at: string | null;
      call_status: "queued" | "needs_to_call";
      assigned_agent_id?: string | null;
    } = {
      scheduled_call_at: data.scheduledAt,
      call_status: data.scheduledAt ? "queued" : "needs_to_call",
    };
    if (data.agentId !== undefined) patch.assigned_agent_id = data.agentId;
    const { error, count } = await supabase
      .from("data_records")
      .update(patch, { count: "exact" })
      .eq("workspace_id", workspaceId)
      .in("id", data.recordIds);
    if (error) throw new Error(error.message);
    return { updated: count ?? 0 };
  });

export const setRecordCallStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    RecordIdsSchema.extend({
      status: z.enum([
        "needs_to_call",
        "queued",
        "calling",
        "completed",
        "failed",
        "do_not_call",
      ]),
    }).parse(input),
  )
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    const workspaceId = await resolveWorkspaceId(supabase, userId);
    const patch = {
      call_status: data.status,
      need_to_call: data.status !== "do_not_call" && data.status !== "completed",
    };
    const { error, count } = await supabase
      .from("data_records")
      .update(patch, { count: "exact" })
      .eq("workspace_id", workspaceId)
      .in("id", data.recordIds);
    if (error) throw new Error(error.message);
    return { updated: count ?? 0 };
  });

/**
 * Start calling the selected data records.
 * If a record has an assigned agent with a linked retell_agent_id, we place
 * a real outbound call through Retell. Otherwise the record is queued so
 * the agent picks it up once linked.
 */
export const startCallingRecords = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    RecordIdsSchema.extend({
      agentId: z.string().uuid().nullable().optional(),
      fromNumber: z.string().min(3).max(32).nullable().optional(),
    }).parse(input),
  )
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    const workspaceId = await resolveWorkspaceId(supabase, userId);

    const { data: records, error } = await supabase
      .from("data_records")
      .select("id, mobile_number, assigned_agent_id, name")
      .eq("workspace_id", workspaceId)
      .in("id", data.recordIds);
    if (error) throw new Error(error.message);

    // Load all agents we might need (assigned + override) so we can map to retell_agent_id.
    const agentIds = Array.from(
      new Set(
        [
          data.agentId ?? null,
          ...(records ?? []).map((r: any) => r.assigned_agent_id),
        ].filter(Boolean) as string[],
      ),
    );
    let agentsById: Record<string, { retell_agent_id: string | null; name: string }> = {};
    if (agentIds.length) {
      const { data: ags, error: aErr } = await supabase
        .from("agents")
        .select("id, retell_agent_id, name")
        .in("id", agentIds);
      if (aErr) throw new Error(aErr.message);
      agentsById = Object.fromEntries((ags ?? []).map((a: any) => [a.id, a]));
    }

    let queued = 0;
    let placed = 0;
    let failed = 0;
    const errors: { recordId: string; message: string }[] = [];

    for (const r of records ?? []) {
      const useAgentId = (data.agentId ?? r.assigned_agent_id) as string | null;
      const agent = useAgentId ? agentsById[useAgentId] : null;
      const retellAgentId = agent?.retell_agent_id ?? null;

      if (!retellAgentId || !data.fromNumber) {
        // Queue for later — agent not linked or no caller number provided yet.
        const { error: uErr } = await supabase
          .from("data_records")
          .update({
            call_status: "queued",
            assigned_agent_id: useAgentId,
          })
          .eq("id", r.id)
          .eq("workspace_id", workspaceId);
        if (uErr) failed += 1;
        else queued += 1;
        continue;
      }

      try {
        const call = await retellFetch<any>(
          "/v2/create-phone-call",
          {
            from_number: data.fromNumber,
            to_number: r.mobile_number,
            override_agent_id: retellAgentId,
            metadata: { data_record_id: r.id, workspace_id: workspaceId },
          },
          "POST",
        );
        await supabase
          .from("data_records")
          .update({
            call_status: "calling",
            assigned_agent_id: useAgentId,
          })
          .eq("id", r.id)
          .eq("workspace_id", workspaceId);
        // Insert a tracking row in calls so the rest of the dashboard sees it.
        await supabase.from("calls").insert({
          workspace_id: workspaceId,
          retell_call_id: call?.call_id ?? null,
          agent_id: retellAgentId,
          agent_name: agent?.name ?? null,
          from_number: data.fromNumber,
          to_number: r.mobile_number,
          call_type: "outbound",
          call_status: "initiated",
        });
        placed += 1;
      } catch (e: any) {
        failed += 1;
        errors.push({ recordId: r.id, message: e?.message ?? "Retell call failed" });
        await supabase
          .from("data_records")
          .update({ call_status: "failed" })
          .eq("id", r.id)
          .eq("workspace_id", workspaceId);
      }
    }

    return { placed, queued, failed, errors };
  });

// ============= CALL SCHEDULE (workspace-wide) =============
const CallScheduleSchema = z.object({
  timezone: z.string().max(64).default("UTC"),
  days: z.array(z.number().int().min(0).max(6)).max(7),
  startHour: z.number().int().min(0).max(23),
  endHour: z.number().int().min(0).max(24),
  enabled: z.boolean().default(true),
});

export const getCallSchedule = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const workspaceId = await resolveWorkspaceId(supabase, userId);
    const { data, error } = await supabase
      .from("workspace_settings")
      .select("call_schedule, timezone")
      .eq("workspace_id", workspaceId)
      .maybeSingle();
    if (error) throw new Error(error.message);
    return {
      schedule: (data?.call_schedule ?? null) as null | z.infer<typeof CallScheduleSchema>,
      timezone: data?.timezone ?? "UTC",
    };
  });

export const setCallSchedule = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => CallScheduleSchema.parse(input))
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    const workspaceId = await resolveWorkspaceId(supabase, userId);
    const { error } = await supabase
      .from("workspace_settings")
      .upsert(
        {
          workspace_id: workspaceId,
          call_schedule: data,
          timezone: data.timezone,
        },
        { onConflict: "workspace_id" },
      );
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// ============= QUALIFIED LEADS (data_records called with neutral/positive sentiment) =============
export const listCalledQualifiedRecords = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const workspaceId = await resolveWorkspaceId(supabase, userId);

    // Pull calls in this workspace that have a neutral or positive sentiment.
    const { data: calls, error: callsErr } = await supabase
      .from("calls")
      .select("id, to_number, sentiment, call_status, call_outcome, call_summary, started_at, ended_at, duration_seconds, agent_name")
      .eq("workspace_id", workspaceId)
      .in("sentiment", ["neutral", "positive"])
      .order("started_at", { ascending: false, nullsFirst: false })
      .limit(2000);
    if (callsErr) throw new Error(callsErr.message);

    const callsList = (calls ?? []) as any[];
    if (callsList.length === 0) return [];

    // Normalize phone: keep digits only for matching.
    const digits = (s: string | null | undefined) => (s ?? "").replace(/\D/g, "");

    // Latest call per normalized phone number.
    const latestByPhone = new Map<string, any>();
    for (const c of callsList) {
      const key = digits(c.to_number);
      if (!key) continue;
      if (!latestByPhone.has(key)) latestByPhone.set(key, c);
    }

    // Fetch all data_records in the workspace, then match locally on normalized phone.
    const { data: records, error: recErr } = await supabase
      .from("data_records")
      .select("*")
      .eq("workspace_id", workspaceId)
      .eq("is_deleted", false)
      .limit(5000);
    if (recErr) throw new Error(recErr.message);

    const out: any[] = [];
    for (const r of (records ?? []) as any[]) {
      const key = digits(r.mobile_number);
      const call = key ? latestByPhone.get(key) : undefined;
      if (call) out.push({ record: r, call });
    }

    // Sort by latest call started_at desc.
    out.sort((a, b) => {
      const ta = a.call.started_at ? new Date(a.call.started_at).getTime() : 0;
      const tb = b.call.started_at ? new Date(b.call.started_at).getTime() : 0;
      return tb - ta;
    });

    return out;
  });

// ============= WORKSPACE SETTINGS =============
export const getWorkspaceSettings = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const workspaceId = await resolveWorkspaceId(supabase, userId);
    const { data, error } = await supabase
      .from("workspace_settings")
      .select("*")
      .eq("workspace_id", workspaceId)
      .maybeSingle();
    if (error) throw new Error(error.message);
    return { workspaceId, settings: data };
  });

export const saveWorkspaceSettings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      business_name: z.string().nullable().optional(),
      timezone: z.string().optional(),
      notification_email: z.string().email().nullable().optional().or(z.literal("")),
      retell_default_agent_id: z.string().nullable().optional(),
      calcom_api_token: z.string().nullable().optional(),
      calcom_event_type_id: z.string().nullable().optional(),
      calcom_webhook_secret: z.string().nullable().optional(),
      whatsapp_phone_id: z.string().nullable().optional(),
      twilio_auth_token: z.string().nullable().optional(),
      builder_base_url: z.string().url().nullable().optional().or(z.literal("")),
      builder_api_token: z.string().nullable().optional(),
    }).parse(input),
  )
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    const workspaceId = await resolveWorkspaceId(supabase, userId);
    const payload = {
      workspace_id: workspaceId,
      business_name: data.business_name ?? null,
      timezone: data.timezone ?? "UTC",
      notification_email: data.notification_email || null,
      retell_default_agent_id: data.retell_default_agent_id
        ? data.retell_default_agent_id.replace(/^agents\//, "").trim() || null
        : null,
      calcom_api_token: data.calcom_api_token ?? null,
      calcom_event_type_id: data.calcom_event_type_id ?? null,
      calcom_webhook_secret: data.calcom_webhook_secret ?? null,
      whatsapp_phone_id: data.whatsapp_phone_id ?? null,
      twilio_auth_token: data.twilio_auth_token ?? null,
      builder_base_url: (data.builder_base_url || null) as string | null,
      builder_api_token: data.builder_api_token ?? null,
    };
    const { error } = await supabase
      .from("workspace_settings")
      .upsert(payload, { onConflict: "workspace_id" });
    if (error) throw new Error(error.message);

    // Auto-register the Cal.com webhook the moment a token is present —
    // user never has to paste anything into Cal.com.
    let calcomWebhook:
      | { ok: boolean; message: string; created: boolean; webhookId?: string | number }
      | null = null;
    if (payload.calcom_api_token) {
      try {
        const { registerCalcomWebhook } = await import(
          "@/lib/providers/calcom/webhook-register.server"
        );
        const origin =
          process.env.PUBLIC_SITE_URL?.trim().replace(/\/$/, "") ||
          "https://project--5ac2a13e-280d-409c-99e9-989a09464b56.lovable.app";
        const r = await registerCalcomWebhook({
          workspaceId,
          subscriberUrl: `${origin}/api/public/calcom-webhook/${workspaceId}`,
        });
        calcomWebhook = {
          ok: r.ok,
          message: r.message,
          created: r.created,
          webhookId:
            typeof r.webhookId === "string" || typeof r.webhookId === "number"
              ? r.webhookId
              : undefined,
        };
      } catch (e) {
        console.warn("[saveWorkspaceSettings] calcom webhook register failed", e);
      }
    }
    return { ok: true, calcomWebhook };
  });

// ============= DATA IMPORT (CSV) =============
const DataRowSchema = z.object({
  name: z.string().min(1).max(200),
  mobile_number: z.string().min(3).max(40),
  first_name: z.string().max(120).nullable().optional(),
  last_name: z.string().max(120).nullable().optional(),
  email: z.string().email().max(200).nullable().optional().or(z.literal("")),
  title: z.string().max(120).nullable().optional(),
  client_name: z.string().max(200).nullable().optional(),
  unique_id: z.string().max(120).nullable().optional(),
  property_type: z.string().max(120).nullable().optional(),
  bedrooms: z.string().max(40).nullable().optional(),
  address_line1: z.string().max(255).nullable().optional(),
  address_line2: z.string().max(255).nullable().optional(),
  city: z.string().max(120).nullable().optional(),
  state: z.string().max(120).nullable().optional(),
  postal_code: z.string().max(40).nullable().optional(),
});

export const importDataRecords = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      rows: z.array(DataRowSchema).min(1).max(5000),
    }).parse(input),
  )
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    const workspaceId = await resolveWorkspaceId(supabase, userId);
    const payload = data.rows.map((r) => ({
      workspace_id: workspaceId,
      name: r.name,
      mobile_number: r.mobile_number,
      first_name: r.first_name || null,
      last_name: r.last_name || null,
      email: r.email || null,
      title: r.title || null,
      client_name: r.client_name || null,
      unique_id: r.unique_id || null,
      property_type: r.property_type || null,
      bedrooms: r.bedrooms || null,
      address_line1: r.address_line1 || null,
      address_line2: r.address_line2 || null,
      city: r.city || null,
      state: r.state || null,
      postal_code: r.postal_code || null,
    }));
    // Batch into 1000-row chunks to stay well under PostgREST/Postgres limits.
    const CHUNK = 1000;
    let inserted = 0;
    for (let i = 0; i < payload.length; i += CHUNK) {
      const slice = payload.slice(i, i + CHUNK);
      const { error, count } = await supabase
        .from("data_records")
        .insert(slice, { count: "exact" });
      if (error) throw new Error(`Chunk ${i / CHUNK + 1}: ${error.message}`);
      inserted += count ?? slice.length;
    }
    return { inserted };
  });

// ============= RETELL SYNC (receptionist) =============
export const syncRetellReceptionist = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const workspaceId = await resolveWorkspaceId(supabase, userId);

    // Pull this workspace's deployed Retell agent ids
    const { data: deps, error: depErr } = await supabase
      .from("deployments")
      .select("provider_agent_id, deployed_at, agent_id")
      .eq("workspace_id", workspaceId)
      .eq("provider", "retell")
      .order("deployed_at", { ascending: false });
    if (depErr) throw new Error(depErr.message);

    const localAgentIds = new Set(
      (deps ?? []).map((d: any) => d.provider_agent_id).filter(Boolean),
    );

    // Pull live Retell agents + phone numbers (best-effort)
    let retellAgents: any[] = [];
    let phoneNumbers: any[] = [];
    try {
      retellAgents = await retellFetch<any[]>("/list-agents", null, "GET");
    } catch (e) {
      console.error("Retell list-agents failed:", e);
    }
    try {
      phoneNumbers = await retellFetch<any[]>("/list-phone-numbers", null, "GET");
    } catch (e) {
      console.error("Retell list-phone-numbers failed:", e);
    }

    // Annotate phone numbers with whether they're bound to one of our agents
    const ours = (phoneNumbers ?? []).map((p: any) => ({
      phone_number: p.phone_number ?? p.phone_number_pretty ?? null,
      nickname: p.nickname ?? null,
      inbound_agent_id: p.inbound_agent_id ?? null,
      outbound_agent_id: p.outbound_agent_id ?? null,
      is_ours:
        localAgentIds.has(p.inbound_agent_id) ||
        localAgentIds.has(p.outbound_agent_id),
    }));

    const liveAgents = (retellAgents ?? []).map((a: any) => ({
      agent_id: a.agent_id,
      agent_name: a.agent_name ?? null,
      is_ours: localAgentIds.has(a.agent_id),
      last_modification_timestamp: a.last_modification_timestamp ?? null,
    }));

    return {
      deployedCount: localAgentIds.size,
      agents: liveAgents.filter((a) => a.is_ours),
      phoneNumbers: ours.filter((p) => p.is_ours),
      allPhoneNumbersCount: ours.length,
    };
  });

// ============= RETELL ANALYTICS =============
export const getRetellAnalytics = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      days: z.number().int().min(1).max(90).default(30),
      limit: z.number().int().min(1).max(1000).default(1000),
    }).parse(input ?? {}),
  )
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    const workspaceId = await resolveWorkspaceId(supabase, userId);

    const { data: deps, error: depErr } = await supabase
      .from("deployments")
      .select("provider_agent_id, agent_id")
      .eq("workspace_id", workspaceId)
      .eq("provider", "retell");
    if (depErr) throw new Error(depErr.message);
    const agentIds = Array.from(
      new Set((deps ?? []).map((d: any) => d.provider_agent_id).filter(Boolean)),
    );

    const sinceMs = Date.now() - data.days * 24 * 60 * 60 * 1000;
    let calls: any[] = [];
    let error: string | null = null;
    try {
      const filter_criteria: Record<string, unknown> = {
        start_timestamp: { lower_threshold: sinceMs },
      };
      // If this workspace has deployed agents, scope to them.
      // Otherwise pull ALL calls from the master Retell account.
      if (agentIds.length > 0) {
        filter_criteria.agent_id = agentIds;
      }
      const res = await retellFetch<any>(
        "/v2/list-calls",
        {
          filter_criteria,
          limit: data.limit,
          sort_order: "descending",
        },
        "POST",
      );
      calls = Array.isArray(res)
        ? res
        : (res?.calls ?? res?.data ?? res?.result ?? []);
      console.log(
        `[getRetellAnalytics] workspace=${workspaceId} agents=${agentIds.length} days=${data.days} returned=${calls.length}`,
      );
    } catch (e: any) {
      error = e?.message || "Failed to load Retell analytics";
      console.error("Retell list-calls failed:", e);
    }

    return { configured: true, agentIds, calls, error };
  });

// ============= BUILDER SYNC =============
/**
 * Pull integration settings from the connected Agent Builder workspace.
 * Expects the builder to expose `GET {builder_base_url}/api/public/integrations/export`
 * with `Authorization: Bearer <builder_api_token>` returning JSON like:
 *   {
 *     calcom: { apiToken, eventTypeId },
 *     twilio: { authToken, phoneId },
 *     timezone, businessName, notificationEmail,
 *     retellDefaultAgentId
 *   }
 * Any field that is missing is left untouched on this side.
 */
export const syncFromBuilder = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const workspaceId = await resolveWorkspaceId(supabase, userId);

    const { data: settings, error: sErr } = await supabase
      .from("workspace_settings")
      .select("builder_base_url, builder_api_token")
      .eq("workspace_id", workspaceId)
      .maybeSingle();
    if (sErr) throw new Error(sErr.message);
    const baseUrl = (settings?.builder_base_url ?? "").toString().trim().replace(/\/$/, "");
    const token = (settings?.builder_api_token ?? "").toString().trim();
    if (!baseUrl) throw new Error("Set Builder URL first.");
    if (!token) throw new Error("Set Builder API token first.");

    const url = `${baseUrl}/api/public/integrations/export`;
    let res: Response;
    try {
      res = await fetch(url, {
        method: "GET",
        headers: { Authorization: `Bearer ${token}`, Accept: "application/json" },
      });
    } catch (e: any) {
      throw new Error(`Could not reach Builder: ${e?.message ?? "network error"}`);
    }
    const text = await res.text();
    if (!res.ok) {
      throw new Error(`Builder responded ${res.status}: ${text.slice(0, 300)}`);
    }
    let body: any;
    try { body = text ? JSON.parse(text) : {}; } catch { throw new Error("Builder returned non-JSON response."); }

    const syncedAt = new Date().toISOString();
    const patch: Record<string, unknown> = {
      builder_last_synced_at: syncedAt,
      builder_last_sync_status: "ok",
    };
    const filled: string[] = [];
    const pick = (k: string, v: unknown) => {
      if (typeof v === "string" && v.trim()) { patch[k] = v.trim(); filled.push(k); }
    };
    pick("calcom_api_token", body?.calcom?.apiToken ?? body?.calcom_api_token);
    pick("calcom_event_type_id", body?.calcom?.eventTypeId ?? body?.calcom_event_type_id);
    pick("twilio_auth_token", body?.twilio?.authToken ?? body?.twilio_auth_token);
    pick("whatsapp_phone_id", body?.twilio?.phoneId ?? body?.whatsapp_phone_id);
    pick("timezone", body?.timezone);
    pick("business_name", body?.businessName ?? body?.business_name);
    pick("notification_email", body?.notificationEmail ?? body?.notification_email);
    pick("retell_default_agent_id", body?.retellDefaultAgentId ?? body?.retell_default_agent_id);

    const { error: uErr } = await supabase
      .from("workspace_settings")
      .update(patch as never)
      .eq("workspace_id", workspaceId);
    if (uErr) throw new Error(uErr.message);

    // Auto-register Cal.com webhook if a token came through.
    if (typeof patch.calcom_api_token === "string") {
      try {
        const { registerCalcomWebhook } = await import(
          "@/lib/providers/calcom/webhook-register.server"
        );
        const origin =
          process.env.PUBLIC_SITE_URL?.trim().replace(/\/$/, "") ||
          "https://project--5ac2a13e-280d-409c-99e9-989a09464b56.lovable.app";
        await registerCalcomWebhook({
          workspaceId,
          subscriberUrl: `${origin}/api/public/calcom-webhook/${workspaceId}`,
        });
      } catch (e) {
        console.warn("[syncFromBuilder] calcom webhook register failed", e);
      }
    }

    return { ok: true, filled, syncedAt };
  });