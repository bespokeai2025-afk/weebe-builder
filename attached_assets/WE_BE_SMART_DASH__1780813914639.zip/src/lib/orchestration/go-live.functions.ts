/**
 * Go-live workflow: the user pasted a Retell agent ID that their external
 * Agent Builder already cloned into the Retell workspace. We:
 *   1. Validate the agent exists on Retell (GET /get-agent/:id).
 *   2. PATCH the Retell agent to set webhook_url -> our public webhook,
 *      so call events flow into the dashboard's Calls table.
 *   3. Persist retell_agent_id on the agent row + audit in deployments.
 */
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getRequestHost } from "@tanstack/react-start/server";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { retellFetch } from "@/lib/providers/retell/client.server";

function buildWebhookUrl(): string {
  const explicit = process.env.PUBLIC_SITE_URL?.trim();
  if (explicit) return `${explicit.replace(/\/$/, "")}/api/public/voice-webhook`;
  const host = getRequestHost();
  return `https://${host}/api/public/voice-webhook`;
}

export const goLiveAgent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        id: z.string().uuid(),
        retellAgentId: z
          .string()
          .min(3)
          .max(128)
          .regex(/^[A-Za-z0-9_-]+$/, "Retell agent id contains invalid characters"),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;

    const { data: row, error: rowErr } = await supabase
      .from("agents")
      .select("id, workspace_id, name, agent_type")
      .eq("id", data.id)
      .maybeSingle();
    if (rowErr) throw new Error(rowErr.message);
    if (!row) throw new Error("Agent not found");

    // 1. Verify agent exists on Retell.
    let retellAgent: Record<string, unknown>;
    try {
      retellAgent = await retellFetch<Record<string, unknown>>(
        `/get-agent/${encodeURIComponent(data.retellAgentId)}`,
        undefined,
        "GET",
      );
    } catch (e) {
      const message = e instanceof Error ? e.message : "Failed to fetch Retell agent";
      throw new Error(
        `Retell agent "${data.retellAgentId}" not reachable. ${message}`,
      );
    }

    const verifiedAgentId =
      (retellAgent.agent_id as string | undefined) ?? data.retellAgentId;

    // 2. Patch agent on Retell with our webhook URL.
    const webhookUrl = buildWebhookUrl();
    try {
      await retellFetch(
        `/update-agent/${encodeURIComponent(verifiedAgentId)}`,
        { webhook_url: webhookUrl },
        "PATCH",
      );
    } catch (e) {
      const message = e instanceof Error ? e.message : "Failed to register webhook";
      await supabase.from("deployments").insert({
        agent_id: row.id as string,
        workspace_id: row.workspace_id as string,
        provider: "retell",
        provider_agent_id: verifiedAgentId,
        status: "error",
        error: message,
        deployed_by: userId,
        payload: { stage: "register_webhook", webhook_url: webhookUrl } as never,
      });
      throw new Error(message);
    }

    // 3. Persist link + audit success.
    const flowIdRaw = retellAgent.response_engine as
      | { conversation_flow_id?: string }
      | undefined;
    const conversationFlowId = flowIdRaw?.conversation_flow_id ?? null;

    const { error: updErr } = await supabase
      .from("agents")
      .update({
        retell_agent_id: verifiedAgentId,
        retell_conversation_flow_id: conversationFlowId,
      })
      .eq("id", row.id);
    if (updErr) throw new Error(updErr.message);

    await supabase.from("deployments").insert({
      agent_id: row.id as string,
      workspace_id: row.workspace_id as string,
      provider: "retell",
      provider_agent_id: verifiedAgentId,
      provider_flow_id: conversationFlowId,
      status: "success",
      deployed_by: userId,
      payload: {
        stage: "go_live",
        agent_type: row.agent_type,
        webhook_url: webhookUrl,
      } as never,
    });

    return {
      retellAgentId: verifiedAgentId,
      retellConversationFlowId: conversationFlowId,
      webhookUrl,
    };
  });