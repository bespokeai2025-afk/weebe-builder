/**
 * Server functions for compiling and deploying IR agents to providers.
 * Thin file by design: only `createServerFn` declarations and their
 * imports. Heavy logic lives in `*.server.ts` modules so the bundler can
 * tree-shake them away from the client.
 */
import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import {
  IRAgent,
  IRToolDefinition,
  validateAgent,
} from "@/lib/orchestration/ir";
import { compileAgentToRetell } from "@/lib/providers/retell/compiler";
import { deployAgentToRetell } from "@/lib/providers/retell/adapter.server";
import { z } from "zod";

const DeployInput = z.object({
  provider: z.literal("retell"),
  agent: IRAgent,
  tools: z.array(IRToolDefinition).default([]),
  retellAgentId: z.string().optional(),
  retellConversationFlowId: z.string().optional(),
});

/**
 * Compile-only — validates the IR and returns the provider payload WITHOUT
 * calling the provider's API. Useful for previewing what we'd send and
 * surfacing oneOf-style errors at design time.
 */
export const previewDeployment = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        provider: z.literal("retell"),
        agent: z.unknown(),
        tools: z.array(IRToolDefinition).default([]),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const v = validateAgent(data.agent);
    if (!v.ok) {
      return { ok: false as const, issues: v.issues };
    }
    const compiled = compileAgentToRetell(v.agent, data.tools);
    // JSON round-trip so the serializer sees a concrete JSON-safe shape
    // (TanStack rejects Record<string, unknown> values at the RPC boundary).
    return { ok: true as const, compiledJson: JSON.stringify(compiled) };
  });

/**
 * Compile + push to the provider. Returns the provider ids + raw response.
 * Persistence into the `deployments` table is added in Phase 6.
 */
export const deployAgent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => DeployInput.parse(input))
  .handler(async ({ data }) => {
    const result = await deployAgentToRetell({
      agent: data.agent,
      tools: data.tools,
      retellAgentId: data.retellAgentId,
      retellConversationFlowId: data.retellConversationFlowId,
    });
    return {
      retellAgentId: result.retellAgentId,
      retellConversationFlowId: result.retellConversationFlowId,
      // Don't ship the full agent/flow response back to the browser by
      // default — they can be large. Caller can re-request if needed.
      summary: {
        agentName: data.agent.name,
        nodeCount: data.agent.workflow.nodes.length,
        toolCount: data.tools.length,
      },
    };
  });