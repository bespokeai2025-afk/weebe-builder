import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { IRToolDefinition, validateAgent } from "@/lib/orchestration/ir";
import { deployAgentToRetell } from "@/lib/providers/retell/adapter.server";

/**
 * Deploy an existing agent row to Retell using the IR + tools already saved
 * on the row's `settings` JSON. Powers the "Go Live" button on /my-agents.
 *
 * Expected shape on `agents.settings`:
 *   { ir: IRAgent, tools?: IRToolDefinition[] }
 */
export const deployAgentById = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;

    const { data: row, error } = await supabase
      .from("agents")
      .select(
        "id, workspace_id, name, agent_type, settings, retell_agent_id, retell_conversation_flow_id",
      )
      .eq("id", data.id)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!row) throw new Error("Agent not found");

    const settings = (row.settings ?? {}) as {
      ir?: unknown;
      tools?: unknown;
    };

    const v = validateAgent(settings.ir);
    if (!v.ok) {
      throw new Error(
        "Agent settings are missing a valid IR. Save the agent in the builder first.",
      );
    }
    const tools = z.array(IRToolDefinition).default([]).parse(settings.tools ?? []);

    try {
      const result = await deployAgentToRetell({
        agent: v.agent,
        tools,
        retellAgentId: row.retell_agent_id ?? undefined,
        retellConversationFlowId: row.retell_conversation_flow_id ?? undefined,
      });

      await supabase
        .from("agents")
        .update({
          retell_agent_id: result.retellAgentId,
          retell_conversation_flow_id: result.retellConversationFlowId,
        })
        .eq("id", row.id);

      await supabase.from("deployments").insert({
        agent_id: row.id as string,
        workspace_id: row.workspace_id as string,
        provider: "retell",
        provider_agent_id: result.retellAgentId,
        provider_flow_id: result.retellConversationFlowId,
        status: "success",
        deployed_by: userId,
        payload: { agent_type: row.agent_type, name: row.name } as never,
      });

      return {
        retellAgentId: result.retellAgentId,
        retellConversationFlowId: result.retellConversationFlowId,
      };
    } catch (e) {
      const message = e instanceof Error ? e.message : "Deploy failed";
      await supabase.from("deployments").insert({
        agent_id: row.id as string,
        workspace_id: row.workspace_id as string,
        provider: "retell",
        provider_agent_id: row.retell_agent_id,
        status: "error",
        error: message,
        deployed_by: userId,
        payload: { agent_type: row.agent_type, name: row.name } as never,
      });
      throw new Error(message);
    }
  });