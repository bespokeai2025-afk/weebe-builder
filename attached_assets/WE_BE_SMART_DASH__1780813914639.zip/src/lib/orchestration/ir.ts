/**
 * Internal, provider-agnostic Intermediate Representation (IR) for AI voice
 * agents. The dashboard, agent builder, and Lovable backend all speak this
 * IR. Provider adapters (Retell today, others later) compile it into the
 * provider's native payload shape.
 *
 * Design goals:
 *  - One source of truth for what an agent IS, independent of Retell.
 *  - Strong Zod validation so deployment failures surface BEFORE we call
 *    the provider (no more opaque Retell `oneOf` errors).
 *  - Stable across providers — adding a new provider should never require
 *    changing the IR, only adding a new adapter.
 */
import { z } from "zod";

// ---------- Shared primitives ----------

export const IRId = z.string().min(1).max(128);

export const IRPosition = z.object({
  x: z.number(),
  y: z.number(),
});

export const IRTransition = z.object({
  /** Stable id matching the source-node's outgoing handle. */
  id: IRId,
  /** Natural-language condition: "User wants to book", "Else", etc. */
  condition: z.string().min(1).max(1000),
  /** Target IR node id. Null = dangling (treated as "no destination"). */
  target: IRId.nullable(),
});
export type IRTransition = z.infer<typeof IRTransition>;

// ---------- Workflow nodes ----------

export const IRNodeKind = z.enum([
  "conversation",
  "tool", // function call (Cal.com booking, CRM lookup, custom HTTP, etc.)
  "call_transfer",
  "qualification", // extract structured variables from the call
  "logic", // branch on conditions
  "end_call",
]);
export type IRNodeKind = z.infer<typeof IRNodeKind>;

const IRBaseNode = z.object({
  id: IRId,
  label: z.string().min(1).max(120),
  position: IRPosition,
  isStart: z.boolean().optional(),
  /** Free-form prompt / instruction for nodes that talk. */
  prompt: z.string().max(8000).optional(),
  transitions: z.array(IRTransition).default([]),
});

export const IRConversationNode = IRBaseNode.extend({
  kind: z.literal("conversation"),
  startSpeaker: z.enum(["agent", "user"]).optional(),
  instructionType: z.enum(["prompt", "static_text"]).default("prompt"),
});

export const IRToolNode = IRBaseNode.extend({
  kind: z.literal("tool"),
  /** Reference to a tool_instances row (id) or a registry preset key. */
  toolRef: z.string().min(1).max(128),
  speakDuringExecution: z.boolean().default(false),
  waitForResult: z.boolean().default(true),
});

export const IRCallTransferNode = IRBaseNode.extend({
  kind: z.literal("call_transfer"),
  transferMode: z.enum(["static", "dynamic"]).default("static"),
  /** E.164 number when static; dynamic variable name when dynamic. */
  destination: z.string().min(1).max(256),
  transferType: z
    .enum(["cold_transfer", "warm_transfer", "agentic_warm_transfer"])
    .default("cold_transfer"),
  showTransfereeAsCaller: z.boolean().default(false),
  ringDurationSec: z.number().int().min(5).max(90).optional(),
  warmHandoffPrompt: z.string().max(2000).optional(),
});

export const IRQualificationNode = IRBaseNode.extend({
  kind: z.literal("qualification"),
  variables: z
    .array(
      z.object({
        name: z.string().min(1).max(64).regex(/^[a-zA-Z_][a-zA-Z0-9_]*$/),
        description: z.string().min(1).max(500),
        type: z.enum(["string", "number", "boolean", "enum"]).default("string"),
        choices: z.array(z.string()).optional(),
      }),
    )
    .min(1)
    .max(20),
});

export const IRLogicNode = IRBaseNode.extend({
  kind: z.literal("logic"),
});

export const IREndCallNode = IRBaseNode.extend({
  kind: z.literal("end_call"),
  endingPrompt: z.string().max(2000).optional(),
});

export const IRNode = z.discriminatedUnion("kind", [
  IRConversationNode,
  IRToolNode,
  IRCallTransferNode,
  IRQualificationNode,
  IRLogicNode,
  IREndCallNode,
]);
export type IRNode = z.infer<typeof IRNode>;

// ---------- Workflow ----------

export const IRWorkflow = z.object({
  id: IRId.optional(),
  globalPrompt: z.string().max(20000).default(""),
  /** Who speaks first across the whole flow. */
  startSpeaker: z.enum(["agent", "user"]).default("agent"),
  nodes: z.array(IRNode).min(1).max(200),
  /**
   * Authoritative edges from the graph editor. The compiler also reads
   * `node.transitions[].target` and reconciles the two, but explicit edges
   * here win when both exist.
   */
  edges: z
    .array(
      z.object({
        id: IRId,
        source: IRId,
        sourceHandle: IRId.optional(),
        target: IRId,
      }),
    )
    .default([]),
});
export type IRWorkflow = z.infer<typeof IRWorkflow>;

// ---------- Voice / agent settings ----------

export const IRVoiceConfig = z.object({
  voiceId: z.string().min(1).max(120),
  /** ISO-639 + region, e.g. "en-US". */
  language: z.string().min(2).max(20).default("en-US"),
  voiceSpeed: z.number().min(0.5).max(2).default(1),
  voiceTemperature: z.number().min(0).max(2).default(1),
  volume: z.number().min(0).max(2).default(1),
  responsiveness: z.number().min(0).max(1).default(1),
  interruptionSensitivity: z.number().min(0).max(1).default(0.7),
  voiceEmotion: z
    .enum(["calm", "sympathetic", "happy", "sad", "angry", "fearful", "surprised", "none"])
    .default("none"),
});
export type IRVoiceConfig = z.infer<typeof IRVoiceConfig>;

export const IRAgent = z.object({
  id: IRId.optional(),
  name: z.string().min(1).max(120),
  /** LLM model identifier the agent uses for generation. */
  model: z.string().min(1).max(120).default("gpt-4o-mini"),
  beginMessage: z.string().max(2000).default(""),
  voice: IRVoiceConfig,
  workflow: IRWorkflow,
  /** Optional webhook the provider will call with call events. */
  webhookUrl: z.string().url().optional(),
  maxCallDurationMs: z
    .number()
    .int()
    .min(30_000)
    .max(3_600_000)
    .default(1_800_000),
});
export type IRAgent = z.infer<typeof IRAgent>;

// ---------- Tool registry entries ----------

export const IRToolDefinition = z.object({
  key: z.string().min(1).max(64).regex(/^[a-z][a-z0-9_]*$/),
  name: z.string().min(1).max(120),
  description: z.string().min(1).max(1000),
  kind: z.enum(["http", "calcom", "crm", "builtin"]),
  /** URL for HTTP/CRM tools. */
  url: z.string().url().optional(),
  /** JSON Schema of the tool's parameters (passed to the LLM). */
  parameters: z.record(z.string(), z.unknown()).default({}),
  speakDuringExecution: z.boolean().default(false),
});
export type IRToolDefinition = z.infer<typeof IRToolDefinition>;

// ---------- Result type for compiler / adapter ----------

export type IRValidationIssue = {
  path: string;
  message: string;
};

export function validateAgent(input: unknown): {
  ok: true;
  agent: IRAgent;
} | {
  ok: false;
  issues: IRValidationIssue[];
} {
  const parsed = IRAgent.safeParse(input);
  if (parsed.success) return { ok: true, agent: parsed.data };
  return {
    ok: false,
    issues: parsed.error.issues.map((i) => ({
      path: i.path.join("."),
      message: i.message,
    })),
  };
}