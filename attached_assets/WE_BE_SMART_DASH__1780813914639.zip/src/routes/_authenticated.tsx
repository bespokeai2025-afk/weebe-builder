import { createFileRoute, Outlet, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { getMyContext } from "@/lib/workspace.functions";

export const Route = createFileRoute("/_authenticated")({
  component: AuthenticatedLayout,
});

function AuthenticatedLayout() {
  const navigate = useNavigate();
  const [ready, setReady] = useState(false);
  const [embedded, setEmbedded] = useState(false);
  const fetchCtx = useServerFn(getMyContext);

  useEffect(() => {
    document.documentElement.classList.add("dark");
    // Embedded mode only when explicitly requested via ?embedded=1.
    // (Iframe auto-detection caused the sidebar to disappear inside the
    // Lovable preview itself.)
    try {
      const params = new URLSearchParams(window.location.search);
      setEmbedded(params.get("embedded") === "1");
    } catch {
      setEmbedded(false);
    }
    let active = true;
    supabase.auth.getUser().then(({ data, error }) => {
      if (!active) return;
      if (error || !data.user) navigate({ to: "/login", replace: true });
      else setReady(true);
    });
    return () => { active = false; };
  }, [navigate]);

  const { data: ctx } = useQuery({
    queryKey: ["my-context"],
    queryFn: () => fetchCtx(),
    enabled: ready,
  });

  if (!ready) {
    return (
      <div className="flex min-h-screen items-center justify-center text-muted-foreground">
        Loading…
      </div>
    );
  }

  const profile = ctx?.profile;
  const primaryWs = ctx?.workspaces?.[0];

  if (embedded) {
    return (
      <div className="min-h-screen w-full bg-background">
        <main className="flex-1">
          <Outlet />
        </main>
      </div>
    );
  }

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full bg-background">
        <AppSidebar
          email={profile?.email ?? ""}
          workspaceName={primaryWs?.name ?? "Workspace"}
          isAdmin={primaryWs?.role === "owner" || primaryWs?.role === "admin"}
        />
        <div className="flex flex-1 flex-col">
          <header className="flex h-12 items-center border-b px-3">
            <SidebarTrigger />
          </header>
          <main className="flex-1">
            <Outlet />
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
