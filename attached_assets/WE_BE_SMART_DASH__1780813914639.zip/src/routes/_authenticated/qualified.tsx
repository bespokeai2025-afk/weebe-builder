import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { ShieldCheck } from "lucide-react";
import { PageHeader, PanelCard, EmptyState } from "@/components/dashboard/PageShell";
import { listLeads } from "@/lib/dashboard.functions";

export const Route = createFileRoute("/_authenticated/qualified")({
  head: () => ({ meta: [{ title: "Qualified" }] }),
  component: () => {
    const fn = useServerFn(listLeads);
    const q = useQuery({ queryKey: ["leads-qualified"], queryFn: () => fn({ data: { qualifiedOnly: true } }) });
    const rows = (q.data ?? []) as any[];
    return (
      <div className="pb-12">
        <PageHeader title="Qualified" subtitle="Leads marked interested or qualified" icon={ShieldCheck} onRefresh={() => q.refetch()} />
        <div className="px-8 pt-6">
          <PanelCard>
            {rows.length === 0 ? <EmptyState icon={ShieldCheck} title="No qualified leads" message="Qualified leads will show up here." /> : (
              <ul className="divide-y divide-white/[0.05]">
                {rows.map((l) => (
                  <li key={l.id} className="flex items-center justify-between py-3">
                    <div><p className="text-sm font-medium">{l.full_name ?? l.phone}</p><p className="text-xs text-muted-foreground">{l.phone} · {l.email ?? "—"}</p></div>
                    <span className="rounded-full bg-emerald-500/15 px-2 py-0.5 text-[11px] text-emerald-400">{l.status}</span>
                  </li>
                ))}
              </ul>
            )}
          </PanelCard>
        </div>
      </div>
    );
  },
});