import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Plus, Workflow, Rocket, Link2Off, Loader2, PhoneIncoming, PhoneOutgoing, ChevronDown, Wand2 } from "lucide-react";
import { toast } from "sonner";
import { listMyAgents, linkAgentToRetell, autoFixBookingTool } from "@/lib/agents.functions";
import { deployAgentById } from "@/lib/orchestration/deploy-by-id.functions";
import { goLiveAgent } from "@/lib/orchestration/go-live.functions";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

type AgentType = "lead_gen" | "receptionist";

export const Route = createFileRoute("/_authenticated/my-agents")({
  head: () => ({ meta: [{ title: "Agents" }] }),
  component: MyAgentsPage,
});

function MyAgentsPage() {
  const fetchAgents = useServerFn(listMyAgents);
  const linkFn = useServerFn(linkAgentToRetell);
  const deployFn = useServerFn(deployAgentById);
  const goLiveFn = useServerFn(goLiveAgent);
  const queryClient = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["my-agents"],
    queryFn: () => fetchAgents(),
  });

  const [linkTarget, setLinkTarget] = useState<{ id: string; name: string } | null>(null);
  const [retellId, setRetellId] = useState("");
  const [flowId, setFlowId] = useState("");
  const [agentType, setAgentType] = useState<AgentType>("lead_gen");
  const [inboundPhone, setInboundPhone] = useState("");
  const [advancedOpen, setAdvancedOpen] = useState(false);

  const linkMutation = useMutation({
    mutationFn: (input: {
      id: string;
      retellAgentId: string | null;
      agentType?: AgentType;
      inboundPhoneNumber?: string | null;
      retellConversationFlowId?: string | null;
    }) => linkFn({ data: input }),
    onSuccess: (_res, vars) => {
      toast.success(vars.retellAgentId ? "Agent is now live" : "Agent unlinked");
      queryClient.invalidateQueries({ queryKey: ["my-agents"] });
      setLinkTarget(null);
      setRetellId("");
      setFlowId("");
      setInboundPhone("");
      setAgentType("lead_gen");
      setAdvancedOpen(false);
    },
    onError: (err) => toast.error(err instanceof Error ? err.message : "Failed to link agent"),
  });

  const deployMutation = useMutation({
    mutationFn: async (input: {
      id: string;
      currentRetellAgentId: string | null;
      agentType: AgentType;
      inboundPhoneNumber: string | null;
    }) => {
      // Persist flow type / inbound number first (preserve existing retell id).
      await linkFn({
        data: {
          id: input.id,
          retellAgentId: input.currentRetellAgentId,
          agentType: input.agentType,
          inboundPhoneNumber: input.inboundPhoneNumber,
        },
      });
      return deployFn({ data: { id: input.id } });
    },
    onSuccess: () => {
      toast.success("Agent is live");
      queryClient.invalidateQueries({ queryKey: ["my-agents"] });
      setLinkTarget(null);
      setRetellId("");
      setFlowId("");
      setInboundPhone("");
      setAgentType("lead_gen");
      setAdvancedOpen(false);
    },
    onError: (err) => toast.error(err instanceof Error ? err.message : "Deploy failed"),
  });

  const goLiveMutation = useMutation({
    mutationFn: async (input: {
      id: string;
      retellAgentId: string;
      agentType: AgentType;
      inboundPhoneNumber: string | null;
    }) => {
      // Persist flow type / inbound number first so the agent row is in sync.
      await linkFn({
        data: {
          id: input.id,
          retellAgentId: input.retellAgentId,
          agentType: input.agentType,
          inboundPhoneNumber: input.inboundPhoneNumber,
        },
      });
      return goLiveFn({
        data: { id: input.id, retellAgentId: input.retellAgentId },
      });
    },
    onSuccess: (res) => {
      toast.success("Agent is live — webhooks registered");
      console.log("[go-live] webhook url:", res.webhookUrl);
      queryClient.invalidateQueries({ queryKey: ["my-agents"] });
      setLinkTarget(null);
      setRetellId("");
      setFlowId("");
      setInboundPhone("");
      setAgentType("lead_gen");
      setAdvancedOpen(false);
    },
    onError: (err) =>
      toast.error(err instanceof Error ? err.message : "Go live failed"),
  });

  function openLink(agent: {
    id: string;
    name: string;
    retell_agent_id: string | null;
    retell_conversation_flow_id: string | null;
    agent_type: AgentType;
    inbound_phone_number: string | null;
  }) {
    setLinkTarget({ id: agent.id, name: agent.name });
    setRetellId(agent.retell_agent_id ?? "");
    setFlowId(agent.retell_conversation_flow_id ?? "");
    setAgentType(agent.agent_type);
    setInboundPhone(agent.inbound_phone_number ?? "");
    setAdvancedOpen(false);
  }

  return (
    <div className="mx-auto max-w-6xl px-6 py-8">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Agents</h1>
          <p className="mt-1 text-sm text-muted-foreground">Your deployed and draft voice agents.</p>
        </div>
        <Button asChild>
          <Link to="/builder"><Plus className="mr-2 h-4 w-4" />New agent</Link>
        </Button>
      </div>

      <BookingToolChecklist />

      {isLoading ? (
        <p className="text-sm text-muted-foreground">Loading…</p>
      ) : !data || data.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-16 text-center">
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
              <Workflow className="h-6 w-6" />
            </div>
            <h3 className="text-lg font-semibold">No agents yet</h3>
            <p className="mt-1 text-sm text-muted-foreground">Open the builder to design your first conversation flow.</p>
            <Button asChild className="mt-4">
              <Link to="/builder">Open builder</Link>
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
          {data.map((a) => (
            <Card key={a.id as string} className="hover:shadow-elegant transition-shadow">
              <CardContent className="p-5">
                <div className="mb-2 flex items-start justify-between gap-2">
                  <h3 className="font-semibold leading-tight">{a.name as string}</h3>
                  {a.retell_agent_id ? <Badge variant="secondary">Deployed</Badge> : <Badge variant="outline">Draft</Badge>}
                </div>
                <div className="mb-2 flex items-center gap-1.5 text-xs text-muted-foreground">
                  {((a as { agent_type?: AgentType }).agent_type ?? "lead_gen") === "receptionist" ? (
                    <>
                      <PhoneIncoming className="h-3.5 w-3.5" />
                      <span>Receptionist · inbound</span>
                    </>
                  ) : (
                    <>
                      <PhoneOutgoing className="h-3.5 w-3.5" />
                      <span>Lead generation · outbound</span>
                    </>
                  )}
                </div>
                <p className="text-xs text-muted-foreground">
                  Updated {new Date(a.updated_at as string).toLocaleDateString()}
                </p>
                {a.retell_agent_id ? (
                  <p className="mt-1 truncate font-mono text-[11px] text-muted-foreground">
                    Agent ID: {a.retell_agent_id as string}
                  </p>
                ) : null}
                {(a as { inbound_phone_number?: string | null }).inbound_phone_number ? (
                  <p className="mt-0.5 truncate font-mono text-[11px] text-muted-foreground">
                    Inbound: {(a as { inbound_phone_number?: string }).inbound_phone_number}
                  </p>
                ) : null}
                <div className="mt-4 flex flex-wrap gap-2">
                  <Button asChild size="sm" variant="outline">
                    <Link to="/builder">Open</Link>
                  </Button>
                  <Button
                    size="sm"
                    onClick={() =>
                      openLink({
                        id: a.id as string,
                        name: a.name as string,
                        retell_agent_id: (a.retell_agent_id as string | null) ?? null,
                        retell_conversation_flow_id:
                          ((a as { retell_conversation_flow_id?: string | null }).retell_conversation_flow_id) ?? null,
                        agent_type:
                          ((a as { agent_type?: AgentType | null }).agent_type) ?? "lead_gen",
                        inbound_phone_number:
                          ((a as { inbound_phone_number?: string | null }).inbound_phone_number) ?? null,
                      })
                    }
                  >
                    <Rocket className="mr-2 h-4 w-4" />
                    {a.retell_agent_id ? "Re-link" : "Go Live"}
                  </Button>
                  {a.retell_agent_id ? (
                    <Button
                      size="sm"
                      variant="ghost"
                      disabled={linkMutation.isPending}
                      onClick={() =>
                        linkMutation.mutate({ id: a.id as string, retellAgentId: null })
                      }
                    >
                      <Link2Off className="mr-2 h-4 w-4" />
                      Unlink
                    </Button>
                  ) : null}
                  {a.retell_agent_id ? (
                    <AutoFixButton agentId={a.id as string} />
                  ) : null}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={!!linkTarget} onOpenChange={(v) => !v && setLinkTarget(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Go live: {linkTarget?.name}</DialogTitle>
            <DialogDescription>
              Paste the voice agent ID from the Agent Builder (the one already
              cloned into your workspace). We'll verify it, register a call
              webhook so outcomes flow into the Calls page, and mark the agent
              live here.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label htmlFor="primary-retell-id">Voice agent ID</Label>
              <Input
                id="primary-retell-id"
                placeholder="agent_xxxxxxxxxxxxxxxxxxxxxxxx"
                value={retellId}
                onChange={(e) => setRetellId(e.target.value)}
                autoComplete="off"
              />
              <p className="text-xs text-muted-foreground">
                Copy this from the Go Live button in your Agent Builder.
              </p>
            </div>
            <div className="space-y-2">
              <Label>Flow type</Label>
              <RadioGroup
                value={agentType}
                onValueChange={(v) => setAgentType(v as AgentType)}
                className="grid grid-cols-1 gap-2 sm:grid-cols-2"
              >
                <label
                  htmlFor="type-lead-gen"
                  className={`flex cursor-pointer items-start gap-3 rounded-lg border p-3 transition ${
                    agentType === "lead_gen" ? "border-primary bg-primary/5" : "border-border"
                  }`}
                >
                  <RadioGroupItem id="type-lead-gen" value="lead_gen" className="mt-0.5" />
                  <div>
                    <div className="flex items-center gap-1.5 text-sm font-medium">
                      <PhoneOutgoing className="h-3.5 w-3.5" /> Lead generation
                    </div>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      Outbound dialer. Calls records from the Data page.
                    </p>
                  </div>
                </label>
                <label
                  htmlFor="type-receptionist"
                  className={`flex cursor-pointer items-start gap-3 rounded-lg border p-3 transition ${
                    agentType === "receptionist" ? "border-primary bg-primary/5" : "border-border"
                  }`}
                >
                  <RadioGroupItem id="type-receptionist" value="receptionist" className="mt-0.5" />
                  <div>
                    <div className="flex items-center gap-1.5 text-sm font-medium">
                      <PhoneIncoming className="h-3.5 w-3.5" /> Receptionist
                    </div>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      Answers inbound calls and books into your calendar.
                    </p>
                  </div>
                </label>
              </RadioGroup>
            </div>

            {agentType === "receptionist" ? (
              <div className="space-y-1.5">
                <Label htmlFor="inbound-phone">Inbound phone number</Label>
                <Input
                  id="inbound-phone"
                  placeholder="+15551234567"
                  value={inboundPhone}
                  onChange={(e) => setInboundPhone(e.target.value)}
                />
                <p className="text-xs text-muted-foreground">
                  The phone number this receptionist answers. Bookings sync
                  into the Calendar page; call outcomes appear under Calls.
                </p>
              </div>
            ) : null}

            <Collapsible open={advancedOpen} onOpenChange={setAdvancedOpen}>
              <CollapsibleTrigger asChild>
                <button
                  type="button"
                  className="flex w-full items-center justify-between rounded-md border border-dashed px-3 py-2 text-xs text-muted-foreground hover:bg-muted/40"
                >
                  <span>Advanced — compile &amp; push IR from dashboard</span>
                  <ChevronDown
                    className={`h-3.5 w-3.5 transition-transform ${advancedOpen ? "rotate-180" : ""}`}
                  />
                </button>
              </CollapsibleTrigger>
              <CollapsibleContent className="space-y-3 pt-3">
                <p className="text-xs text-muted-foreground">
                  Use this only if you want to compile the IR saved in this
                  dashboard and push it to your voice provider instead of going
                  live with an existing voice agent.
                </p>
                <div className="space-y-1.5">
                  <Label htmlFor="retell-flow-id">Conversation flow ID (optional)</Label>
                  <Input
                    id="retell-flow-id"
                    placeholder="conversation_flow_xxxxxxxx"
                    value={flowId}
                    onChange={(e) => setFlowId(e.target.value)}
                  />
                </div>
                <Button
                  variant="secondary"
                  size="sm"
                  className="w-full"
                  disabled={deployMutation.isPending}
                  onClick={() =>
                    linkTarget &&
                    deployMutation.mutate({
                      id: linkTarget.id,
                      currentRetellAgentId: retellId.trim() || null,
                      agentType,
                      inboundPhoneNumber:
                        agentType === "receptionist" ? inboundPhone.trim() || null : null,
                    })
                  }
                >
                  {deployMutation.isPending ? (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  ) : null}
                  Compile &amp; push IR
                </Button>
              </CollapsibleContent>
            </Collapsible>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setLinkTarget(null)}>
              Cancel
            </Button>
            <Button
              disabled={
                goLiveMutation.isPending ||
                retellId.trim().length === 0 ||
                (agentType === "receptionist" && inboundPhone.trim().length === 0)
              }
              onClick={() =>
                linkTarget &&
                goLiveMutation.mutate({
                  id: linkTarget.id,
                  retellAgentId: retellId.trim(),
                  agentType,
                  inboundPhoneNumber:
                    agentType === "receptionist" ? inboundPhone.trim() || null : null,
                })
              }
            >
              {goLiveMutation.isPending ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Rocket className="mr-2 h-4 w-4" />
              )}
              Go Live
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function BookingToolChecklist() {
  return null;
}

function _OldBookingToolChecklist() {
  return (
    <Collapsible defaultOpen className="mb-6">
      <Card className="border-amber-500/30 bg-amber-500/[0.04]">
        <CollapsibleTrigger asChild>
          <button className="flex w-full items-center justify-between px-5 py-4 text-left">
            <div>
              <div className="text-sm font-semibold">Booking tool setup checklist</div>
              <div className="mt-0.5 text-xs text-muted-foreground">
                Cal.com is rejecting bookings with "attendee email or phone is wrong". Fix in Retell ↓
              </div>
            </div>
            <ChevronDown className="h-4 w-4 text-muted-foreground" />
          </button>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <CardContent className="space-y-4 border-t pt-4 text-sm">
            <div className="rounded-md border border-destructive/40 bg-destructive/10 p-3 text-xs">
              <div className="font-semibold text-destructive">Active error from your last call</div>
              <p className="mt-1 text-destructive/90">
                <code className="rounded bg-background/40 px-1">cal_util.js → bookCalEvent</code> →{" "}
                <em>"Attendee must have at least one contact method (email or phone number)"</em>
              </p>
              <p className="mt-2 text-muted-foreground">
                This means Retell's <strong>Book Appointment (Cal.com)</strong> function node fired without
                an email or phone bound to the attendee fields. Open the node in Retell → Conversation Flow
                and complete steps 1–2 below.
              </p>
            </div>
            <div>
              <div className="mb-1 font-medium">1. In Retell → your flow → Book Appointment node</div>
              <p className="text-xs text-muted-foreground">
                Cal.com v2 requires the attendee block to contain <code className="rounded bg-muted px-1">email</code> AND/OR
                {" "}<code className="rounded bg-muted px-1">phoneNumber</code>. In the Retell node's "Attendee" section,
                bind both fields to dynamic variables:
              </p>
              <ul className="mt-2 space-y-1 text-xs">
                <li>• <code className="rounded bg-muted px-1">email</code> → <code>{`{{attendee_email}}`}</code></li>
                <li>• <code className="rounded bg-muted px-1">phoneNumber</code> → <code>{`{{attendee_phone}}`}</code> (E.164, e.g. +447353303364)</li>
                <li>• <code className="rounded bg-muted px-1">name</code> → <code>{`{{attendee_name}}`}</code></li>
                <li>• <code className="rounded bg-muted px-1">timeZone</code> → <code>{`{{caller_timezone}}`}</code> or hard-code <code>Europe/London</code></li>
              </ul>
              <p className="mt-2 text-xs text-muted-foreground">
                If a field shows a literal value or is left blank, Retell sends an empty string → Cal.com 400s.
                Both must reference a variable that the agent has already collected.
              </p>
            </div>
            <div>
              <div className="mb-1 font-medium">2. Add a "collect contact" conversation node BEFORE the booking node</div>
              <p className="text-xs text-muted-foreground">
                The agent must extract these into variables before the function node runs. In your "collect contact"
                node, set extraction variables:
              </p>
              <ul className="mt-2 space-y-1 text-xs">
                <li>• <code className="rounded bg-muted px-1">attendee_name</code> (string, required)</li>
                <li>• <code className="rounded bg-muted px-1">attendee_email</code> (string, required) — prompt the agent to spell it back</li>
                <li>• <code className="rounded bg-muted px-1">attendee_phone</code> (string, required) — default to <code>{`{{caller_number}}`}</code> for inbound calls</li>
              </ul>
              <p className="mt-2 text-xs text-muted-foreground italic">
                Tip for inbound receptionist: pre-fill <code>attendee_phone</code> with the caller's number so the agent
                only has to confirm email.
              </p>
            </div>
            <div>
              <div className="mb-1 font-medium">3. Prompt rule for the agent</div>
              <p className="text-xs text-muted-foreground italic">
                "Before calling book_appointment, always confirm with the caller: full name, email
                address (spell it back), phone number, preferred date and time. Never call the
                booking tool with missing fields. If the caller refuses to give an email, offer to
                take a message instead."
              </p>
            </div>
            <div>
              <div className="mb-1 font-medium">4. Event type &amp; availability</div>
              <p className="text-xs text-muted-foreground">
                Confirm <code className="rounded bg-muted px-1">eventTypeId: 5831382</code> is set on the
                Book Appointment node. Add a <code className="rounded bg-muted px-1">check_availability</code> node before
                booking so the agent only offers real slots.
              </p>
            </div>
          </CardContent>
        </CollapsibleContent>
      </Card>
    </Collapsible>
  );
}
function AutoFixButton({ agentId }: { agentId: string }) {
  const fn = useServerFn(autoFixBookingTool);
  const m = useMutation({
    mutationFn: () => fn({ data: { agentId } }),
    onSuccess: (r) => {
      if (r.ok) {
        toast.success(r.message);
      } else {
        toast.error(r.message);
      }
      if (r.warnings?.length) {
        for (const w of r.warnings) toast.warning(w);
      }
    },
    onError: (e: unknown) => toast.error(e instanceof Error ? e.message : "Auto-fix failed"),
  });
  return (
    <Button size="sm" variant="outline" disabled={m.isPending} onClick={() => m.mutate()}>
      {m.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Wand2 className="mr-2 h-4 w-4" />}
      Auto-fix booking
    </Button>
  );
}
