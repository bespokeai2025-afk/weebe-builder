import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Phone, PhoneIncoming, PhoneOutgoing, PlayCircle } from "lucide-react";
import { PageHeader, PanelCard, EmptyState, StatCard } from "@/components/dashboard/PageShell";
import { listCalls } from "@/lib/dashboard.functions";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/calls")({
  head: () => ({ meta: [{ title: "Calls" }] }),
  component: CallsPage,
});

function fmtDuration(s?: number | null) {
  if (!s) return "—";
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${m}m ${r}s`;
}

function sentimentClass(v?: string | null) {
  if (v === "positive") return "bg-emerald-500/15 text-emerald-400";
  if (v === "negative") return "bg-destructive/15 text-destructive";
  if (v === "neutral") return "bg-muted text-muted-foreground";
  return "bg-muted/40 text-muted-foreground";
}

function statusClass(s?: string | null) {
  if (s === "completed") return "bg-emerald-500/15 text-emerald-400";
  if (s === "in_progress" || s === "ringing") return "bg-primary/15 text-primary";
  if (s === "failed" || s === "no_answer" || s === "busy") return "bg-destructive/15 text-destructive";
  if (s === "voicemail") return "bg-amber-500/15 text-amber-400";
  return "bg-muted text-muted-foreground";
}

function CallsPage() {
  const fn = useServerFn(listCalls);
  const q = useQuery({ queryKey: ["calls"], queryFn: () => fn({ data: {} }) });
  const rows = (q.data ?? []) as any[];
  const completed = rows.filter((r) => r.call_status === "completed").length;
  const failed = rows.filter((r) => ["failed", "no_answer", "busy"].includes(r.call_status)).length;
  const totalSec = rows.reduce((a, r) => a + (r.duration_seconds ?? 0), 0);
  return (
    <div className="pb-12">
      <PageHeader title="Calls" subtitle="Call activity, transcripts and outcomes" icon={Phone} onRefresh={() => q.refetch()} />
      <div className="grid grid-cols-2 gap-4 px-8 pt-6 md:grid-cols-4">
        <StatCard label="Total calls" tone="primary" value={rows.length} />
        <StatCard label="Completed" tone="success" value={completed} />
        <StatCard label="Failed" tone="danger" value={failed} />
        <StatCard label="Total talk" tone="info" value={fmtDuration(totalSec)} />
      </div>
      <div className="px-8 pt-6">
        <PanelCard>
          {rows.length === 0 ? (
            <EmptyState icon={Phone} title="No calls yet" message="Outbound and inbound calls will be logged here." />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-white/[0.06] text-left text-[11px] uppercase tracking-wider text-muted-foreground">
                    <th className="px-3 py-2">Contact</th>
                    <th className="px-3 py-2">Type</th>
                    <th className="px-3 py-2">Agent</th>
                    <th className="px-3 py-2">Status</th>
                    <th className="px-3 py-2">Sentiment</th>
                    <th className="px-3 py-2">Duration</th>
                    <th className="px-3 py-2">Recording</th>
                    <th className="px-3 py-2">When</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((c) => {
                    const inbound = c.call_type === "inbound";
                    const contact = c.lead?.full_name ?? (inbound ? c.from_number : c.to_number) ?? "Unknown";
                    return (
                      <tr key={c.id} className="border-b border-white/[0.04] align-top">
                        <td className="px-3 py-2 font-medium">
                          {contact}
                          {c.call_summary && (
                            <div className="mt-0.5 line-clamp-1 max-w-xs text-[11px] text-muted-foreground">
                              {c.call_summary}
                            </div>
                          )}
                        </td>
                        <td className="px-3 py-2">
                          <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
                            {inbound ? (
                              <PhoneIncoming className="h-3.5 w-3.5 text-primary" />
                            ) : (
                              <PhoneOutgoing className="h-3.5 w-3.5" />
                            )}
                            {inbound ? "Inbound · Receptionist" : "Outbound · Lead gen"}
                          </span>
                        </td>
                        <td className="px-3 py-2 text-muted-foreground">{c.agent_name ?? "—"}</td>
                        <td className="px-3 py-2">
                          <span className={cn("rounded-full px-2 py-0.5 text-[11px] capitalize", statusClass(c.call_status))}>
                            {String(c.call_status ?? "").replace(/_/g, " ")}
                          </span>
                        </td>
                        <td className="px-3 py-2">
                          {c.sentiment ? (
                            <span className={cn("rounded-full px-2 py-0.5 text-[11px] capitalize", sentimentClass(c.sentiment))}>
                              {c.sentiment}
                            </span>
                          ) : (
                            <span className="text-xs text-muted-foreground">—</span>
                          )}
                        </td>
                        <td className="px-3 py-2 text-muted-foreground tabular-nums">{fmtDuration(c.duration_seconds)}</td>
                        <td className="px-3 py-2">
                          {c.recording_url ? (
                            <a
                              href={c.recording_url}
                              target="_blank"
                              rel="noreferrer"
                              className="inline-flex items-center gap-1 text-xs text-primary hover:underline"
                            >
                              <PlayCircle className="h-3.5 w-3.5" /> Play
                            </a>
                          ) : (
                            <span className="text-xs text-muted-foreground">—</span>
                          )}
                        </td>
                        <td className="px-3 py-2 text-muted-foreground">{c.started_at ? new Date(c.started_at).toLocaleString() : "—"}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </PanelCard>
      </div>
    </div>
  );
}