import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Settings as SettingsIcon, Copy, Plus, Trash2, KeyRound } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { PageHeader, PanelCard } from "@/components/dashboard/PageShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { getWorkspaceSettings, saveWorkspaceSettings } from "@/lib/dashboard.functions";
import {
  listWorkspaceApiTokens,
  createWorkspaceApiToken,
  revokeWorkspaceApiToken,
} from "@/lib/api-tokens.functions";
import { BuilderSyncSection } from "@/components/settings/BuilderSyncSection";

// Stable published URL — same host whether viewed from preview, dev,
// or the published site, so webhook URLs copied from settings always
// point at the deployed endpoint.
const PUBLISHED_ORIGIN =
  "https://project--5ac2a13e-280d-409c-99e9-989a09464b56.lovable.app";

export const Route = createFileRoute("/_authenticated/settings")({
  head: () => ({ meta: [{ title: "Settings" }] }),
  component: SettingsPage,
});

function SettingsPage() {
  const getFn = useServerFn(getWorkspaceSettings);
  const saveFn = useServerFn(saveWorkspaceSettings);
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["workspace-settings"], queryFn: () => getFn() });
  const [form, setForm] = useState({
    business_name: "",
    timezone: "UTC",
    notification_email: "",
    retell_default_agent_id: "",
    calcom_api_token: "",
    calcom_event_type_id: "",
    calcom_webhook_secret: "",
    whatsapp_phone_id: "",
    twilio_auth_token: "",
    builder_base_url: "",
    builder_api_token: "",
  });

  useEffect(() => {
    const s = (q.data as any)?.settings;
    if (s) {
      setForm({
        business_name: s.business_name ?? "",
        timezone: s.timezone ?? "UTC",
        notification_email: s.notification_email ?? "",
        retell_default_agent_id: s.retell_default_agent_id ?? "",
        calcom_api_token: s.calcom_api_token ?? "",
        calcom_event_type_id: s.calcom_event_type_id ?? "",
        calcom_webhook_secret: s.calcom_webhook_secret ?? "",
        whatsapp_phone_id: s.whatsapp_phone_id ?? "",
        twilio_auth_token: s.twilio_auth_token ?? "",
        builder_base_url: s.builder_base_url ?? "",
        builder_api_token: s.builder_api_token ?? "",
      });
    }
  }, [q.data]);

  const m = useMutation({
    mutationFn: () => saveFn({ data: form }),
    onSuccess: () => {
      toast.success("Settings saved");
      qc.invalidateQueries({ queryKey: ["workspace-settings"] });
    },
    onError: (e: any) => toast.error(e?.message ?? "Failed to save"),
  });

  const field = (k: keyof typeof form, label: string, placeholder?: string) => (
    <div className="space-y-1.5">
      <Label htmlFor={k} className="text-xs uppercase tracking-wider text-muted-foreground">{label}</Label>
      <Input id={k} value={form[k]} placeholder={placeholder} onChange={(e) => setForm((f) => ({ ...f, [k]: e.target.value }))} />
    </div>
  );

  return (
    <div className="pb-12">
      <PageHeader title="Settings" subtitle="Workspace preferences and integrations" icon={SettingsIcon} />
      <div className="space-y-4 px-8 pt-6">
        <PanelCard>
          <h3 className="mb-4 text-sm font-semibold">Workspace</h3>
          <div className="grid gap-4 md:grid-cols-2">
            {field("business_name", "Business name", "Acme Inc")}
            {field("timezone", "Timezone", "UTC")}
            {field("notification_email", "Notification email", "alerts@example.com")}
          </div>
        </PanelCard>
        <PanelCard>
          <h3 className="mb-4 text-sm font-semibold">Integrations</h3>
          <div className="grid gap-4 md:grid-cols-2">
            {field("retell_default_agent_id", "Default voice agent ID")}
            {field("calcom_api_token", "Cal.com API token", "cal_live_...")}
            {field("calcom_event_type_id", "Cal.com event type ID")}
            {field("whatsapp_phone_id", "WhatsApp phone ID")}
            {field("calcom_webhook_secret", "Cal.com webhook secret", "whsec_...")}
            {field("twilio_auth_token", "Twilio auth token (WhatsApp)", "Found in Twilio Console")}
          </div>
          <CalcomWebhookHint workspaceId={(q.data as any)?.workspaceId} />
          <TwilioWebhookHint workspaceId={(q.data as any)?.workspaceId} />
          <RetellWebhookHint />
        </PanelCard>
        <ApiTokensSection workspaceId={(q.data as any)?.workspaceId} />
        <BuilderConnectHint workspaceId={(q.data as any)?.workspaceId} />
        <BuilderSyncSection
          form={form}
          setForm={setForm}
          lastSyncedAt={(q.data as any)?.settings?.builder_last_synced_at ?? null}
          lastStatus={(q.data as any)?.settings?.builder_last_sync_status ?? null}
          saveFirst={() => m.mutateAsync()}
        />
        <div className="flex justify-end">
          <Button onClick={() => m.mutate()} disabled={m.isPending} className="bg-primary text-primary-foreground">
            {m.isPending ? "Saving…" : "Save changes"}
          </Button>
        </div>
      </div>
    </div>
  );
}

function ApiTokensSection({ workspaceId }: { workspaceId?: string }) {
  const listFn = useServerFn(listWorkspaceApiTokens);
  const createFn = useServerFn(createWorkspaceApiToken);
  const revokeFn = useServerFn(revokeWorkspaceApiToken);
  const qc = useQueryClient();
  const [name, setName] = useState("");
  const [revealed, setRevealed] = useState<{ name: string; plaintext: string } | null>(null);

  const tokensQuery = useQuery({
    queryKey: ["workspace-api-tokens", workspaceId],
    queryFn: () => listFn({ data: { workspaceId: workspaceId! } }),
    enabled: !!workspaceId,
  });

  const createMut = useMutation({
    mutationFn: () => createFn({ data: { workspaceId: workspaceId!, name: name.trim() } }),
    onSuccess: (res: any) => {
      setRevealed({ name: res.name, plaintext: res.plaintext });
      setName("");
      qc.invalidateQueries({ queryKey: ["workspace-api-tokens", workspaceId] });
    },
    onError: (e: any) => toast.error(e?.message ?? "Failed to create token"),
  });

  const revokeMut = useMutation({
    mutationFn: (id: string) => revokeFn({ data: { id } }),
    onSuccess: () => {
      toast.success("Token revoked");
      qc.invalidateQueries({ queryKey: ["workspace-api-tokens", workspaceId] });
    },
    onError: (e: any) => toast.error(e?.message ?? "Revoke failed"),
  });

  const endpoint = `${PUBLISHED_ORIGIN}/api/public/agents/register`;

  if (!workspaceId) return null;

  return (
    <PanelCard>
      <div className="mb-2 flex items-center gap-2">
        <KeyRound className="h-4 w-4 text-muted-foreground" />
        <h3 className="text-sm font-semibold">API tokens</h3>
      </div>
      <p className="mb-4 text-xs text-muted-foreground">
        Generate a token for the Agent Builder to call this dashboard's Go Live endpoint.
        Send it as <code className="rounded bg-muted px-1">Authorization: Bearer &lt;token&gt;</code>{" "}
        when POSTing to <code className="rounded bg-muted px-1">{endpoint}</code>.
      </p>

      {revealed ? (
        <div className="mb-4 rounded-md border border-primary/40 bg-primary/5 p-3">
          <p className="text-xs font-medium">Copy this token now — it won't be shown again.</p>
          <div className="mt-2 flex items-center gap-2">
            <code className="flex-1 truncate rounded bg-background px-2 py-1.5 font-mono text-xs">
              {revealed.plaintext}
            </code>
            <Button
              size="sm"
              variant="outline"
              onClick={() => {
                navigator.clipboard.writeText(revealed.plaintext);
                toast.success("Copied");
              }}
            >
              <Copy className="h-3.5 w-3.5" />
            </Button>
            <Button size="sm" variant="ghost" onClick={() => setRevealed(null)}>
              Done
            </Button>
          </div>
        </div>
      ) : null}

      <div className="mb-4 flex gap-2">
        <Input
          placeholder="Token name (e.g. Agent Builder)"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <Button
          onClick={() => createMut.mutate()}
          disabled={createMut.isPending || name.trim().length === 0}
        >
          <Plus className="mr-1.5 h-4 w-4" />
          Generate
        </Button>
      </div>

      <div className="space-y-2">
        {tokensQuery.isLoading ? (
          <p className="text-xs text-muted-foreground">Loading…</p>
        ) : (tokensQuery.data ?? []).length === 0 ? (
          <p className="text-xs text-muted-foreground">No tokens yet.</p>
        ) : (
          (tokensQuery.data as any[]).map((t) => (
            <div
              key={t.id}
              className="flex items-center justify-between rounded-md border bg-background p-3"
            >
              <div className="min-w-0">
                <div className="flex items-center gap-2 text-sm font-medium">
                  {t.name}
                  {t.revoked_at ? (
                    <span className="rounded bg-muted px-1.5 py-0.5 text-[10px] uppercase text-muted-foreground">
                      Revoked
                    </span>
                  ) : null}
                </div>
                <div className="mt-0.5 truncate font-mono text-[11px] text-muted-foreground">
                  {t.prefix}…
                  {t.last_used_at ? ` · last used ${new Date(t.last_used_at).toLocaleString()}` : " · never used"}
                </div>
              </div>
              {!t.revoked_at ? (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => revokeMut.mutate(t.id)}
                  disabled={revokeMut.isPending}
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              ) : null}
            </div>
          ))
        )}
      </div>
    </PanelCard>
  );
}

function CalcomWebhookHint({ workspaceId }: { workspaceId?: string }) {
  if (!workspaceId) return null;
  const url = `${PUBLISHED_ORIGIN}/api/public/calcom-webhook/${workspaceId}`;
  return (
    <div className="mt-4 rounded-md border bg-muted/30 p-3 text-xs text-muted-foreground">
      <div className="mb-1 flex items-center gap-2 font-medium text-foreground">
        Cal.com webhook URL
        <span className="rounded-full bg-primary/15 px-2 py-0.5 text-[10px] uppercase tracking-wider text-primary">
          Auto-registered
        </span>
      </div>
      <div className="flex items-center gap-2">
        <code className="flex-1 truncate rounded bg-background px-2 py-1.5 font-mono text-[11px]">
          {url}
        </code>
        <Button
          size="sm"
          variant="outline"
          onClick={() => {
            navigator.clipboard.writeText(url);
            toast.success("Copied");
          }}
        >
          <Copy className="h-3.5 w-3.5" />
        </Button>
      </div>
      <p className="mt-2">
        As soon as your Cal.com API token is saved (or pushed from the Agent
        Builder), we register this webhook on Cal.com automatically and store
        a generated signing secret. No manual paste required.
      </p>
    </div>
  );
}

function TwilioWebhookHint({ workspaceId }: { workspaceId?: string }) {
  if (!workspaceId) return null;
  const url = `${PUBLISHED_ORIGIN}/api/public/whatsapp-webhook/${workspaceId}`;
  return (
    <div className="mt-4 rounded-md border bg-muted/30 p-3 text-xs text-muted-foreground">
      <div className="mb-1 font-medium text-foreground">Twilio WhatsApp webhook URL</div>
      <div className="flex items-center gap-2">
        <code className="flex-1 truncate rounded bg-background px-2 py-1.5 font-mono text-[11px]">
          {url}
        </code>
        <Button
          size="sm"
          variant="outline"
          onClick={() => {
            navigator.clipboard.writeText(url);
            toast.success("Copied");
          }}
        >
          <Copy className="h-3.5 w-3.5" />
        </Button>
      </div>
      <p className="mt-2">
        In Twilio Console → Messaging → your WhatsApp sender, set the "When a message
        comes in" webhook to this URL with method <code className="rounded bg-background px-1">POST</code>.
        Save your Twilio auth token above so we can verify each event's signature.
      </p>
    </div>
  );
}

function RetellWebhookHint() {
  const url = `${PUBLISHED_ORIGIN}/api/public/voice-webhook`;
  return (
    <div className="mt-4 rounded-md border bg-muted/30 p-3 text-xs text-muted-foreground">
      <div className="mb-1 flex items-center gap-2 font-medium text-foreground">
        Voice agent webhook URL
        <span className="rounded-full bg-primary/15 px-2 py-0.5 text-[10px] uppercase tracking-wider text-primary">
          Auto-registered
        </span>
      </div>
      <div className="flex items-center gap-2">
        <code className="flex-1 truncate rounded bg-background px-2 py-1.5 font-mono text-[11px]">
          {url}
        </code>
        <Button
          size="sm"
          variant="outline"
          onClick={() => {
            navigator.clipboard.writeText(url);
            toast.success("Copied");
          }}
        >
          <Copy className="h-3.5 w-3.5" />
        </Button>
      </div>
      <p className="mt-2">
        Set on every agent automatically when the Agent Builder publishes —
        you should never need to copy this manually.
      </p>
    </div>
  );
}

function BuilderConnectHint({ workspaceId }: { workspaceId?: string }) {
  if (!workspaceId) return null;
  const url = `${PUBLISHED_ORIGIN}/api/public/agents/register`;
  const examplePayload = JSON.stringify(
    {
      retellAgentId: "agent_xxxxxxxxxxxxxxxx",
      name: "My agent",
      agentType: "receptionist",
      inboundPhoneNumber: "+447353303364",
      retellConversationFlowId: "conversation_flow_xxxxxxxx",
    },
    null,
    2,
  );
  const curl = `curl -X POST '${url}' \\\n  -H 'Authorization: Bearer <WORKSPACE_API_TOKEN>' \\\n  -H 'Content-Type: application/json' \\\n  -d '${examplePayload.replace(/\n/g, "")}'`;
  const examplePayloadFull = JSON.stringify(
    {
      retellAgentId: "agent_xxxxxxxxxxxxxxxx",
      name: "My agent",
      agentType: "receptionist",
      inboundPhoneNumber: "+447353303364",
      retellConversationFlowId: "conversation_flow_xxxxxxxx",
      integrations: {
        calcom: { apiToken: "cal_live_xxx", eventTypeId: "123456" },
        twilio: { authToken: "xxx", phoneId: "MGxxxx" },
        timezone: "Europe/London",
        businessName: "Acme Inc",
        notificationEmail: "alerts@acme.com",
      },
      builderCallbackUrl: "https://your-builder.app/api/dashboard-sync",
    },
    null,
    2,
  );
  return (
    <PanelCard>
      <h3 className="mb-1 text-sm font-semibold">Connect Agent Builder</h3>
      <p className="mb-4 text-xs text-muted-foreground">
        The Agent Builder pushes deployed agents AND integration credentials
        (Cal.com, Twilio, timezone) here in one call. The dashboard then auto-
        registers every webhook (voice, Cal.com, WhatsApp) and posts back to{" "}
        <code className="rounded bg-muted px-1">builderCallbackUrl</code> so
        both apps stay in sync — zero manual setup.
      </p>
      <div className="space-y-3">
        <div>
          <div className="mb-1 text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
            Endpoint URL
          </div>
          <div className="flex items-center gap-2">
            <code className="flex-1 truncate rounded bg-muted/40 px-2 py-1.5 font-mono text-[11px]">
              {url}
            </code>
            <Button
              size="sm"
              variant="outline"
              onClick={() => {
                navigator.clipboard.writeText(url);
                toast.success("Copied");
              }}
            >
              <Copy className="h-3.5 w-3.5" />
            </Button>
          </div>
        </div>
        <div>
          <div className="mb-1 text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
            Workspace ID
          </div>
          <div className="flex items-center gap-2">
            <code className="flex-1 truncate rounded bg-muted/40 px-2 py-1.5 font-mono text-[11px]">
              {workspaceId}
            </code>
            <Button
              size="sm"
              variant="outline"
              onClick={() => {
                navigator.clipboard.writeText(workspaceId);
                toast.success("Copied");
              }}
            >
              <Copy className="h-3.5 w-3.5" />
            </Button>
          </div>
        </div>
        <div>
          <div className="mb-1 text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
            Full example payload (integrations + two-way sync)
          </div>
          <pre className="overflow-x-auto rounded-md border bg-muted/30 p-3 font-mono text-[11px] leading-relaxed">
{examplePayloadFull}
          </pre>
        </div>
        <ul className="list-disc space-y-1 pl-4 text-xs text-muted-foreground">
          <li>Required: <code>retellAgentId</code>, <code>name</code>.</li>
          <li>
            Anything under <code>integrations</code> overwrites this
            workspace's settings (Cal.com API token, event type, Twilio creds,
            timezone, business name, notification email).
          </li>
          <li>
            With a Cal.com token present we call Cal.com's API and register the
            booking webhook automatically — no dashboard paste.
          </li>
          <li>
            <code>builderCallbackUrl</code>: dashboard POSTs the resulting
            agent id + all webhook URLs back to your builder so it can store
            them next to its own copy.
          </li>
        </ul>
      </div>
    </PanelCard>
  );
}