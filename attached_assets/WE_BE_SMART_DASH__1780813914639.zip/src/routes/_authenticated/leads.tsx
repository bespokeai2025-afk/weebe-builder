import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Users } from "lucide-react";
import { PageHeader, PanelCard, EmptyState, StatCard } from "@/components/dashboard/PageShell";
import { listCalledQualifiedRecords } from "@/lib/dashboard.functions";

export const Route = createFileRoute("/_authenticated/leads")({
  head: () => ({ meta: [{ title: "Leads" }] }),
  component: LeadsPage,
});

function fmtDate(d: string | null) {
  if (!d) return "—";
  try {
    return new Date(d).toLocaleString();
  } catch {
    return d;
  }
}

function fmtDuration(s: number | null) {
  if (!s || s <= 0) return "—";
  const m = Math.floor(s / 60);
  const r = s % 60;
  return m > 0 ? `${m}m ${r}s` : `${r}s`;
}

function LeadsPage() {
  const fn = useServerFn(listCalledQualifiedRecords);
  const q = useQuery({ queryKey: ["leads-qualified"], queryFn: () => fn() });
  const rows = (q.data ?? []) as { record: any; call: any }[];
  const positive = rows.filter((r) => r.call.sentiment === "positive").length;
  const neutral = rows.filter((r) => r.call.sentiment === "neutral").length;

  return (
    <div className="pb-12">
      <PageHeader
        title="Leads"
        subtitle="Clients called by your voice agent with a neutral or positive outcome"
        icon={Users}
        onRefresh={() => q.refetch()}
      />
      <div className="grid grid-cols-2 gap-4 px-8 pt-6 md:grid-cols-3">
        <StatCard label="Qualified leads" tone="primary" value={rows.length} />
        <StatCard label="Positive" tone="success" value={positive} />
        <StatCard label="Neutral" tone="warning" value={neutral} />
      </div>
      <div className="px-8 pt-6">
        <PanelCard>
          {q.isLoading ? (
            <p className="px-4 py-8 text-center text-sm text-muted-foreground">Loading…</p>
          ) : rows.length === 0 ? (
            <EmptyState
              icon={Users}
              title="No qualified leads yet"
              message="Once your voice agent calls clients from the Data section and a call ends with neutral or positive sentiment, they'll appear here."
            />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-white/[0.06] text-left text-[11px] uppercase tracking-wider text-muted-foreground">
                    <th className="px-3 py-2">Name</th>
                    <th className="px-3 py-2">Mobile</th>
                    <th className="px-3 py-2">Email</th>
                    <th className="px-3 py-2">City</th>
                    <th className="px-3 py-2">Sentiment</th>
                    <th className="px-3 py-2">Outcome</th>
                    <th className="px-3 py-2">Duration</th>
                    <th className="px-3 py-2">Last call</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map(({ record: r, call: c }) => (
                    <tr key={r.id} className="border-b border-white/[0.04] align-top">
                      <td className="px-3 py-2 font-medium">{r.name ?? "—"}</td>
                      <td className="whitespace-nowrap px-3 py-2 text-muted-foreground">{r.mobile_number}</td>
                      <td className="px-3 py-2 text-muted-foreground">{r.email ?? "—"}</td>
                      <td className="px-3 py-2 text-muted-foreground">{r.city ?? "—"}</td>
                      <td className="px-3 py-2">
                        <span
                          className={
                            c.sentiment === "positive"
                              ? "rounded-full bg-emerald-500/15 px-2 py-0.5 text-[11px] text-emerald-400"
                              : "rounded-full bg-amber-500/15 px-2 py-0.5 text-[11px] text-amber-400"
                          }
                        >
                          {c.sentiment}
                        </span>
                      </td>
                      <td className="px-3 py-2 text-muted-foreground">{c.call_outcome ?? c.call_status ?? "—"}</td>
                      <td className="whitespace-nowrap px-3 py-2 text-muted-foreground">{fmtDuration(c.duration_seconds)}</td>
                      <td className="whitespace-nowrap px-3 py-2 text-muted-foreground">{fmtDate(c.started_at)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </PanelCard>
      </div>
    </div>
  );
}