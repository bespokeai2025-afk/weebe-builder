import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { CheckCircle2, Rocket, XCircle } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { listMyDeployments } from "@/lib/agents.functions";

export const Route = createFileRoute("/_authenticated/deployments")({
  head: () => ({ meta: [{ title: "Deployments" }] }),
  component: DeploymentsPage,
});

function DeploymentsPage() {
  const fetchFn = useServerFn(listMyDeployments);
  const { data, isLoading } = useQuery({
    queryKey: ["deployments"],
    queryFn: () => fetchFn(),
  });

  return (
    <div className="mx-auto max-w-6xl px-6 py-8">
      <div className="mb-8">
        <p className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">Audit log</p>
        <h1 className="text-2xl font-semibold tracking-tight">Deployments</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Every time an agent is pushed to a provider, we record it here.
        </p>
      </div>

      {isLoading ? (
        <p className="text-sm text-muted-foreground">Loading…</p>
      ) : !data || data.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-16 text-center">
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
              <Rocket className="h-6 w-6" />
            </div>
            <h3 className="text-lg font-semibold">No deployments yet</h3>
            <p className="mt-1 text-sm text-muted-foreground">
              Push an agent from the builder to see it here.
            </p>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="p-0">
            <div className="grid grid-cols-12 gap-2 border-b px-5 py-3 text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
              <div className="col-span-1">Status</div>
              <div className="col-span-3">Provider agent</div>
              <div className="col-span-2">Provider</div>
              <div className="col-span-3">Error</div>
              <div className="col-span-3 text-right">When</div>
            </div>
            <ul className="divide-y divide-border/60">
              {data.map((d) => (
                <li key={d.id as string} className="grid grid-cols-12 items-center gap-2 px-5 py-3 text-sm">
                  <div className="col-span-1">
                    {d.status === "success" ? (
                      <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                    ) : (
                      <XCircle className="h-4 w-4 text-destructive" />
                    )}
                  </div>
                  <code className="col-span-3 truncate text-xs">{(d.provider_agent_id as string) ?? "—"}</code>
                  <div className="col-span-2"><Badge variant="outline">{d.provider as string}</Badge></div>
                  <div className="col-span-3 truncate text-xs text-destructive/80">{(d.error as string) ?? ""}</div>
                  <div className="col-span-3 text-right text-xs text-muted-foreground">
                    {new Date(d.deployed_at as string).toLocaleString()}
                  </div>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}
    </div>
  );
}