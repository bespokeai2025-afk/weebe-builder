import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  Database,
  PhoneOutgoing,
  CalendarClock,
  UserCheck,
  Filter,
  Search,
} from "lucide-react";
import { useState, useMemo } from "react";
import { toast } from "sonner";
import {
  PageHeader,
  PanelCard,
  EmptyState,
  StatCard,
} from "@/components/dashboard/PageShell";
import {
  listDataRecords,
  importDataRecords,
  assignAgentToRecords,
  scheduleCallsForRecords,
  startCallingRecords,
  setRecordCallStatus,
  getCallSchedule,
  setCallSchedule,
} from "@/lib/dashboard.functions";
import { listMyAgents } from "@/lib/agents.functions";
import { CsvUploader, type ParsedRow } from "@/components/dashboard/CsvUploader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";

export const Route = createFileRoute("/_authenticated/data")({
  head: () => ({ meta: [{ title: "Data" }] }),
  component: DataPage,
});

const STATUS_OPTIONS = [
  { value: "all", label: "All statuses" },
  { value: "needs_to_call", label: "Needs to call" },
  { value: "queued", label: "Queued" },
  { value: "calling", label: "Calling" },
  { value: "completed", label: "Completed" },
  { value: "failed", label: "Failed" },
  { value: "do_not_call", label: "Do not call" },
] as const;

type StatusValue = (typeof STATUS_OPTIONS)[number]["value"];

const STATUS_BADGES: Record<string, { label: string; cls: string }> = {
  needs_to_call: { label: "Needs to call", cls: "bg-amber-500/15 text-amber-300 border-amber-500/30" },
  queued: { label: "Queued", cls: "bg-sky-500/15 text-sky-300 border-sky-500/30" },
  calling: { label: "Calling…", cls: "bg-violet-500/15 text-violet-300 border-violet-500/30" },
  completed: { label: "Completed", cls: "bg-emerald-500/15 text-emerald-300 border-emerald-500/30" },
  failed: { label: "Failed", cls: "bg-rose-500/15 text-rose-300 border-rose-500/30" },
  do_not_call: { label: "Do not call", cls: "bg-muted text-muted-foreground border-white/[0.06]" },
};

const SENTIMENT_BADGES: Record<string, string> = {
  positive: "bg-emerald-500/15 text-emerald-300",
  neutral: "bg-amber-500/15 text-amber-300",
  negative: "bg-rose-500/15 text-rose-300",
};

const DAY_NAMES = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

function DataPage() {
  const fn = useServerFn(listDataRecords);
  const importFn = useServerFn(importDataRecords);
  const scheduleFn = useServerFn(scheduleCallsForRecords);
  const startFn = useServerFn(startCallingRecords);
  const agentsFn = useServerFn(listMyAgents);
  const getScheduleFn = useServerFn(getCallSchedule);
  const setScheduleFn = useServerFn(setCallSchedule);
  const qc = useQueryClient();

  const [showUploader, setShowUploader] = useState(false);
  const [importProgress, setImportProgress] = useState<{ done: number; total: number } | null>(null);

  // Filters
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<StatusValue>("all");
  const [agentFilter, setAgentFilter] = useState<string>("all");

  // Selection
  const [selected, setSelected] = useState<Set<string>>(new Set());

  // Modals
  const [scheduleOpen, setScheduleOpen] = useState(false);
  const [callScheduleOpen, setCallScheduleOpen] = useState(false);
  const [startCallOpen, setStartCallOpen] = useState(false);

  const q = useQuery({
    queryKey: ["data-records", search, statusFilter, agentFilter],
    queryFn: () =>
      fn({
        data: {
          search: search || undefined,
          callStatus: statusFilter,
          assignedAgentId:
            agentFilter === "all" || agentFilter === "unassigned" ? undefined : agentFilter,
          unassignedOnly: agentFilter === "unassigned",
        },
      }),
  });

  const agentsQ = useQuery({ queryKey: ["my-agents"], queryFn: () => agentsFn() });
  const agents = (agentsQ.data ?? []) as any[];

  const scheduleQ = useQuery({
    queryKey: ["call-schedule"],
    queryFn: () => getScheduleFn(),
  });

  const rows = (q.data ?? []) as any[];
  const needCall = rows.filter((r) => r.call_status === "needs_to_call").length;
  const queued = rows.filter((r) => r.call_status === "queued").length;
  const completed = rows.filter((r) => r.call_status === "completed").length;

  const agentName = (id: string | null) =>
    id ? agents.find((a) => a.id === id)?.name ?? "—" : "—";

  const ALL_FIELDS: { key: string; label: string }[] = [
    { key: "name", label: "Name" },
    { key: "first_name", label: "First name" },
    { key: "last_name", label: "Last name" },
    { key: "title", label: "Title" },
    { key: "mobile_number", label: "Mobile" },
    { key: "email", label: "Email" },
    { key: "client_name", label: "Client" },
    { key: "unique_id", label: "Unique ID" },
    { key: "property_type", label: "Property type" },
    { key: "bedrooms", label: "Bedrooms" },
    { key: "address_line1", label: "Address 1" },
    { key: "address_line2", label: "Address 2" },
    { key: "city", label: "City" },
    { key: "state", label: "State" },
    { key: "postal_code", label: "Postcode" },
  ];

  const visibleFields = ALL_FIELDS.filter((f) =>
    rows.some((r) => r[f.key] != null && String(r[f.key]).trim() !== ""),
  );

  const MAX_ROWS = 50000;
  const CHUNK_SIZE = 5000;

  const toggleAll = (checked: boolean) => {
    setSelected(checked ? new Set(rows.map((r) => r.id)) : new Set());
  };
  const toggleOne = (id: string, checked: boolean) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (checked) next.add(id);
      else next.delete(id);
      return next;
    });
  };
  const allSelected = rows.length > 0 && selected.size === rows.length;

  const importMut = useMutation({
    mutationFn: async (parsed: ParsedRow[]) => {
      if (parsed.length > MAX_ROWS) {
        throw new Error(`Maximum ${MAX_ROWS.toLocaleString()} rows per import. Got ${parsed.length.toLocaleString()}.`);
      }
      const total = parsed.length;
      let inserted = 0;
      setImportProgress({ done: 0, total });
      const toastId = toast.loading(`Importing 0 / ${total.toLocaleString()}…`);
      try {
        for (let i = 0; i < total; i += CHUNK_SIZE) {
          const slice = parsed.slice(i, i + CHUNK_SIZE);
          const res = await importFn({ data: { rows: slice as any } });
          inserted += res.inserted;
          setImportProgress({ done: Math.min(i + CHUNK_SIZE, total), total });
          toast.loading(`Importing ${Math.min(i + CHUNK_SIZE, total).toLocaleString()} / ${total.toLocaleString()}…`, { id: toastId });
        }
        toast.dismiss(toastId);
      } catch (e) {
        toast.dismiss(toastId);
        throw e;
      }
      return { inserted };
    },
    onSuccess: (res) => {
      toast.success(`Imported ${res.inserted.toLocaleString()} records`);
      setShowUploader(false);
      setImportProgress(null);
      qc.invalidateQueries({ queryKey: ["data-records"] });
    },
    onError: (e: any) => {
      setImportProgress(null);
      toast.error(e?.message ?? "Import failed");
    },
  });

  const refreshRecords = () => qc.invalidateQueries({ queryKey: ["data-records"] });

  const startMut = useMutation({
    mutationFn: (input: { recordIds: string[]; agentId?: string | null; fromNumber?: string | null }) =>
      startFn({ data: input }),
    onSuccess: (res) => {
      toast.success(`Started: ${res.placed} placed, ${res.queued} queued, ${res.failed} failed`);
      setStartCallOpen(false);
      setSelected(new Set());
      refreshRecords();
    },
    onError: (e: any) => toast.error(e?.message ?? "Failed to start calls"),
  });

  const scheduleMut = useMutation({
    mutationFn: (input: { recordIds: string[]; scheduledAt: string | null; agentId?: string | null }) =>
      scheduleFn({ data: input }),
    onSuccess: (res) => {
      toast.success(`Scheduled ${res.updated} records`);
      setScheduleOpen(false);
      setSelected(new Set());
      refreshRecords();
    },
    onError: (e: any) => toast.error(e?.message ?? "Failed to schedule"),
  });

  const setScheduleMut = useMutation({
    mutationFn: (input: any) => setScheduleFn({ data: input }),
    onSuccess: () => {
      toast.success("Call schedule saved");
      setCallScheduleOpen(false);
      qc.invalidateQueries({ queryKey: ["call-schedule"] });
    },
    onError: (e: any) => toast.error(e?.message ?? "Failed to save"),
  });

  return (
    <div className="pb-12">
      <PageHeader
        title="Data"
        subtitle="Imported records ready for outreach"
        icon={Database}
        onRefresh={() => q.refetch()}
        actions={
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => setCallScheduleOpen(true)}>
              <CalendarClock className="mr-2 h-4 w-4" />
              Call schedule
            </Button>
            <Button onClick={() => setShowUploader((s) => !s)} className="bg-primary text-primary-foreground">
              {showUploader ? "Close" : "Upload CSV"}
            </Button>
          </div>
        }
      />
      {showUploader && (
        <div className="px-8 pt-6">
          <PanelCard>
            <CsvUploader onImport={(r) => importMut.mutate(r)} isImporting={importMut.isPending} />
            {importProgress && (
              <div className="mt-4">
                <div className="mb-1 flex justify-between text-xs text-muted-foreground">
                  <span>Uploading…</span>
                  <span>{importProgress.done.toLocaleString()} / {importProgress.total.toLocaleString()}</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-white/[0.06]">
                  <div
                    className="h-full bg-primary transition-all"
                    style={{ width: `${Math.round((importProgress.done / Math.max(1, importProgress.total)) * 100)}%` }}
                  />
                </div>
              </div>
            )}
          </PanelCard>
        </div>
      )}

      <div className="grid grid-cols-2 gap-4 px-8 pt-6 md:grid-cols-4">
        <StatCard label="Total records" tone="primary" value={rows.length} />
        <StatCard label="Need to call" tone="warning" value={needCall} />
        <StatCard label="Queued" tone="info" value={queued} />
        <StatCard label="Completed" tone="success" value={completed} />
      </div>

      <div className="px-8 pt-6">
        <PanelCard className="!p-4">
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative min-w-[220px] flex-1">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search name, mobile or email…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as StatusValue)}>
              <SelectTrigger className="w-[170px]">
                <Filter className="mr-2 h-4 w-4" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {STATUS_OPTIONS.map((o) => (
                  <SelectItem key={o.value} value={o.value}>
                    {o.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={agentFilter} onValueChange={setAgentFilter}>
              <SelectTrigger className="w-[200px]">
                <UserCheck className="mr-2 h-4 w-4" />
                <SelectValue placeholder="Agent" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All agents</SelectItem>
                <SelectItem value="unassigned">Unassigned</SelectItem>
                {agents.map((a) => (
                  <SelectItem key={a.id} value={a.id}>
                    {a.name} {a.retell_agent_id ? "" : "(draft)"}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <div className="ml-auto flex items-center gap-2">
              <span className="text-xs text-muted-foreground">{selected.size} selected</span>
              <Button
                size="sm"
                variant="outline"
                disabled={selected.size === 0}
                onClick={() => setScheduleOpen(true)}
              >
                <CalendarClock className="mr-1.5 h-4 w-4" /> Schedule
              </Button>
              <Button
                size="sm"
                disabled={selected.size === 0}
                onClick={() => setStartCallOpen(true)}
                className="bg-primary text-primary-foreground"
              >
                <PhoneOutgoing className="mr-1.5 h-4 w-4" /> Start calling
              </Button>
            </div>
          </div>
        </PanelCard>
      </div>

      <div className="px-8 pt-6">
        <PanelCard>
          {rows.length === 0 ? (
            <EmptyState icon={Database} title="No data records" message="Upload a CSV or sync from a source to see records." />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-white/[0.06] text-left text-[11px] uppercase tracking-wider text-muted-foreground">
                    <th className="px-3 py-2">
                      <Checkbox
                        checked={allSelected}
                        onCheckedChange={(c) => toggleAll(Boolean(c))}
                        aria-label="Select all"
                      />
                    </th>
                    {visibleFields.map((f) => (
                      <th key={f.key} className="whitespace-nowrap px-3 py-2">{f.label}</th>
                    ))}
                    <th className="px-3 py-2">Agent</th>
                    <th className="px-3 py-2">Scheduled</th>
                    <th className="px-3 py-2">Status</th>
                    <th className="px-3 py-2">Last result</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r) => (
                    <tr key={r.id} className="border-b border-white/[0.04]">
                      <td className="px-3 py-2">
                        <Checkbox
                          checked={selected.has(r.id)}
                          onCheckedChange={(c) => toggleOne(r.id, Boolean(c))}
                          aria-label="Select row"
                        />
                      </td>
                      {visibleFields.map((f) => {
                        const v = r[f.key];
                        const empty = v == null || String(v).trim() === "";
                        return (
                          <td
                            key={f.key}
                            className={
                              f.key === "name"
                                ? "whitespace-nowrap px-3 py-2 font-medium"
                                : "whitespace-nowrap px-3 py-2 text-muted-foreground"
                            }
                          >
                            {empty ? "—" : String(v)}
                          </td>
                        );
                      })}
                      <td className="whitespace-nowrap px-3 py-2 text-muted-foreground">
                        {agentName(r.assigned_agent_id)}
                      </td>
                      <td className="whitespace-nowrap px-3 py-2 text-muted-foreground">
                        {r.scheduled_call_at ? new Date(r.scheduled_call_at).toLocaleString() : "—"}
                      </td>
                      <td className="px-3 py-2">
                        {(() => {
                          const s = STATUS_BADGES[r.call_status] ?? STATUS_BADGES.needs_to_call;
                          return (
                            <span className={`inline-flex items-center rounded-full border px-2 py-0.5 text-[11px] ${s.cls}`}>
                              {s.label}
                            </span>
                          );
                        })()}
                      </td>
                      <td className="whitespace-nowrap px-3 py-2 text-muted-foreground">
                        {r.last_call_outcome || r.last_call_sentiment ? (
                          <div className="flex flex-col gap-0.5">
                            {r.last_call_sentiment && (
                              <span className={`inline-flex w-fit rounded-full px-2 py-0.5 text-[11px] ${SENTIMENT_BADGES[r.last_call_sentiment] ?? "bg-muted text-muted-foreground"}`}>
                                {r.last_call_sentiment}
                              </span>
                            )}
                            {r.last_call_outcome && <span className="text-[11px]">{r.last_call_outcome}</span>}
                            {r.last_call_at && (
                              <span className="text-[10px] text-muted-foreground/70">
                                {new Date(r.last_call_at).toLocaleString()}
                              </span>
                            )}
                          </div>
                        ) : (
                          "—"
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </PanelCard>
      </div>

      <StartCallingDialog
        open={startCallOpen}
        onOpenChange={setStartCallOpen}
        agents={agents}
        selectedCount={selected.size}
        loading={startMut.isPending}
        onStart={(agentId, fromNumber) =>
          startMut.mutate({
            recordIds: Array.from(selected),
            agentId: agentId || null,
            fromNumber: fromNumber || null,
          })
        }
      />

      <ScheduleCallsDialog
        open={scheduleOpen}
        onOpenChange={setScheduleOpen}
        agents={agents}
        selectedCount={selected.size}
        loading={scheduleMut.isPending}
        onSchedule={(when, agentId) =>
          scheduleMut.mutate({
            recordIds: Array.from(selected),
            scheduledAt: when,
            agentId: agentId || null,
          })
        }
      />

      <CallScheduleDialog
        open={callScheduleOpen}
        onOpenChange={setCallScheduleOpen}
        initial={scheduleQ.data?.schedule ?? null}
        defaultTz={scheduleQ.data?.timezone ?? "UTC"}
        loading={setScheduleMut.isPending}
        onSave={(s) => setScheduleMut.mutate(s)}
      />
    </div>
  );
}

// ---------- Dialogs ----------

function StartCallingDialog({
  open,
  onOpenChange,
  agents,
  selectedCount,
  loading,
  onStart,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  agents: any[];
  selectedCount: number;
  loading: boolean;
  onStart: (agentId: string, fromNumber: string) => void;
}) {
  const [agentId, setAgentId] = useState<string>("none");
  const [fromNumber, setFromNumber] = useState("");
  const agent = agents.find((a) => a.id === agentId);
  const linked = !!agent?.retell_agent_id;
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Start calling {selectedCount} record{selectedCount === 1 ? "" : "s"}</DialogTitle>
          <DialogDescription>
            Records assigned to a linked voice agent will be dialed
            immediately. Others will be queued until you link a voice agent
            from the builder.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="space-y-1.5">
            <Label>Agent</Label>
            <Select value={agentId} onValueChange={setAgentId}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">Use each record's assigned agent</SelectItem>
                {agents.map((a) => (
                  <SelectItem key={a.id} value={a.id}>
                    {a.name} {a.retell_agent_id ? "✓ linked" : "(draft)"}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {agentId !== "none" && !linked && (
              <p className="text-xs text-amber-400">
                This agent isn't linked to a voice provider yet. Records will be queued.
              </p>
            )}
          </div>
          <div className="space-y-1.5">
            <Label>Caller ID (from-number)</Label>
            <Input
              placeholder="+15551234567"
              value={fromNumber}
              onChange={(e) => setFromNumber(e.target.value)}
            />
            <p className="text-xs text-muted-foreground">
              Leave empty to queue records without dialing.
            </p>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button
            disabled={loading}
            onClick={() => onStart(agentId === "none" ? "" : agentId, fromNumber)}
            className="bg-primary text-primary-foreground"
          >
            <PhoneOutgoing className="mr-2 h-4 w-4" />
            {loading ? "Starting…" : "Start calling"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function ScheduleCallsDialog({
  open,
  onOpenChange,
  agents,
  selectedCount,
  loading,
  onSchedule,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  agents: any[];
  selectedCount: number;
  loading: boolean;
  onSchedule: (whenIso: string, agentId: string) => void;
}) {
  const defaultWhen = useMemo(() => {
    const d = new Date(Date.now() + 60 * 60 * 1000);
    d.setSeconds(0, 0);
    return d.toISOString().slice(0, 16);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);
  const [when, setWhen] = useState(defaultWhen);
  const [agentId, setAgentId] = useState("none");
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Schedule calls for {selectedCount} record{selectedCount === 1 ? "" : "s"}</DialogTitle>
          <DialogDescription>
            Records will move to "Queued" and the assigned agent will dial them
            at the scheduled time.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="space-y-1.5">
            <Label>When</Label>
            <Input
              type="datetime-local"
              value={when}
              onChange={(e) => setWhen(e.target.value)}
            />
          </div>
          <div className="space-y-1.5">
            <Label>Assign agent (optional)</Label>
            <Select value={agentId} onValueChange={setAgentId}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">Keep current assignment</SelectItem>
                {agents.map((a) => (
                  <SelectItem key={a.id} value={a.id}>
                    {a.name} {a.retell_agent_id ? "✓ linked" : "(draft)"}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button
            disabled={loading || !when}
            onClick={() =>
              onSchedule(new Date(when).toISOString(), agentId === "none" ? "" : agentId)
            }
            className="bg-primary text-primary-foreground"
          >
            {loading ? "Scheduling…" : "Schedule"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function CallScheduleDialog({
  open,
  onOpenChange,
  initial,
  defaultTz,
  loading,
  onSave,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  initial: any;
  defaultTz: string;
  loading: boolean;
  onSave: (s: any) => void;
}) {
  const [enabled, setEnabled] = useState<boolean>(initial?.enabled ?? true);
  const [tz, setTz] = useState<string>(initial?.timezone ?? defaultTz ?? "UTC");
  const [days, setDays] = useState<number[]>(initial?.days ?? [1, 2, 3, 4, 5]);
  const [startHour, setStartHour] = useState<number>(initial?.startHour ?? 9);
  const [endHour, setEndHour] = useState<number>(initial?.endHour ?? 18);

  const toggleDay = (d: number) => {
    setDays((prev) =>
      prev.includes(d) ? prev.filter((x) => x !== d) : [...prev, d].sort(),
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Workspace call schedule</DialogTitle>
          <DialogDescription>
            Set the days and hours your agents are allowed to place outbound calls.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="flex items-center justify-between rounded-lg border border-white/[0.06] p-3">
            <div>
              <p className="text-sm font-medium">Enable schedule</p>
              <p className="text-xs text-muted-foreground">
                When off, calling is paused regardless of queue.
              </p>
            </div>
            <Switch checked={enabled} onCheckedChange={setEnabled} />
          </div>
          <div className="space-y-1.5">
            <Label>Days</Label>
            <div className="flex flex-wrap gap-1.5">
              {DAY_NAMES.map((name, idx) => {
                const active = days.includes(idx);
                return (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => toggleDay(idx)}
                    className={`rounded-md border px-3 py-1.5 text-xs transition ${active ? "border-primary bg-primary/15 text-primary" : "border-white/[0.06] text-muted-foreground hover:text-foreground"}`}
                  >
                    {name}
                  </button>
                );
              })}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Start hour</Label>
              <Input
                type="number"
                min={0}
                max={23}
                value={startHour}
                onChange={(e) => setStartHour(Number(e.target.value))}
              />
            </div>
            <div className="space-y-1.5">
              <Label>End hour</Label>
              <Input
                type="number"
                min={1}
                max={24}
                value={endHour}
                onChange={(e) => setEndHour(Number(e.target.value))}
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>Timezone</Label>
            <Input value={tz} onChange={(e) => setTz(e.target.value)} placeholder="UTC" />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button
            disabled={loading || endHour <= startHour || days.length === 0}
            onClick={() => onSave({ enabled, timezone: tz, days, startHour, endHour })}
            className="bg-primary text-primary-foreground"
          >
            {loading ? "Saving…" : "Save schedule"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
