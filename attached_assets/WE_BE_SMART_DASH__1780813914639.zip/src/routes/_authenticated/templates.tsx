import { createFileRoute } from "@tanstack/react-router";
import { LayoutTemplate } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

export const Route = createFileRoute("/_authenticated/templates")({
  head: () => ({ meta: [{ title: "Templates" }] }),
  component: TemplatesPage,
});

function TemplatesPage() {
  return (
    <div className="mx-auto max-w-6xl px-6 py-8">
      <h1 className="text-2xl font-semibold tracking-tight">Templates</h1>
      <p className="mt-1 text-sm text-muted-foreground">Starter flows you can clone into your workspace.</p>
      <Card className="mt-6 border-dashed">
        <CardContent className="flex flex-col items-center justify-center py-16 text-center">
          <LayoutTemplate className="mb-3 h-8 w-8 text-muted-foreground" />
          <p className="text-sm text-muted-foreground">Templates library coming with the builder port.</p>
        </CardContent>
      </Card>
    </div>
  );
}