import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { MessageCircle } from "lucide-react";
import { PageHeader, PanelCard, EmptyState } from "@/components/dashboard/PageShell";
import { listWhatsappThreads } from "@/lib/dashboard.functions";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/whatsapp")({
  head: () => ({ meta: [{ title: "Whatsapp" }] }),
  component: WhatsappPage,
});

function WhatsappPage() {
  const fn = useServerFn(listWhatsappThreads);
  const q = useQuery({ queryKey: ["wa-threads"], queryFn: () => fn() });
  const threads = (q.data ?? []) as any[];
  const [activePhone, setActivePhone] = useState<string | null>(null);
  const active = threads.find((t) => t.phone === activePhone) ?? threads[0];

  return (
    <div className="pb-12">
      <PageHeader title="Whatsapp" subtitle="All conversations across your workspace" icon={MessageCircle} onRefresh={() => q.refetch()} />
      <div className="px-8 pt-6">
        {threads.length === 0 ? (
          <PanelCard>
            <EmptyState icon={MessageCircle} title="No conversations" message="Inbound and outbound WhatsApp messages will appear here." />
          </PanelCard>
        ) : (
          <div className="grid gap-4 md:grid-cols-[320px_1fr]">
            <PanelCard className="p-0">
              <ul className="divide-y divide-white/[0.05]">
                {threads.map((t) => (
                  <li key={t.phone}>
                    <button
                      onClick={() => setActivePhone(t.phone)}
                      className={cn(
                        "w-full px-4 py-3 text-left transition-colors hover:bg-white/[0.03]",
                        (active?.phone === t.phone) && "bg-primary/10",
                      )}
                    >
                      <p className="truncate text-sm font-medium">{t.name ?? t.phone}</p>
                      <p className="truncate text-xs text-muted-foreground">{t.lastMessage ?? "—"}</p>
                    </button>
                  </li>
                ))}
              </ul>
            </PanelCard>
            <PanelCard>
              {active ? (
                <div className="flex h-[520px] flex-col">
                  <div className="border-b border-white/[0.06] pb-3">
                    <p className="text-sm font-semibold">{active.name ?? active.phone}</p>
                    <p className="text-xs text-muted-foreground">{active.phone}</p>
                  </div>
                  <div className="flex-1 space-y-2 overflow-y-auto py-4">
                    {[...active.messages].reverse().map((m: any) => (
                      <div key={m.id} className={cn("max-w-[75%] rounded-2xl px-3 py-2 text-sm", m.direction === "outbound" ? "ml-auto bg-primary/20 text-foreground" : "bg-muted text-foreground")}>
                        {m.body ?? "(media)"}
                        <p className="mt-1 text-[10px] text-muted-foreground">{new Date(m.sent_at).toLocaleString()}</p>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <EmptyState icon={MessageCircle} title="Select a conversation" message="Pick a thread on the left to view messages." />
              )}
            </PanelCard>
          </div>
        )}
      </div>
    </div>
  );
}