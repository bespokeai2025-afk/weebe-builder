import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getMyContext } from "@/lib/workspace.functions";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({ meta: [{ title: "Admin · Workspace" }] }),
  component: AdminPage,
});

function AdminPage() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const fetchCtx = useServerFn(getMyContext);

  const { data, isLoading, error } = useQuery({
    queryKey: ["my-context"],
    queryFn: () => fetchCtx(),
  });

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    qc.clear();
    navigate({ to: "/login", replace: true });
  };

  if (isLoading) {
    return <div className="flex min-h-screen items-center justify-center text-muted-foreground">Loading workspace…</div>;
  }

  if (error) {
    return (
      <div className="flex min-h-screen items-center justify-center px-4">
        <div className="text-center">
          <p className="text-destructive">{(error as Error).message}</p>
          <Button onClick={handleSignOut} variant="outline" className="mt-4">Sign out</Button>
        </div>
      </div>
    );
  }

  const profile = data!.profile;
  const workspaces = data!.workspaces;

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-6 py-4">
          <h1 className="text-lg font-semibold">Agent Orchestration · Admin</h1>
          <div className="flex items-center gap-3">
            <Button asChild variant="ghost" size="sm"><Link to="/dashboard">Dashboard</Link></Button>
            <Button asChild variant="ghost" size="sm"><Link to="/my-agents">Agents</Link></Button>
            <Button asChild variant="ghost" size="sm"><Link to="/data">Data</Link></Button>
            <span className="text-sm text-muted-foreground">{profile.email}</span>
            <Button variant="outline" size="sm" onClick={handleSignOut}>Sign out</Button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-5xl space-y-6 px-6 py-8">
        <Card>
          <CardHeader>
            <CardTitle>Profile</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            <div><span className="text-muted-foreground">Name:</span> {profile.full_name ?? "—"}</div>
            <div><span className="text-muted-foreground">User ID:</span> <code className="text-xs">{profile.id}</code></div>
            <div><span className="text-muted-foreground">Default workspace:</span> <code className="text-xs">{profile.default_workspace_id ?? "—"}</code></div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Workspaces ({workspaces.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {workspaces.length === 0 ? (
              <p className="text-sm text-muted-foreground">No workspaces.</p>
            ) : (
              <ul className="divide-y">
                {workspaces.map((w) => (
                  <li key={w.id} className="flex items-center justify-between py-3">
                    <div>
                      <div className="font-medium">{w.name}</div>
                      <div className="text-xs text-muted-foreground">{w.slug} · <code>{w.id}</code></div>
                    </div>
                    <Badge variant="secondary">{w.role}</Badge>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Next phases</CardTitle>
          </CardHeader>
          <CardContent className="space-y-1 text-sm text-muted-foreground">
            <p>Phase 2 — Internal schema + workflow compiler</p>
            <p>Phase 3 — Voice provider adapter layer</p>
            <p>Phase 4 — Orchestration server functions (deploy, campaigns, calls)</p>
            <p>Phase 5 — Public API + voice webhooks</p>
            <p>Phase 6 — Deployment logs UI</p>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}