import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { LayoutDashboard, Users, Phone, CalendarCheck, Clock, Headphones, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PageHeader, StatCard, PanelCard, EmptyState } from "@/components/dashboard/PageShell";
import { getOverviewStats, listCalls, listBookings, syncRetellReceptionist } from "@/lib/dashboard.functions";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard" }] }),
  component: DashboardPage,
});

function formatSeconds(s: number): string {
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m`;
  const h = Math.floor(m / 60);
  return `${h}h ${m % 60}m`;
}

function formatRelative(iso: string): string {
  const diff = Math.max(0, Date.now() - new Date(iso).getTime());
  const s = Math.floor(diff / 1000);
  if (s < 60) return `${s}s ago`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}

function DashboardPage() {
  const statsFn = useServerFn(getOverviewStats);
  const callsFn = useServerFn(listCalls);
  const bookingsFn = useServerFn(listBookings);
  const retellFn = useServerFn(syncRetellReceptionist);

  const stats = useQuery({ queryKey: ["overview-stats"], queryFn: () => statsFn() });
  const calls = useQuery({ queryKey: ["recent-calls"], queryFn: () => callsFn({ data: { limit: 5 } }) });
  const bookings = useQuery({ queryKey: ["upcoming-bookings"], queryFn: () => bookingsFn({ data: { limit: 5 } }) });
  const retell = useQuery({ queryKey: ["retell-receptionist"], queryFn: () => retellFn(), staleTime: 60_000 });

  const t = stats.data?.totals;

  return (
    <div className="pb-12">
      <PageHeader
        title="Dashboard"
        subtitle="Overview of leads, calls, and bookings in your workspace"
        icon={LayoutDashboard}
        onRefresh={() => { stats.refetch(); calls.refetch(); bookings.refetch(); }}
      />

      <div className="grid grid-cols-2 gap-4 px-8 pt-6 md:grid-cols-4">
        <StatCard label="Total leads" tone="primary" value={t?.leads ?? "—"} hint={`${t?.qualified ?? 0} qualified`} />
        <StatCard label="Calls" tone="success" value={t?.calls ?? "—"} hint={`${t?.callsCompleted ?? 0} completed`} />
        <StatCard label="Upcoming" tone="warning" value={t?.upcomingBookings ?? "—"} hint={`${t?.pendingBookings ?? 0} pending`} />
        <StatCard label="Cancelled" tone="danger" value={t?.cancelledBookings ?? "—"} hint="bookings" />
      </div>

      <div className="mt-6 grid grid-cols-1 gap-4 px-8 lg:grid-cols-3">
        <PanelCard className="lg:col-span-2">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="text-sm font-semibold">Recent calls</h3>
            <Button asChild size="sm" variant="ghost"><Link to="/calls">View all</Link></Button>
          </div>
          {(calls.data ?? []).length === 0 ? (
            <EmptyState icon={Phone} title="No calls yet" message="Calls placed or received will show up here." />
          ) : (
            <ul className="divide-y divide-white/[0.05]">
              {(calls.data ?? []).map((c: any) => (
                <li key={c.id} className="flex items-center justify-between py-3">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium text-foreground">{c.lead?.full_name ?? c.to_number}</p>
                    <p className="text-xs text-muted-foreground">
                      {c.call_type} · {c.call_status}{c.started_at ? ` · ${formatRelative(c.started_at)}` : ""}
                    </p>
                  </div>
                  <p className="text-xs text-muted-foreground tabular-nums">{formatSeconds(c.duration_seconds ?? 0)}</p>
                </li>
              ))}
            </ul>
          )}
        </PanelCard>

        <PanelCard>
          <div className="mb-4 flex items-center justify-between">
            <h3 className="text-sm font-semibold">Upcoming bookings</h3>
            <Button asChild size="sm" variant="ghost"><Link to="/calendar">Open</Link></Button>
          </div>
          {(bookings.data ?? []).length === 0 ? (
            <EmptyState icon={CalendarCheck} title="No bookings" message="New appointments will appear here." />
          ) : (
            <ul className="space-y-3">
              {(bookings.data ?? []).slice(0, 5).map((b: any) => (
                <li key={b.id} className="rounded-lg bg-white/[0.03] p-3">
                  <p className="truncate text-sm font-medium text-foreground">{b.title}</p>
                  <p className="text-xs text-muted-foreground">{new Date(b.start_at).toLocaleString()}</p>
                </li>
              ))}
            </ul>
          )}
        </PanelCard>
      </div>

      <div className="mt-6 grid grid-cols-1 gap-4 px-8 lg:grid-cols-2">
        <PanelCard>
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/15 text-primary">
              <Clock className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Total call time</p>
              <p className="text-xl font-semibold tabular-nums">{formatSeconds(t?.totalCallSeconds ?? 0)}</p>
            </div>
          </div>
        </PanelCard>
        <PanelCard>
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/15 text-primary">
              <Users className="h-5 w-5" />
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Qualified rate</p>
              <p className="text-xl font-semibold tabular-nums">
                {t && t.leads > 0 ? `${Math.round((t.qualified / t.leads) * 100)}%` : "—"}
              </p>
            </div>
          </div>
        </PanelCard>
      </div>

      <div className="mt-6 px-8">
        <PanelCard>
          <div className="mb-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/15 text-primary">
                <Headphones className="h-5 w-5" />
              </div>
              <div>
                <h3 className="text-sm font-semibold">Receptionists</h3>
                <p className="text-xs text-muted-foreground">Live status of agents deployed from the builder</p>
              </div>
            </div>
            <Button size="sm" variant="ghost" onClick={() => retell.refetch()} disabled={retell.isFetching}>
              <RefreshCw className={`mr-2 h-3.5 w-3.5 ${retell.isFetching ? "animate-spin" : ""}`} /> Sync
            </Button>
          </div>
          {retell.isLoading ? (
            <p className="text-xs text-muted-foreground">Loading…</p>
          ) : (retell.data?.agents.length ?? 0) === 0 ? (
            <EmptyState
              icon={Headphones}
              title="No receptionists deployed"
              message="Deploy an agent from the builder to make it pick up calls here."
            />
          ) : (
            <div className="space-y-3">
              {retell.data!.agents.map((a) => {
                const phones = retell.data!.phoneNumbers.filter(
                  (p) => p.inbound_agent_id === a.agent_id || p.outbound_agent_id === a.agent_id,
                );
                return (
                  <div key={a.agent_id} className="rounded-xl border border-white/[0.06] bg-white/[0.02] p-3">
                    <div className="flex items-center justify-between">
                      <div className="min-w-0">
                        <p className="truncate text-sm font-medium">{a.agent_name ?? "Untitled agent"}</p>
                        <p className="truncate text-[11px] text-muted-foreground font-mono">{a.agent_id}</p>
                      </div>
                      <span className="rounded-full bg-emerald-500/15 px-2 py-0.5 text-[11px] text-emerald-400">Live</span>
                    </div>
                    {phones.length > 0 && (
                      <div className="mt-2 flex flex-wrap gap-1.5">
                        {phones.map((p) => (
                          <span key={p.phone_number ?? p.nickname} className="rounded-full bg-primary/15 px-2 py-0.5 text-[11px] text-primary">
                            {p.phone_number ?? p.nickname}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </PanelCard>
      </div>
    </div>
  );
}