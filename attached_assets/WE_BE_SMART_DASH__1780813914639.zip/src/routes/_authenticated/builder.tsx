import { createFileRoute } from "@tanstack/react-router";
import { Workflow } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

export const Route = createFileRoute("/_authenticated/builder")({
  head: () => ({ meta: [{ title: "Builder" }] }),
  component: BuilderPage,
});

function BuilderPage() {
  return (
    <div className="mx-auto max-w-4xl px-6 py-8">
      <h1 className="text-2xl font-semibold tracking-tight">Builder</h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Design conversation flows and deploy them to your voice provider.
      </p>
      <Card className="mt-6 border-dashed">
        <CardContent className="flex flex-col items-center justify-center py-16 text-center">
          <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
            <Workflow className="h-6 w-6" />
          </div>
          <h3 className="text-lg font-semibold">Builder UI coming next</h3>
          <p className="mt-1 max-w-md text-sm text-muted-foreground">
            The full drag-and-drop builder from the Agent Exporter is being merged in. The backend
            (agents table, workspace-scoped CRUD, IR + deploy pipeline) is ready.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}