import { createFileRoute } from "@tanstack/react-router";
import { Link } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Agent Orchestration Platform" },
      { name: "description", content: "Multi-tenant AI voice agent orchestration backend." },
      { property: "og:title", content: "Agent Orchestration Platform" },
      { property: "og:description", content: "Multi-tenant AI voice agent orchestration backend." },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-background px-6 text-center">
      <h1 className="text-4xl font-bold tracking-tight text-foreground sm:text-5xl">
        Agent Orchestration Platform
      </h1>
      <p className="mt-4 max-w-xl text-muted-foreground">
        Multi-tenant backend for AI voice agents. Compile workflows, deploy your voice agents,
        sync calls, and run campaigns — all from one API surface.
      </p>
      <div className="mt-8 flex gap-3">
        <Link
          to="/login"
          className="inline-flex items-center justify-center rounded-md bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground hover:bg-primary/90"
        >
          Sign in
        </Link>
        <Link
          to="/signup"
          className="inline-flex items-center justify-center rounded-md border border-input bg-background px-5 py-2.5 text-sm font-medium text-foreground hover:bg-accent"
        >
          Create account
        </Link>
      </div>
    </div>
  );
}
