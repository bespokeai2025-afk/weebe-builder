import { useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { RefreshCw } from "lucide-react";
import { toast } from "sonner";
import { PanelCard } from "@/components/dashboard/PageShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { syncFromBuilder } from "@/lib/dashboard.functions";

export function BuilderSyncSection<F extends { builder_base_url: string; builder_api_token: string }>({
  form,
  setForm,
  lastSyncedAt,
  lastStatus,
  saveFirst,
}: {
  form: F;
  setForm: React.Dispatch<React.SetStateAction<F>>;
  lastSyncedAt: string | null;
  lastStatus: string | null;
  saveFirst: () => Promise<unknown>;
}) {
  const syncFn = useServerFn(syncFromBuilder);
  const syncMut = useMutation({
    mutationFn: async () => {
      await saveFirst();
      return syncFn();
    },
    onSuccess: (r: any) => {
      const n = r?.filled?.length ?? 0;
      toast.success(n ? `Synced ${n} field(s) from Builder` : "Connected — nothing new to pull");
      setTimeout(() => window.location.reload(), 400);
    },
    onError: (e: any) => toast.error(e?.message ?? "Sync failed"),
  });

  return (
    <PanelCard>
      <div className="mb-1 flex items-center justify-between gap-3">
        <h3 className="text-sm font-semibold">Sync from Agent Builder</h3>
        <Button
          size="sm"
          onClick={() => syncMut.mutate()}
          disabled={syncMut.isPending}
          className="bg-primary text-primary-foreground"
        >
          <RefreshCw className={`mr-1.5 h-3.5 w-3.5 ${syncMut.isPending ? "animate-spin" : ""}`} />
          {syncMut.isPending ? "Syncing…" : "Sync now"}
        </Button>
      </div>
      <p className="mb-4 text-xs text-muted-foreground">
        Pulls Cal.com, Twilio, timezone, business name and the default voice
        agent ID from your Agent Builder workspace and fills every field on
        this page in one click.
      </p>
      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-1.5">
          <Label className="text-xs uppercase tracking-wider text-muted-foreground">Builder URL</Label>
          <Input
            placeholder="https://your-builder.lovable.app"
            value={form.builder_base_url}
            onChange={(e) => setForm((f) => ({ ...f, builder_base_url: e.target.value }))}
          />
        </div>
        <div className="space-y-1.5">
          <Label className="text-xs uppercase tracking-wider text-muted-foreground">Builder API token</Label>
          <Input
            type="password"
            placeholder="Paste token from Builder settings"
            value={form.builder_api_token}
            onChange={(e) => setForm((f) => ({ ...f, builder_api_token: e.target.value }))}
          />
        </div>
      </div>
      {lastSyncedAt ? (
        <p className="mt-3 text-[11px] text-muted-foreground">
          Last synced {new Date(lastSyncedAt).toLocaleString()}
          {lastStatus ? ` · ${lastStatus}` : ""}
        </p>
      ) : null}
      <details className="mt-4 rounded-md border bg-muted/30 p-3 text-xs text-muted-foreground">
        <summary className="cursor-pointer font-medium text-foreground">
          Builder setup (one-time)
        </summary>
        <p className="mt-2">
          Add this endpoint to the Agent Builder project so this dashboard can
          pull settings. Paste the prompt below into the Builder's chat:
        </p>
        <pre className="mt-2 max-h-64 overflow-auto rounded bg-background p-2 font-mono text-[11px] leading-relaxed">
{`Create a TanStack server route at src/routes/api/public/integrations/export.ts.
It must:
- Accept GET only.
- Read "Authorization: Bearer <token>" and validate the token against a stored
  per-user API token (reuse dashboard_sync_settings.api_token — match the
  token and resolve the user_id).
- Load that user's workspace_calendar_settings row.
- Respond 200 with JSON:
    {
      "calcom":   { "apiToken": <calcom_api_key>, "eventTypeId": <default_event_type_id> },
      "twilio":   { "authToken": <twilio_auth_token or null>, "phoneId": <whatsapp_phone_id or null> },
      "timezone": <timezone>,
      "businessName": <business_name or null>,
      "notificationEmail": <notification_email or null>,
      "retellDefaultAgentId": <default retell agent id or null>
    }
- Return 401 on missing/invalid bearer. Never leak data across users.`}
        </pre>
      </details>
    </PanelCard>
  );
}