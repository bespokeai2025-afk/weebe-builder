import { useRef, useState } from "react";
import Papa from "papaparse";
import { Upload, FileSpreadsheet, Check, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const ALIASES: Record<string, string> = {
  // canonical -> aliases (lowercased)
  name: "name|full_name|fullname|client|customer",
  mobile_number: "mobile_number|mobile|phone|phone_number|mobilenumber|cell",
  first_name: "first_name|firstname|first",
  last_name: "last_name|lastname|last|surname",
  email: "email|email_address|e-mail",
  title: "title|salutation",
  client_name: "client_name|clientname|company|account",
  unique_id: "unique_id|uniqueid|external_id|id|record_id",
  property_type: "property_type|propertytype",
  bedrooms: "bedrooms|beds",
  address_line1: "address_line1|address|addr|street|address1",
  address_line2: "address_line2|address2|addr2",
  city: "city|town",
  state: "state|region|province",
  postal_code: "postal_code|postalcode|postcode|zip|zip_code",
};

const CANONICAL_FIELDS = Object.keys(ALIASES);
const IGNORE = "__ignore__";

function normalize(h: string) {
  return h.trim().toLowerCase().replace(/[\s\-]+/g, "_");
}

function mapHeader(h: string): string | null {
  const k = normalize(h);
  for (const [canon, aliases] of Object.entries(ALIASES)) {
    if (aliases.split("|").some((a) => a === k)) return canon;
  }
  return null;
}

export type ParsedRow = Record<string, string>;

export function CsvUploader({
  onImport,
  isImporting,
}: {
  onImport: (rows: ParsedRow[]) => void;
  isImporting?: boolean;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [rawRows, setRawRows] = useState<Record<string, string>[]>([]);
  const [headers, setHeaders] = useState<{ raw: string; mapped: string | null }[]>([]);
  const [fileName, setFileName] = useState<string | null>(null);
  const [dragging, setDragging] = useState(false);

  const buildRows = (
    src: Record<string, string>[],
    mapping: { raw: string; mapped: string | null }[],
  ): ParsedRow[] => {
    const out: ParsedRow[] = [];
    for (const r of src) {
      const row: ParsedRow = {};
      for (const h of mapping) {
        if (!h.mapped) continue;
        const v = (r as any)[h.raw];
        if (v != null && String(v).trim() !== "") row[h.mapped] = String(v).trim();
      }
      if (!row.name && (row.first_name || row.last_name)) {
        row.name = [row.first_name, row.last_name].filter(Boolean).join(" ").trim();
      }
      if (row.name && row.mobile_number) out.push(row);
    }
    return out;
  };

  const rows = buildRows(rawRows, headers);

  const updateMapping = (raw: string, value: string) => {
    setHeaders((prev) =>
      prev.map((h) =>
        h.raw === raw ? { ...h, mapped: value === IGNORE ? null : value } : h,
      ),
    );
  };

  const handleFile = (file: File) => {
    setFileName(file.name);
    Papa.parse<Record<string, string>>(file, {
      header: true,
      skipEmptyLines: true,
      complete: (result) => {
        const rawHeaders = result.meta.fields ?? [];
        const mapped = rawHeaders.map((h) => ({ raw: h, mapped: mapHeader(h) }));
        setHeaders(mapped);
        setRawRows(result.data);
        const out = buildRows(result.data, mapped);
        if (out.length === 0) {
          toast.warning("Auto-mapping incomplete. Map your columns below — name + mobile_number are required.");
        } else {
          toast.success(`Parsed ${out.length} rows from ${file.name}. Review mapping below.`);
        }
      },
      error: (err) => toast.error(`Parse error: ${err.message}`),
    });
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    const f = e.dataTransfer.files?.[0];
    if (f) handleFile(f);
  };

  const reset = () => {
    setRawRows([]);
    setHeaders([]);
    setFileName(null);
    if (inputRef.current) inputRef.current.value = "";
  };

  const usedFields = new Set(headers.map((h) => h.mapped).filter(Boolean) as string[]);
  const hasName = usedFields.has("name") || (usedFields.has("first_name") || usedFields.has("last_name"));
  const hasPhone = usedFields.has("mobile_number");

  return (
    <div className="space-y-4">
      <div
        onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDrop={onDrop}
        className={cn(
          "rounded-2xl border-2 border-dashed border-white/10 bg-card/30 p-8 text-center transition-colors",
          dragging && "border-primary/60 bg-primary/5",
        )}
      >
        <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-primary/15 text-primary">
          <Upload className="h-5 w-5" />
        </div>
        <p className="text-sm font-medium">Drag a CSV here or browse</p>
        <p className="mt-1 text-xs text-muted-foreground">
          Required columns: <code className="font-mono">name</code>, <code className="font-mono">mobile_number</code>. Optional: email, city, address…
        </p>
        <input
          ref={inputRef}
          type="file"
          accept=".csv,text/csv"
          className="hidden"
          onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
        />
        <Button
          variant="secondary"
          onClick={() => inputRef.current?.click()}
          className="mt-4 bg-primary/15 text-primary hover:bg-primary/25"
        >
          Choose CSV
        </Button>
      </div>

      {fileName && (
        <div className="rounded-2xl border border-white/[0.06] bg-card/50 p-4">
          <div className="mb-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <FileSpreadsheet className="h-4 w-4 text-primary" />
              <span className="text-sm font-medium">{fileName}</span>
              <span className="text-xs text-muted-foreground">· {rows.length} ready</span>
            </div>
            <Button variant="ghost" size="sm" onClick={reset}>Clear</Button>
          </div>
          <div className="mb-4">
            <div className="mb-2 flex items-center justify-between">
              <p className="text-xs font-medium text-muted-foreground">Column mapping</p>
              <p className="text-[10px] text-muted-foreground">
                Required: <span className={cn("font-mono", hasName ? "text-emerald-400" : "text-destructive")}>name</span>{" "}
                + <span className={cn("font-mono", hasPhone ? "text-emerald-400" : "text-destructive")}>mobile_number</span>
              </p>
            </div>
            <div className="grid gap-2 sm:grid-cols-2">
              {headers.map((h) => {
                const sample = rawRows[0]?.[h.raw];
                return (
                  <div
                    key={h.raw}
                    className="flex items-center gap-2 rounded-lg border border-white/[0.06] bg-background/40 p-2"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        {h.mapped ? (
                          <Check className="h-3 w-3 shrink-0 text-emerald-400" />
                        ) : (
                          <X className="h-3 w-3 shrink-0 text-muted-foreground" />
                        )}
                        <span className="truncate text-xs font-medium">{h.raw}</span>
                      </div>
                      {sample && (
                        <p className="mt-0.5 truncate pl-4 text-[10px] text-muted-foreground">
                          e.g. {sample}
                        </p>
                      )}
                    </div>
                    <Select
                      value={h.mapped ?? IGNORE}
                      onValueChange={(v) => updateMapping(h.raw, v)}
                    >
                      <SelectTrigger className="h-8 w-[160px] text-xs">
                        <SelectValue placeholder="Ignore" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value={IGNORE} className="text-xs">
                          Ignore column
                        </SelectItem>
                        {CANONICAL_FIELDS.map((f) => {
                          const taken = usedFields.has(f) && h.mapped !== f;
                          return (
                            <SelectItem key={f} value={f} disabled={taken} className="text-xs">
                              {f}
                              {taken && " (used)"}
                            </SelectItem>
                          );
                        })}
                      </SelectContent>
                    </Select>
                  </div>
                );
              })}
            </div>
          </div>
          <Button
            onClick={() => onImport(rows)}
            disabled={rows.length === 0 || isImporting}
            className="bg-primary text-primary-foreground"
          >
            {isImporting ? "Importing…" : `Import ${rows.length} records`}
          </Button>
        </div>
      )}
    </div>
  );
}