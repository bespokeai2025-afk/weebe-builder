import { Link, useRouterState, useNavigate } from "@tanstack/react-router";
import {
  ShieldCheck,
  ChevronsUpDown,
  LogOut,
  Sparkles,
  LayoutDashboard,
  Database,
  Users,
  MessageCircle,
  Phone,
  CalendarCheck,
  Settings,
  BarChart3,
  Bot,
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import { ThemeToggle } from "@/components/ThemeToggle";

const navItems = [
  { title: "Dashboard", url: "/dashboard", icon: LayoutDashboard },
  { title: "My Agents", url: "/my-agents", icon: Bot },
  { title: "Data", url: "/data", icon: Database },
  { title: "Leads", url: "/leads", icon: Users },
  { title: "Qualified", url: "/qualified", icon: ShieldCheck },
  { title: "Whatsapp", url: "/whatsapp", icon: MessageCircle },
  { title: "Calls", url: "/calls", icon: Phone },
  { title: "Calendar Manager", url: "/calendar", icon: CalendarCheck },
  { title: "Analytics", url: "/analytics", icon: BarChart3 },
  { title: "Settings", url: "/settings", icon: Settings },
];

interface AppSidebarProps {
  email?: string;
  workspaceName?: string;
  isAdmin?: boolean;
}

export function AppSidebar({ email = "", workspaceName = "Workspace", isAdmin = false }: AppSidebarProps) {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const navigate = useNavigate();
  const currentPath = useRouterState({ select: (r) => r.location.pathname });

  const isActive = (path: string) =>
    path === "/builder"
      ? currentPath.startsWith("/builder")
      : currentPath === path || currentPath.startsWith(path + "/");

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    navigate({ to: "/login" });
  };

  const initials = (email || "U").slice(0, 2).toUpperCase();

  const navButtonClasses = (active: boolean) =>
    cn(
      "group/nav relative h-11 rounded-xl px-3 text-[15px] transition-all duration-200",
      "text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-white/[0.04]",
      "group-data-[collapsible=icon]:!h-11 group-data-[collapsible=icon]:!w-11",
      "group-data-[collapsible=icon]:!p-0 group-data-[collapsible=icon]:justify-center",
      active && [
        "text-white font-medium",
        "bg-gradient-to-r from-primary/25 via-primary/15 to-transparent",
        "shadow-[inset_0_0_0_1px_rgba(124,92,255,0.25)]",
      ],
    );

  return (
    <Sidebar collapsible="icon" className="border-r border-white/[0.04]">
      <SidebarHeader className="px-4 pt-5 pb-4 group-data-[collapsible=icon]:px-2">
        <div className="flex items-center justify-center rounded-2xl bg-white px-4 py-4 shadow-elegant group-data-[collapsible=icon]:px-2 group-data-[collapsible=icon]:py-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-primary/60 text-primary-foreground">
            <Sparkles className="h-5 w-5" />
          </div>
          {!collapsed && (
            <span className="ml-2 truncate text-sm font-semibold text-[#0A0E1F]">
              {workspaceName}
            </span>
          )}
        </div>
      </SidebarHeader>

      <SidebarContent className="px-3 pt-4">
        <SidebarGroup>
          {!collapsed && (
            <SidebarGroupLabel className="px-3 pb-2 text-[10px] font-medium uppercase tracking-[0.14em] text-sidebar-foreground/40">
              Workspace
            </SidebarGroupLabel>
          )}
          <SidebarGroupContent>
            <SidebarMenu className="gap-1.5">
              {navItems.map((item) => {
                const active = isActive(item.url);
                return (
                  <SidebarMenuItem key={item.url}>
                    <SidebarMenuButton asChild tooltip={item.title} className={navButtonClasses(active)}>
                      <Link to={item.url} className="flex items-center gap-3">
                        <item.icon className={cn("h-5 w-5 shrink-0", active ? "text-primary" : "text-sidebar-foreground/60")} />
                        <span className="truncate group-data-[collapsible=icon]:hidden">{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {isAdmin && (
          <>
            <div className="mx-2 my-3 h-px bg-border" />
            <SidebarGroup>
              {!collapsed && (
                <SidebarGroupLabel className="px-2 text-[10px] font-medium uppercase tracking-[0.12em] text-muted-foreground/70">
                  Administration
                </SidebarGroupLabel>
              )}
              <SidebarGroupContent>
                <SidebarMenu className="gap-1">
                  <SidebarMenuItem>
                    <SidebarMenuButton asChild tooltip="Admin" className={navButtonClasses(isActive("/admin"))}>
                      <Link to="/admin" className="flex items-center gap-3">
                        <ShieldCheck className={cn("h-[18px] w-[18px]", isActive("/admin") ? "text-primary" : "text-muted-foreground")} />
                        <span className="truncate group-data-[collapsible=icon]:hidden">Admin</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </>
        )}
      </SidebarContent>

      <div className="mx-2 mb-1 h-px bg-border" />
      <SidebarFooter className="px-1.5 pb-3">
        <div className="flex items-center justify-between gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="group flex flex-1 items-center gap-2.5 rounded-lg px-1.5 py-1.5 text-left hover:bg-muted/40">
                <Avatar className="h-8 w-8">
                  <AvatarFallback className="bg-gradient-to-br from-primary/30 to-primary/10 text-[11px] font-semibold">
                    {initials}
                  </AvatarFallback>
                </Avatar>
                {!collapsed && (
                  <>
                    <div className="flex min-w-0 flex-1 flex-col">
                      <span className="truncate text-sm font-medium">{email || "Account"}</span>
                      <span className="flex items-center gap-1 text-[11px] text-muted-foreground">
                        {isAdmin ? <Badge variant="secondary" className="h-4 rounded px-1.5 py-0 text-[10px] font-normal">Admin</Badge> : "Member"}
                      </span>
                    </div>
                    <ChevronsUpDown className="h-3.5 w-3.5 text-muted-foreground" />
                  </>
                )}
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" side="top" className="w-56">
              <DropdownMenuLabel className="truncate text-xs text-muted-foreground">{email}</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleSignOut} className="text-destructive focus:text-destructive">
                <LogOut className="mr-2 h-4 w-4" />
                Sign out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          {!collapsed && <ThemeToggle className="h-8 w-8" />}
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}