import { Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

export function Logo({ className }: { className?: string }) {
  return (
    <div
      className={cn(
        "flex h-8 w-8 items-center justify-center rounded-lg",
        "bg-gradient-to-br from-primary/90 to-primary/50 text-primary-foreground",
        "shadow-[0_0_0_1px_rgba(79,140,255,0.25),0_4px_16px_-4px_rgba(79,140,255,0.45)]",
        className,
      )}
      aria-label="Orchestrate logo"
    >
      <Sparkles className="h-4 w-4" />
    </div>
  );
}