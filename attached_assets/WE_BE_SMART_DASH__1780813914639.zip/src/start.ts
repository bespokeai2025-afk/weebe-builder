import { createStart, createMiddleware } from "@tanstack/react-start";

import { renderErrorPage } from "./lib/error-page";
import { attachSupabaseAuth } from "@/integrations/supabase/auth-attacher";

// Allow this app to be iframed by the agent builder (and any other
// *.lovable.app surface / custom domain we add later).
const FRAME_ANCESTORS =
  "'self' https://*.lovable.app https://*.lovable.dev https://*.lovableproject.com https://*.lovable.build";

const frameAncestorsMiddleware = createMiddleware().server(async ({ next }) => {
  const response = await next();
  if (response instanceof Response) {
    response.headers.set(
      "Content-Security-Policy",
      `frame-ancestors ${FRAME_ANCESTORS}`,
    );
    // Remove any X-Frame-Options that would otherwise block embedding.
    response.headers.delete("X-Frame-Options");
  }
  return response;
});

const errorMiddleware = createMiddleware().server(async ({ next }) => {
  try {
    return await next();
  } catch (error) {
    if (error != null && typeof error === "object" && "statusCode" in error) {
      throw error;
    }
    console.error(error);
    return new Response(renderErrorPage(), {
      status: 500,
      headers: { "content-type": "text/html; charset=utf-8" },
    });
  }
});

export const startInstance = createStart(() => ({
  requestMiddleware: [frameAncestorsMiddleware, errorMiddleware],
  functionMiddleware: [attachSupabaseAuth],
}));
