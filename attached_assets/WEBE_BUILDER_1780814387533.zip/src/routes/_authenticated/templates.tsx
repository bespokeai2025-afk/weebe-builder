import { useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, Loader2, Trash2, Plus, Globe2, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import { Logo } from "@/components/Logo";
import { ThemeToggle } from "@/components/ThemeToggle";
import { useBuilderStore } from "@/lib/builder/store";
import {
  listAgentTemplates,
  getAgentTemplate,
  deleteAgentTemplate,
  isCurrentUserAdmin,
} from "@/lib/agents/templates.functions";

export const Route = createFileRoute("/_authenticated/templates")({
  head: () => ({
    meta: [
      { title: "Agent Templates — Webespoke AI" },
      {
        name: "description",
        content:
          "Browse global agent templates and your personal saved templates. Clone any template into the builder to start a new agent.",
      },
    ],
  }),
  component: TemplatesPage,
});

function TemplatesPage() {
  const navigate = useNavigate();
  const listFn = useServerFn(listAgentTemplates);
  const getFn = useServerFn(getAgentTemplate);
  const deleteFn = useServerFn(deleteAgentTemplate);
  const adminFn = useServerFn(isCurrentUserAdmin);
  const qc = useQueryClient();

  const [loadingId, setLoadingId] = useState<string | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<{ id: string; name: string } | null>(null);
  const [deleting, setDeleting] = useState(false);

  const templatesQ = useQuery({
    queryKey: ["agent-templates"],
    queryFn: () => listFn(),
    refetchOnWindowFocus: false,
  });

  const adminQ = useQuery({
    queryKey: ["is-admin"],
    queryFn: () => adminFn(),
    refetchOnWindowFocus: false,
  });

  async function handleUse(id: string) {
    setLoadingId(id);
    try {
      const row = await getFn({ data: { id } });
      if (!row) throw new Error("Template not found");
      const flow = (row.flow_data ?? {}) as { nodes?: unknown; edges?: unknown };
      const nodes = Array.isArray(flow.nodes) ? flow.nodes : [];
      const edges = Array.isArray(flow.edges) ? flow.edges : [];
      const settings = (row.settings ?? {}) as Record<string, unknown>;
      const variables = Array.isArray(row.variables) ? row.variables : [];
      // Strip identifiers so a fresh agent is created on save.
      const cleanSettings = {
        ...settings,
        agentId: undefined,
        conversationFlowId: undefined,
        deployedRetellAgentId: undefined,
        deployedConversationFlowId: undefined,
        phoneNumber: undefined,
        agentName: `${row.name} (copy)`,
      };
      useBuilderStore.getState().loadFlow({
        nodes: nodes as never,
        edges: edges as never,
        settings: cleanSettings as never,
        variables: variables as never,
        agentRowId: null,
      });
      toast.success("Template loaded", { description: row.name });
      navigate({ to: "/builder" });
    } catch (e) {
      toast.error("Failed to load template", { description: (e as Error).message });
    } finally {
      setLoadingId(null);
    }
  }

  async function handleDelete() {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await deleteFn({ data: { id: deleteTarget.id } });
      toast.success("Template deleted");
      setDeleteTarget(null);
      qc.invalidateQueries({ queryKey: ["agent-templates"] });
    } catch (e) {
      toast.error("Delete failed", { description: (e as Error).message });
    } finally {
      setDeleting(false);
    }
  }

  const all = templatesQ.data ?? [];
  const globals = all.filter((t) => t.scope === "global");
  const personals = all.filter((t) => t.scope === "personal");
  const isAdmin = adminQ.data?.isAdmin ?? false;

  return (
    <main className="min-h-screen bg-background">
      <header className="border-b">
        <div className="mx-auto max-w-6xl px-4 py-3 flex items-center justify-between">
          <Link
            to="/builder"
            className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" />
            <Logo className="h-7" />
          </Link>
          <h1 className="text-sm font-medium hidden md:block">Agent Templates</h1>
          <div className="flex items-center gap-2">
            <ThemeToggle />
            <Button asChild size="sm" variant="default" className="gap-1">
              <Link to="/builder">
                <Plus className="h-4 w-4" />
                <span className="hidden sm:inline">New agent</span>
              </Link>
            </Button>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-6xl px-4 py-8 space-y-10">
        <section>
          <div className="flex items-center gap-2 mb-4">
            <Globe2 className="h-5 w-5 text-muted-foreground" />
            <h2 className="text-lg font-semibold">Global templates</h2>
            <Badge variant="secondary" className="ml-1">
              {globals.length}
            </Badge>
          </div>
          <p className="text-sm text-muted-foreground mb-4">
            Curated starting points available to everyone in the workspace.
            {isAdmin
              ? " As an admin, open one in the builder and use Save as template → Global to add new ones."
              : ""}
          </p>
          <TemplateGrid
            items={globals}
            onUse={handleUse}
            onDelete={(t) => setDeleteTarget(t)}
            canDelete={(t) => (t.scope === "personal" ? true : isAdmin)}
            loadingId={loadingId}
            empty="No global templates yet."
          />
        </section>

        <section>
          <div className="flex items-center gap-2 mb-4">
            <User className="h-5 w-5 text-muted-foreground" />
            <h2 className="text-lg font-semibold">My templates</h2>
            <Badge variant="secondary" className="ml-1">
              {personals.length}
            </Badge>
          </div>
          <p className="text-sm text-muted-foreground mb-4">
            Your private templates. Save the current builder draft from the builder header.
          </p>
          <TemplateGrid
            items={personals}
            onUse={handleUse}
            onDelete={(t) => setDeleteTarget(t)}
            canDelete={() => true}
            loadingId={loadingId}
            empty="You haven't saved any templates yet."
          />
        </section>
      </div>

      <AlertDialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete template?</AlertDialogTitle>
            <AlertDialogDescription>
              This permanently removes &quot;{deleteTarget?.name}&quot;. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} disabled={deleting}>
              {deleting ? <Loader2 className="h-4 w-4 animate-spin" /> : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </main>
  );
}

interface TemplateItem {
  id: string;
  scope: "global" | "personal";
  name: string;
  description: string;
  updated_at: string;
}

function TemplateGrid({
  items,
  onUse,
  onDelete,
  canDelete,
  loadingId,
  empty,
}: {
  items: TemplateItem[];
  onUse: (id: string) => void;
  onDelete: (t: { id: string; name: string }) => void;
  canDelete: (t: TemplateItem) => boolean;
  loadingId: string | null;
  empty: string;
}) {
  if (items.length === 0) {
    return (
      <div className="rounded-md border border-dashed p-8 text-center text-sm text-muted-foreground">
        {empty}
      </div>
    );
  }
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
      {items.map((t) => (
        <Card key={t.id}>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">{t.name}</CardTitle>
            <CardDescription className="line-clamp-2">
              {t.description || "No description."}
            </CardDescription>
          </CardHeader>
          <CardContent className="flex items-center justify-between gap-2">
            <span className="text-xs text-muted-foreground">
              Updated {new Date(t.updated_at).toLocaleDateString()}
            </span>
            <div className="flex items-center gap-1">
              {canDelete(t) ? (
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => onDelete({ id: t.id, name: t.name })}
                  aria-label="Delete template"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              ) : null}
              <Button
                size="sm"
                onClick={() => onUse(t.id)}
                disabled={loadingId === t.id}
              >
                {loadingId === t.id ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  "Use template"
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
